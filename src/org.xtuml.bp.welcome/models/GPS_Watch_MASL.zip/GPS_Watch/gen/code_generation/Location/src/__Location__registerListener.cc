//
// File: __Location__registerListener.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "Location_OOA/__Location_services.hh"
#include "__Location__GPS.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_Location
{
  void masls_registerListener ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_registerListener);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // gps : instance of GPS;
        ::SWA::ObjectPtr<maslo_GPS> maslv_gps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_gps(0, maslv_gps);

        // GPS.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslo_GPS::masls_initialize();
        }

        // gps := find_one GPS ();
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_gps = maslo_GPS::findOne();
        }

        // generate GPS.registerListener () to gps;
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_gps->create_maslo_GPS_maslev_registerListener() );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_registerListener = interceptor_masls_registerListener::instance().registerLocal( &masls_registerListener );

}
