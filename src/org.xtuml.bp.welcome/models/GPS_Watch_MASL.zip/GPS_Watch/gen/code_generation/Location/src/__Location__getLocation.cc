//
// File: __Location__getLocation.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "Location_OOA/__Location_services.hh"
#include "__Location__GPS.hh"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Location
{
  void masls_getLocation ( double& maslp_latitude,
                           double& maslp_longitude )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_getLocation);
      ::SWA::Stack::DeclareParameter pm_maslp_latitude(maslp_latitude);
      ::SWA::Stack::DeclareParameter pm_maslp_longitude(maslp_longitude);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // gps : instance of GPS;
        ::SWA::ObjectPtr<maslo_GPS> maslv_gps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_gps(0, maslv_gps);

        // GPS.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslo_GPS::masls_initialize();
        }

        // gps := find_one GPS ();
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          maslv_gps = maslo_GPS::findOne();
        }

        // latitude := gps.currentLatitude;
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          maslp_latitude = maslv_gps->get_masla_currentLatitude();
        }

        // longitude := gps.currentLongitude;
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          maslp_longitude = maslv_gps->get_masla_currentLongitude();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_getLocation = interceptor_masls_getLocation::instance().registerLocal( &masls_getLocation );

}
