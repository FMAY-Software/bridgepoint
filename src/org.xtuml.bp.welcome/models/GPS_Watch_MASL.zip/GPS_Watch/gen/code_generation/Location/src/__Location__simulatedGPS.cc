//
// File: __Location__simulatedGPS.cc
//
#include "__Location__simulatedGPS.hh"
#include "__Location__simulatedGPSPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  ::SWA::ObjectPtr<maslo_simulatedGPS> maslo_simulatedGPS::getInstance ( ::SWA::IdType id )
  {
    return maslo_simulatedGPSPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_simulatedGPS::getNextArchId ( )
  {
    return maslo_simulatedGPSPopulation::getSingleton().getNextArchId();
  }

  maslo_simulatedGPS::maslo_simulatedGPS ( )
    : isDeletedFlag()
  {
  }

  maslo_simulatedGPS::~maslo_simulatedGPS ( )
  {
  }

  ::SWA::ObjectPtr<maslo_simulatedGPS> maslo_simulatedGPS::createInstance ( int32_t masla_id,
                                                                            double  masla_initialLatitude,
                                                                            double  masla_initialLongitude,
                                                                            double  masla_latitudeIncrement,
                                                                            double  masla_longitudeIncrement,
                                                                            int32_t masla_updatePeriod )
  {
    return maslo_simulatedGPSPopulation::getSingleton().createInstance( masla_id, masla_initialLatitude, masla_initialLongitude, masla_latitudeIncrement, masla_longitudeIncrement, masla_updatePeriod );
  }

  void maslo_simulatedGPS::deleteInstance ( )
  {
    maslo_simulatedGPSPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_simulatedGPS>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_simulatedGPS::getPopulationSize ( )
  {
    return maslo_simulatedGPSPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_simulatedGPS> > maslo_simulatedGPS::findAll ( )
  {
    return maslo_simulatedGPSPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_simulatedGPS> maslo_simulatedGPS::findOne ( )
  {
    return maslo_simulatedGPSPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_simulatedGPS> maslo_simulatedGPS::findOnly ( )
  {
    return maslo_simulatedGPSPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&           stream,
                               const maslo_simulatedGPS& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_initialLatitude();
    stream << ",";
    stream << obj.get_masla_initialLongitude();
    stream << ",";
    stream << obj.get_masla_latitudeIncrement();
    stream << ",";
    stream << obj.get_masla_longitudeIncrement();
    stream << ",";
    stream << obj.get_masla_updatePeriod();
    stream << ")";
    return stream;
  }

}
