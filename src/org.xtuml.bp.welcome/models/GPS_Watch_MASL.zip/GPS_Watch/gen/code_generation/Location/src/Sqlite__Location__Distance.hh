//
// File: Sqlite__Location__Distance.hh
//
#ifndef Sqlite_Location_Distance_hh
#define Sqlite_Location_Distance_hh

#include "__Location__Distance.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_Distance
      : public ::masld_Location::maslo_Distance
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_Distance ( ::SWA::IdType architectureId );
        maslo_Distance ( ::SWA::IdType architectureId,
                         int32_t       masla_id,
                         double        masla_kmPerDegree );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_kmPerDegree ( double value )
        {
          this->masla_kmPerDegree = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual double get_masla_kmPerDegree ( ) const { return masla_kmPerDegree; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        double masla_kmPerDegree;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Location_Distance_hh
