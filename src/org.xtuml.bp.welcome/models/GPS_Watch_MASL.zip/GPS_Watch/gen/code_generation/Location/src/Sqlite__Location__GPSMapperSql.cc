//
// File: Sqlite__Location__GPSMapperSql.cc
//
#include "Sqlite__Location__GPS.hh"
#include "Sqlite__Location__GPSMapperSql.hh"
#include "__Location__GPS.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Location_GPS(   architecture_id  INTEGER ,   masla_timer INTEGER,   masla_currentLatitude REAL,   masla_currentLongitude REAL,   masla_motionSegments INTEGER,   masla_id INTEGER,   CurrentState INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Location_GPS", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Location
  {
    maslo_GPSSqlGenerator::maslo_GPSSqlGenerator ( )
      : tableName("S_Location_GPS"),
        objectName("GPS"),
        insertStatement("INSERT INTO S_Location_GPS VALUES(:1,:2,:3,:4,:5,:6,:7);"),
        updateStatement("UPDATE S_Location_GPS SET masla_timer = :2  , masla_currentLatitude = :3  , masla_currentLongitude = :4  , masla_motionSegments = :5  , masla_id = :6  , CurrentState = :7  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Location_GPS WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_GPSSqlGenerator::~maslo_GPSSqlGenerator ( )
    {
    }

    void maslo_GPSSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["timer"] = ::std::string( "masla_timer" );
      columnNameMapper["currentLatitude"] = ::std::string( "masla_currentLatitude" );
      columnNameMapper["currentLongitude"] = ::std::string( "masla_currentLongitude" );
      columnNameMapper["motionSegments"] = ::std::string( "masla_motionSegments" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["CurrentState"] = ::std::string( "CurrentState" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_GPSSqlGenerator::getDomainName ( ) const
    {
      return "Location";
    }

    const ::std::string& maslo_GPSSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_GPSSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_GPSSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_GPSSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_GPSSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                           int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Location_GPS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GPSSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GPSSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_GPSSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                           int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Location_GPS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GPSSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GPSSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_GPSSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Location_GPS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GPSSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GPSSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_GPSSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_GPSSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_timer(), object.getChecked()->get_masla_currentLatitude(), object.getChecked()->get_masla_currentLongitude(), object.getChecked()->get_masla_motionSegments(), object.getChecked()->get_masla_id(), object->getCurrentState() ) );
    }

    void maslo_GPSSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_timer(), object.getChecked()->get_masla_currentLatitude(), object.getChecked()->get_masla_currentLongitude(), object.getChecked()->get_masla_motionSegments(), object.getChecked()->get_masla_id(), object->getCurrentState() ) );
    }

    void maslo_GPSSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_GPSSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_GPSSqlGenerator::executeSelect ( CacheType&             cache,
                                                const ::SQL::Criteria& criteria,
                                                PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("GPS::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "GPS::executeSelect", compile_result, query );
        database.checkColumnCount( "GPS::executeSelect", sqlite3_column_count( ppStmt ), 7, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_GPS(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t timer = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_timer( timer );

            double currentLatitude = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_currentLatitude( currentLatitude );

            double currentLongitude = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_currentLongitude( currentLongitude );

            int32_t motionSegments = sqlite3_column_int( ppStmt, 4 );
            currentObject->set_masla_motionSegments( motionSegments );

            int32_t id = sqlite3_column_int( ppStmt, 5 );
            currentObject->set_masla_id( id );

            int32_t currentState = sqlite3_column_int( ppStmt, 6 );
            currentObject->setCurrentState( static_cast< ::masld_Location::maslo_GPS::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_GPSSqlGenerator::executeSelect ( CacheType&             cache,
                                                const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("GPS::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "GPS::executeSelect", compile_result, query );
        database.checkColumnCount( "GPS::executeSelect", sqlite3_column_count( ppStmt ), 7, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_GPS(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t timer = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_timer( timer );

            double currentLatitude = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_currentLatitude( currentLatitude );

            double currentLongitude = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_currentLongitude( currentLongitude );

            int32_t motionSegments = sqlite3_column_int( ppStmt, 4 );
            currentObject->set_masla_motionSegments( motionSegments );

            int32_t id = sqlite3_column_int( ppStmt, 5 );
            currentObject->set_masla_id( id );

            int32_t currentState = sqlite3_column_int( ppStmt, 6 );
            currentObject->setCurrentState( static_cast< ::masld_Location::maslo_GPS::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
