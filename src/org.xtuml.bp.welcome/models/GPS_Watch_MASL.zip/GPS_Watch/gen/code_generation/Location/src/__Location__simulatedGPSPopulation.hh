//
// File: __Location__simulatedGPSPopulation.hh
//
#ifndef _Location_simulated_GPS_Population_hh
#define _Location_simulated_GPS_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  class maslo_simulatedGPS;
  class maslo_simulatedGPSPopulation
    : public ::SWA::DynamicSingleton<maslo_simulatedGPSPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_simulatedGPS> createInstance ( int32_t masla_id,
                                                                    double  masla_initialLatitude,
                                                                    double  masla_initialLongitude,
                                                                    double  masla_latitudeIncrement,
                                                                    double  masla_longitudeIncrement,
                                                                    int32_t masla_updatePeriod ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_simulatedGPS> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_simulatedGPS> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_simulatedGPS> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_simulatedGPS> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_simulatedGPS> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_simulatedGPSPopulation ( );
      virtual ~maslo_simulatedGPSPopulation ( );


    // Prevent copy
    private:
      maslo_simulatedGPSPopulation ( const maslo_simulatedGPSPopulation& rhs );
      maslo_simulatedGPSPopulation& operator= ( const maslo_simulatedGPSPopulation& rhs );


  };
}
#endif // _Location_simulated_GPS_Population_hh
