//
// File: Transient__Location__GPSPopulation.hh
//
#ifndef Transient_Location_GPS_Population_hh
#define Transient_Location_GPS_Population_hh

#include "__Location__GPS.hh"
#include "__Location__GPSPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Location
  {
    class maslo_GPSPopulation
      : public TransientPopulation< ::masld_Location::maslo_GPS,::masld_Location::maslo_GPSPopulation>
    {

      // Instance Creation
      private:
        maslo_GPSPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                double                                 masla_currentLatitude,
                                                                                double                                 masla_currentLongitude,
                                                                                int32_t                                masla_motionSegments,
                                                                                int32_t                                masla_id,
                                                                                ::masld_Location::maslo_GPS::Type      currentState );


      // Singleton Registration
      public:
        static maslo_GPSPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Location::maslo_GPS> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Location_GPS_Population_hh
