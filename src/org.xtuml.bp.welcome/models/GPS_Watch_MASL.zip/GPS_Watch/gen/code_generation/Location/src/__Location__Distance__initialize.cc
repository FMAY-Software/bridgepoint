//
// File: __Location__Distance__initialize.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__Distance.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Location
{
  void maslo_Distance::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Distance, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // distance : instance of Distance;
        ::SWA::ObjectPtr<maslo_Distance> maslv_distance;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_distance(0, maslv_distance);

        // distance := find_one Distance ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_distance = findOne();
        }

        // if (null = distance) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_distance )
          {

            // distance := create Distance (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_distance = createInstance( 1ll, double() );
            }

            // distance.kmPerDegree := 111.32;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_distance->set_masla_kmPerDegree( 111.32 );
            }
          }
        }
      }
    }
  }

}
