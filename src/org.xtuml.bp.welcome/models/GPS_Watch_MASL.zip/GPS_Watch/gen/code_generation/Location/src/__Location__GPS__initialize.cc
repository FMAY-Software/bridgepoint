//
// File: __Location__GPS__initialize.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__GPS.hh"
#include "__Location__simulatedGPS.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Location
{
  void maslo_GPS::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_GPS, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // gps : instance of GPS;
        ::SWA::ObjectPtr<maslo_GPS> maslv_gps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_gps(0, maslv_gps);

        // simgps : instance of simulatedGPS;
        ::SWA::ObjectPtr<maslo_simulatedGPS> maslv_simgps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_simgps(1, maslv_simgps);

        // gps := find_one GPS ();
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_gps = findOne();
        }

        // if (null = gps) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          if ( ::SWA::Null == maslv_gps )
          {

            // gps := create GPS (
            //               id => 1 ,
            // Current_State => idle);
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              maslv_gps = createInstance( ::SWA::EventTimers::getInstance().createTimer(), double(), double(), int32_t(), 1ll, maslst_idle );
            }

            // gps.motionSegments := 0;
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              maslv_gps->set_masla_motionSegments( 0ll );
            }

            // simulatedGPS.initialize()
            {
              ::SWA::Stack::ExecutingStatement statement(13);
              maslo_simulatedGPS::masls_initialize();
            }

            // simgps := find_one simulatedGPS ();
            {
              ::SWA::Stack::ExecutingStatement statement(14);
              maslv_simgps = maslo_simulatedGPS::findOne();
            }

            // gps.currentLatitude := simgps.initialLatitude;
            {
              ::SWA::Stack::ExecutingStatement statement(15);
              maslv_gps->set_masla_currentLatitude( maslv_simgps->get_masla_initialLatitude() );
            }

            // gps.currentLongitude := simgps.initialLongitude;
            {
              ::SWA::Stack::ExecutingStatement statement(16);
              maslv_gps->set_masla_currentLongitude( maslv_simgps->get_masla_initialLongitude() );
            }
          }
        }
      }
    }
  }

}
