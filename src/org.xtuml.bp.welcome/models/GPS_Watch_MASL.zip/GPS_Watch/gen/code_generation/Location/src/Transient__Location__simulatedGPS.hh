//
// File: Transient__Location__simulatedGPS.hh
//
#ifndef Transient_Location_simulated_GPS_hh
#define Transient_Location_simulated_GPS_hh

#include "__Location__simulatedGPS.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_Location
  {
    class maslo_simulatedGPS
      : public ::masld_Location::maslo_simulatedGPS
    {

      // Constructors and Destructors
      public:
        maslo_simulatedGPS ( int32_t masla_id,
                             double  masla_initialLatitude,
                             double  masla_initialLongitude,
                             double  masla_latitudeIncrement,
                             double  masla_longitudeIncrement,
                             int32_t masla_updatePeriod );


      // Setters for each object attribute
      public:
        virtual void set_masla_initialLatitude ( double value ) { this->masla_initialLatitude = value; }
        virtual void set_masla_initialLongitude ( double value ) { this->masla_initialLongitude = value; }
        virtual void set_masla_latitudeIncrement ( double value ) { this->masla_latitudeIncrement = value; }
        virtual void set_masla_longitudeIncrement ( double value ) { this->masla_longitudeIncrement = value; }
        virtual void set_masla_updatePeriod ( int32_t value ) { this->masla_updatePeriod = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual double get_masla_initialLatitude ( ) const { return masla_initialLatitude; }
        virtual double get_masla_initialLongitude ( ) const { return masla_initialLongitude; }
        virtual double get_masla_latitudeIncrement ( ) const { return masla_latitudeIncrement; }
        virtual double get_masla_longitudeIncrement ( ) const { return masla_longitudeIncrement; }
        virtual int32_t get_masla_updatePeriod ( ) const { return masla_updatePeriod; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        double masla_initialLatitude;
        double masla_initialLongitude;
        double masla_latitudeIncrement;
        double masla_longitudeIncrement;
        int32_t masla_updatePeriod;


    };
  }
}
#endif // Transient_Location_simulated_GPS_hh
