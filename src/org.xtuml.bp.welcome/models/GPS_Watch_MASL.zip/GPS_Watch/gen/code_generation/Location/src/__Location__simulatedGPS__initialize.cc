//
// File: __Location__simulatedGPS__initialize.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__simulatedGPS.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Location
{
  void maslo_simulatedGPS::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_simulatedGPS, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // simgps : instance of simulatedGPS;
        ::SWA::ObjectPtr<maslo_simulatedGPS> maslv_simgps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_simgps(0, maslv_simgps);

        // simgps := find_one simulatedGPS ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_simgps = findOne();
        }

        // if (null = simgps) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_simgps )
          {

            // simgps := create simulatedGPS (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_simgps = createInstance( 1ll, double(), double(), double(), double(), int32_t() );
            }

            // simgps.initialLatitude := 32.432237;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_simgps->set_masla_initialLatitude( 32.432237 );
            }

            // simgps.initialLongitude := (- 110.812283);
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              maslv_simgps->set_masla_initialLongitude( -110.812283 );
            }

            // simgps.latitudeIncrement := 0.00001;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              maslv_simgps->set_masla_latitudeIncrement( 1.0E-5 );
            }

            // simgps.longitudeIncrement := 0.00002;
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              maslv_simgps->set_masla_longitudeIncrement( 2.0E-5 );
            }

            // simgps.updatePeriod := 1000000;
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              maslv_simgps->set_masla_updatePeriod( 1000000ll );
            }
          }
        }
      }
    }
  }

}
