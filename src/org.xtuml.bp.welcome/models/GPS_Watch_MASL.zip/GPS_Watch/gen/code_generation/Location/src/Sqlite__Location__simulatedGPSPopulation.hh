//
// File: Sqlite__Location__simulatedGPSPopulation.hh
//
#ifndef Sqlite_Location_simulated_GPS_Population_hh
#define Sqlite_Location_simulated_GPS_Population_hh

#include "Sqlite__Location__simulatedGPS.hh"
#include "Sqlite__Location__simulatedGPSMapper.hh"
#include "__Location__simulatedGPS.hh"
#include "__Location__simulatedGPSPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_simulatedGPSPopulation
      : public ::SQL::SqlPopulation< ::masld_Location::maslo_simulatedGPS,maslo_simulatedGPS,maslo_simulatedGPSMapper,::masld_Location::maslo_simulatedGPSPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_simulatedGPSPopulation ( );
        ~maslo_simulatedGPSPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> createInstance ( int32_t masla_id,
                                                                                         double  masla_initialLatitude,
                                                                                         double  masla_initialLongitude,
                                                                                         double  masla_latitudeIncrement,
                                                                                         double  masla_longitudeIncrement,
                                                                                         int32_t masla_updatePeriod );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_simulatedGPSPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_Location_simulated_GPS_Population_hh
