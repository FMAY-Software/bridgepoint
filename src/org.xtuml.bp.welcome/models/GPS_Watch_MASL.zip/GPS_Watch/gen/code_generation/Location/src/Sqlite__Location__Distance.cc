//
// File: Sqlite__Location__Distance.cc
//
#include "Sqlite__Location__Distance.hh"
#include "Sqlite__Location__DistancePopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_Distance::maslo_Distance ( ::SWA::IdType architectureId,
                                     int32_t       masla_id,
                                     double        masla_kmPerDegree )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_kmPerDegree(masla_kmPerDegree),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_Distance::maslo_Distance ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_kmPerDegree(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_Distance::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_Distance::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_DistancePopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_Distance::PrimaryKeyType maslo_Distance::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_Distance::IndexKeyType_1 maslo_Distance::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
