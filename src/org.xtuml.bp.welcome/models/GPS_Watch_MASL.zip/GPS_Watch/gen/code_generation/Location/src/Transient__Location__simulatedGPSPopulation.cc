//
// File: Transient__Location__simulatedGPSPopulation.cc
//
#include "Transient__Location__simulatedGPS.hh"
#include "Transient__Location__simulatedGPSPopulation.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Location
  {
    maslo_simulatedGPSPopulation::maslo_simulatedGPSPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> maslo_simulatedGPSPopulation::createInstance ( int32_t masla_id,
                                                                                                           double  masla_initialLatitude,
                                                                                                           double  masla_initialLongitude,
                                                                                                           double  masla_latitudeIncrement,
                                                                                                           double  masla_longitudeIncrement,
                                                                                                           int32_t masla_updatePeriod )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance(new maslo_simulatedGPS(  masla_id,
                         masla_initialLatitude,
                         masla_initialLongitude,
                         masla_latitudeIncrement,
                         masla_longitudeIncrement,
                         masla_updatePeriod ));
      addInstance( instance );
      return instance;
    }

    void maslo_simulatedGPSPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_simulatedGPSPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_simulatedGPSPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_simulatedGPSPopulation& maslo_simulatedGPSPopulation::getPopulation ( )
    {
      static maslo_simulatedGPSPopulation population;
      return population;
    }

    bool maslo_simulatedGPSPopulation::registered = maslo_simulatedGPSPopulation::registerSingleton( &maslo_simulatedGPSPopulation::getPopulation );

  }
}
