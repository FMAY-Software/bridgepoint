//
// File: Sqlite__Location__GPSPopulation.cc
//
#include "Sqlite__Location__GPSPopulation.hh"
#include "__Location__GPS.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_GPSPopulation::maslo_GPSPopulation ( )
    {
    }

    maslo_GPSPopulation::~maslo_GPSPopulation ( )
    {
    }

    void maslo_GPSPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_GPSPopulation& maslo_GPSPopulation::getPopulation ( )
    {
      static maslo_GPSPopulation population;
      return population;
    }

    bool maslo_GPSPopulation::registered = maslo_GPSPopulation::registerSingleton( &maslo_GPSPopulation::getPopulation );

    ::boost::signals2::connection maslo_GPSPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_GPSPopulation::initialise, ::boost::bind( &maslo_GPSPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> maslo_GPSPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> > maslo_GPSPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> maslo_GPSPopulation::createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                         double                                 masla_currentLatitude,
                                                                                         double                                 masla_currentLongitude,
                                                                                         int32_t                                masla_motionSegments,
                                                                                         int32_t                                masla_id,
                                                                                         ::masld_Location::maslo_GPS::Type      currentState )
    {
      return mapper->createInstance( masla_timer, masla_currentLatitude, masla_currentLongitude, masla_motionSegments, masla_id, currentState );
    }

    void maslo_GPSPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
