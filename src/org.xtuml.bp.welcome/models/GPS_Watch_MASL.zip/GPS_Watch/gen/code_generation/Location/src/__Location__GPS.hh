//
// File: __Location__GPS.hh
//
#ifndef _Location_GPS_hh
#define _Location_GPS_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  class maslo_GPS;
  class maslo_GPS
  {

    public:
      enum Type {  maslst_idle,
                   maslst_locating,
                   maslst_registeringListener,
                   maslst_unregistering };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_GPS> createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                          double                                 masla_currentLatitude,
                                                          double                                 masla_currentLongitude,
                                                          int32_t                                masla_motionSegments,
                                                          int32_t                                masla_id,
                                                          Type                                   currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_GPS> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) = 0;
      virtual void set_masla_currentLatitude ( double value ) = 0;
      virtual void set_masla_currentLongitude ( double value ) = 0;
      virtual void set_masla_motionSegments ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const = 0;
      virtual double get_masla_currentLatitude ( ) const = 0;
      virtual double get_masla_currentLongitude ( ) const = 0;
      virtual int32_t get_masla_motionSegments ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_GPS> > findAll ( );
      static ::SWA::ObjectPtr<maslo_GPS> findOne ( );
      static ::SWA::ObjectPtr<maslo_GPS> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_GPS ( );
      virtual ~maslo_GPS ( );


    // Prevent copy
    private:
      maslo_GPS ( const maslo_GPS& rhs );
      maslo_GPS& operator= ( const maslo_GPS& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_idle ( );
      void state_maslst_locating ( );
      void state_maslst_registeringListener ( );
      void state_maslst_unregistering ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_GPS_maslev_tick ( int           sourceObj = -1,
                                                                        ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_GPS_maslev_registeringComplete ( int           sourceObj = -1,
                                                                                       ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_GPS_maslev_registerListener ( int           sourceObj = -1,
                                                                                    ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_GPS_maslev_unregisterListener ( int           sourceObj = -1,
                                                                                      ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_GPS_maslev_unregisterComplete ( int           sourceObj = -1,
                                                                                      ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_GPS_maslev_tick ( ::SWA::IdType id );
      static void consume_maslo_GPS_maslev_registeringComplete ( ::SWA::IdType id );
      static void consume_maslo_GPS_maslev_registerListener ( ::SWA::IdType id );
      static void consume_maslo_GPS_maslev_unregisterListener ( ::SWA::IdType id );
      static void consume_maslo_GPS_maslev_unregisterComplete ( ::SWA::IdType id );


    // Process Events
    public:
      void process_maslo_GPS_maslev_tick ( );
      void process_maslo_GPS_maslev_registeringComplete ( );
      void process_maslo_GPS_maslev_registerListener ( );
      void process_maslo_GPS_maslev_unregisterListener ( );
      void process_maslo_GPS_maslev_unregisterComplete ( );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_idle,
                       stateId_maslst_locating,
                       stateId_maslst_registeringListener,
                       stateId_maslst_unregistering };
      enum EventIds {  eventId_maslo_GPS_maslev_tick,
                       eventId_maslo_GPS_maslev_registeringComplete,
                       eventId_maslo_GPS_maslev_registerListener,
                       eventId_maslo_GPS_maslev_unregisterListener,
                       eventId_maslo_GPS_maslev_unregisterComplete };
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&  stream,
                               const maslo_GPS& obj );
}
#endif // _Location_GPS_hh
