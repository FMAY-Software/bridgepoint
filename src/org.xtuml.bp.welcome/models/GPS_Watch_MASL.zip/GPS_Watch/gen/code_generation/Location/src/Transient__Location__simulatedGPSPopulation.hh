//
// File: Transient__Location__simulatedGPSPopulation.hh
//
#ifndef Transient_Location_simulated_GPS_Population_hh
#define Transient_Location_simulated_GPS_Population_hh

#include "__Location__simulatedGPS.hh"
#include "__Location__simulatedGPSPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Location
  {
    class maslo_simulatedGPSPopulation
      : public TransientPopulation< ::masld_Location::maslo_simulatedGPS,::masld_Location::maslo_simulatedGPSPopulation>
    {

      // Instance Creation
      private:
        maslo_simulatedGPSPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> createInstance ( int32_t masla_id,
                                                                                         double  masla_initialLatitude,
                                                                                         double  masla_initialLongitude,
                                                                                         double  masla_latitudeIncrement,
                                                                                         double  masla_longitudeIncrement,
                                                                                         int32_t masla_updatePeriod );


      // Singleton Registration
      public:
        static maslo_simulatedGPSPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Location_simulated_GPS_Population_hh
