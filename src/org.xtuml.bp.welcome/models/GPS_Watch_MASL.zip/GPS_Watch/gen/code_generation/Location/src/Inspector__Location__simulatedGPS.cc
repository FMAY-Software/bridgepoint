//
// File: Inspector__Location__simulatedGPS.cc
//
#include "Inspector__Location__simulatedGPS.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Location
  {
    namespace maslo_simulatedGPS
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Location::maslo_simulatedGPS::masls_initialize(); }


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write simgps
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> >();
              break;

          }

        }
      }

      maslo_simulatedGPSHandler::maslo_simulatedGPSHandler ( )
      {
        registerServiceHandler( ::masld_Location::maslo_simulatedGPS::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Location::maslo_simulatedGPS> ( const ::masld_Location::maslo_simulatedGPS& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_id() );
    write( instance.get_masla_initialLatitude() );
    write( instance.get_masla_initialLongitude() );
    write( instance.get_masla_latitudeIncrement() );
    write( instance.get_masla_longitudeIncrement() );
    write( instance.get_masla_updatePeriod() );
  }

  namespace masld_Location
  {
    namespace maslo_simulatedGPS
    {
      void maslo_simulatedGPSHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_id;
        double masla_initialLatitude;
        double masla_initialLongitude;
        double masla_latitudeIncrement;
        double masla_longitudeIncrement;
        int32_t masla_updatePeriod;
        channel >> masla_id >> masla_initialLatitude >> masla_initialLongitude >> masla_latitudeIncrement >> masla_longitudeIncrement >> masla_updatePeriod;
        ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance = ::masld_Location::maslo_simulatedGPS::createInstance( masla_id, masla_initialLatitude, masla_initialLongitude, masla_latitudeIncrement, masla_longitudeIncrement, masla_updatePeriod );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_simulatedGPSHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> > ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Location::maslo_simulatedGPS::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Location
  {
    namespace maslo_simulatedGPS
    {
      void maslo_simulatedGPSHandler::writeRelatedInstances ( CommunicationChannel&                                   channel,
                                                              ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance,
                                                              int                                                     relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
