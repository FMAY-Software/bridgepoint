//
// File: Inspector__Location__Distance.hh
//
#ifndef Inspector_Location_Distance_hh
#define Inspector_Location_Distance_hh

#include "__Location__Distance.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Location
  {
    namespace maslo_Distance
    {
      class maslo_DistanceHandler
        : public ObjectHandler< ::masld_Location::maslo_Distance>
      {

        // Constructors
        public:
          maslo_DistanceHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                               channel,
                                       ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance,
                                       int                                                 relId ) const;


      };
    }
  }
}
#endif // Inspector_Location_Distance_hh
