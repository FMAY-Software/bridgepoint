//
// File: Sqlite__Location__simulatedGPSPopulation.cc
//
#include "Sqlite__Location__simulatedGPSPopulation.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_simulatedGPSPopulation::maslo_simulatedGPSPopulation ( )
    {
    }

    maslo_simulatedGPSPopulation::~maslo_simulatedGPSPopulation ( )
    {
    }

    void maslo_simulatedGPSPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_simulatedGPSPopulation& maslo_simulatedGPSPopulation::getPopulation ( )
    {
      static maslo_simulatedGPSPopulation population;
      return population;
    }

    bool maslo_simulatedGPSPopulation::registered = maslo_simulatedGPSPopulation::registerSingleton( &maslo_simulatedGPSPopulation::getPopulation );

    ::boost::signals2::connection maslo_simulatedGPSPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_simulatedGPSPopulation::initialise, ::boost::bind( &maslo_simulatedGPSPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> maslo_simulatedGPSPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> > maslo_simulatedGPSPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> maslo_simulatedGPSPopulation::createInstance ( int32_t masla_id,
                                                                                                           double  masla_initialLatitude,
                                                                                                           double  masla_initialLongitude,
                                                                                                           double  masla_latitudeIncrement,
                                                                                                           double  masla_longitudeIncrement,
                                                                                                           int32_t masla_updatePeriod )
    {
      return mapper->createInstance( masla_id, masla_initialLatitude, masla_initialLongitude, masla_latitudeIncrement, masla_longitudeIncrement, masla_updatePeriod );
    }

    void maslo_simulatedGPSPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
