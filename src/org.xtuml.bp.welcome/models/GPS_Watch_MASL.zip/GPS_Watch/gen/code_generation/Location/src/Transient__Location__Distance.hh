//
// File: Transient__Location__Distance.hh
//
#ifndef Transient_Location_Distance_hh
#define Transient_Location_Distance_hh

#include "__Location__Distance.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_Location
  {
    class maslo_Distance
      : public ::masld_Location::maslo_Distance
    {

      // Constructors and Destructors
      public:
        maslo_Distance ( int32_t masla_id,
                         double  masla_kmPerDegree );


      // Setters for each object attribute
      public:
        virtual void set_masla_kmPerDegree ( double value ) { this->masla_kmPerDegree = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual double get_masla_kmPerDegree ( ) const { return masla_kmPerDegree; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        double masla_kmPerDegree;


    };
  }
}
#endif // Transient_Location_Distance_hh
