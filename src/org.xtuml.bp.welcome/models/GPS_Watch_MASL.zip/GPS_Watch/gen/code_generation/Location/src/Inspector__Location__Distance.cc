//
// File: Inspector__Location__Distance.cc
//
#include "Inspector__Location__Distance.hh"
#include "__Location__Distance.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Location
  {
    namespace maslo_Distance
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Location::maslo_Distance::masls_initialize(); }


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write distance
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> >();
              break;

          }

        }
      }

      maslo_DistanceHandler::maslo_DistanceHandler ( )
      {
        registerServiceHandler( ::masld_Location::maslo_Distance::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Location::maslo_Distance> ( const ::masld_Location::maslo_Distance& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_id() );
    write( instance.get_masla_kmPerDegree() );
  }

  namespace masld_Location
  {
    namespace maslo_Distance
    {
      void maslo_DistanceHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_id;
        double masla_kmPerDegree;
        channel >> masla_id >> masla_kmPerDegree;
        ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance = ::masld_Location::maslo_Distance::createInstance( masla_id, masla_kmPerDegree );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_DistanceHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> > ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Location::maslo_Distance::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Location
  {
    namespace maslo_Distance
    {
      void maslo_DistanceHandler::writeRelatedInstances ( CommunicationChannel&                               channel,
                                                          ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance,
                                                          int                                                 relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
