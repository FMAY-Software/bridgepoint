//
// File: __Location__GPS__locating.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__GPS.hh"
#include "__Location__simulatedGPS.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/math.hh"

namespace masld_Location
{
  void maslo_GPS::state_maslst_locating ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_GPS, stateId_maslst_locating);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // simgps : instance of simulatedGPS;
        ::SWA::ObjectPtr<maslo_simulatedGPS> maslv_simgps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_simgps(0, maslv_simgps);

        // simulatedGPS.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslo_simulatedGPS::masls_initialize();
        }

        // simgps := find_one simulatedGPS ();
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_simgps = maslo_simulatedGPS::findOne();
        }

        // if ((this.motionSegments rem 3) = 0) then ...
        // elsif ((this.motionSegments rem 5) = 0) then ...
        // else ...
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          if ( ::SWA::rem( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_motionSegments(), 3ll ) == 0ll )
          {

            // this.currentLongitude := (this.currentLongitude + (simgps.longitudeIncrement * 2));
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_currentLongitude( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_currentLongitude() + maslv_simgps->get_masla_longitudeIncrement() * 2ll );
            }

            // this.currentLatitude := (this.currentLatitude + simgps.latitudeIncrement);
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_currentLatitude( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_currentLatitude() + maslv_simgps->get_masla_latitudeIncrement() );
            }
          }
          else if ( ::SWA::rem( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_motionSegments(), 5ll ) == 0ll )
          {

            // this.currentLongitude := (this.currentLongitude + simgps.longitudeIncrement);
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_currentLongitude( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_currentLongitude() + maslv_simgps->get_masla_longitudeIncrement() );
            }

            // this.currentLatitude := (this.currentLatitude + (simgps.latitudeIncrement * 3));
            {
              ::SWA::Stack::ExecutingStatement statement(12);
              ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_currentLatitude( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_currentLatitude() + maslv_simgps->get_masla_latitudeIncrement() * 3ll );
            }
          }
          else
          {

            // this.currentLongitude := (this.currentLongitude + simgps.longitudeIncrement);
            {
              ::SWA::Stack::ExecutingStatement statement(14);
              ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_currentLongitude( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_currentLongitude() + maslv_simgps->get_masla_longitudeIncrement() );
            }

            // this.currentLatitude := (this.currentLatitude + simgps.latitudeIncrement);
            {
              ::SWA::Stack::ExecutingStatement statement(15);
              ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_currentLatitude( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_currentLatitude() + maslv_simgps->get_masla_latitudeIncrement() );
            }
          }
        }

        // this.motionSegments := (this.motionSegments + 1);
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          ::SWA::ObjectPtr<maslo_GPS>( this )->set_masla_motionSegments( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_motionSegments() + 1ll );
        }
      }
    }
  }

}
