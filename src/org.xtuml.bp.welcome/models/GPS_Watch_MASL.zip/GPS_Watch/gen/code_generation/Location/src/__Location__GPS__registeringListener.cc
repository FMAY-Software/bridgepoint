//
// File: __Location__GPS__registeringListener.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__GPS.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Duration.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Location
{
  void maslo_GPS::state_maslst_registeringListener ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_GPS, stateId_maslst_registeringListener);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // simgps : instance of simulatedGPS;
        ::SWA::ObjectPtr<maslo_simulatedGPS> maslv_simgps;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_simgps(0, maslv_simgps);

        // simulatedGPS.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslo_simulatedGPS::masls_initialize();
        }

        // simgps := find_one simulatedGPS ();
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_simgps = maslo_simulatedGPS::findOne();
        }

        // schedule this.timer generate GPS.tick () to this delay (@PT0.000001S@ * simgps.updatePeriod) delta (@PT0.000001S@ * simgps.updatePeriod);
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          ::SWA::EventTimers::getInstance().scheduleTimer( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_timer(), ::SWA::Duration::fromNanos( 1000ll ) * maslv_simgps->get_masla_updatePeriod() + ::SWA::Timestamp::now(), ::SWA::Duration::fromNanos( 1000ll ) * maslv_simgps->get_masla_updatePeriod(), ::SWA::ObjectPtr<maslo_GPS>( this )->create_maslo_GPS_maslev_tick( objectId_maslo_GPS, getArchitectureId() ) );
        }

        // LOG::LogInfo("Location listener registered.")
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Location listener registered." ) );
        }

        // generate GPS.registeringComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_GPS>( this )->create_maslo_GPS_maslev_registeringComplete( objectId_maslo_GPS, getArchitectureId() ) );
        }
      }
    }
  }

}
