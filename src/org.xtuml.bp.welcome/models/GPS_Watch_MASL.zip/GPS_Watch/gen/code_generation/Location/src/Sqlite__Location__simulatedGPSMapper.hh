//
// File: Sqlite__Location__simulatedGPSMapper.hh
//
#ifndef Sqlite_Location_simulated_GPS_Mapper_hh
#define Sqlite_Location_simulated_GPS_Mapper_hh

#include "Sqlite__Location__simulatedGPS.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_simulatedGPSMapper
      : public ::SQL::ObjectMapper< ::masld_Location::maslo_simulatedGPS,maslo_simulatedGPS>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> createInstance ( int32_t masla_id,
                                                                                         double  masla_initialLatitude,
                                                                                         double  masla_initialLongitude,
                                                                                         double  masla_latitudeIncrement,
                                                                                         double  masla_longitudeIncrement,
                                                                                         int32_t masla_updatePeriod );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_simulatedGPSMapper ( );
        virtual ~maslo_simulatedGPSMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_simulatedGPS::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Location_simulated_GPS_Mapper_hh
