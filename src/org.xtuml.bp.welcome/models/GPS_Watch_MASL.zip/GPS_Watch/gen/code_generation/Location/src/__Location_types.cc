//
// File: __Location_types.cc
//
