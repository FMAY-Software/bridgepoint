//
// File: __Location.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "swa/Domain.hh"

namespace masld_Location
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
