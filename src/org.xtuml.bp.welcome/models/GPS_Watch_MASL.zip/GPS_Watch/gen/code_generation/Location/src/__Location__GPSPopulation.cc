//
// File: __Location__GPSPopulation.cc
//
#include "__Location__GPSPopulation.hh"

namespace masld_Location
{
  maslo_GPSPopulation::maslo_GPSPopulation ( )
  {
  }

  maslo_GPSPopulation::~maslo_GPSPopulation ( )
  {
  }

}
