//
// File: __Location__GPS.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__GPS.hh"
#include "__Location__GPSEvents.hh"
#include "__Location__GPSPopulation.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  ::SWA::ObjectPtr<maslo_GPS> maslo_GPS::getInstance ( ::SWA::IdType id )
  {
    return maslo_GPSPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_GPS::getNextArchId ( )
  {
    return maslo_GPSPopulation::getSingleton().getNextArchId();
  }

  void maslo_GPS::process_maslo_GPS_maslev_tick ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_locating:
      {
        state_maslst_locating();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_GPS, getArchitectureId(), getCurrentState(), maslst_locating );
        setCurrentState( maslst_locating );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_GPS, eventId_maslo_GPS_maslev_tick ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_GPS ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_GPS, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_GPS::create_maslo_GPS_maslev_tick ( int           sourceObj,
                                                                               ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_GPS_maslev_tick());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_GPS::consume_maslo_GPS_maslev_tick ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_GPS> instance = getInstance( id );
    if ( instance ) instance->process_maslo_GPS_maslev_tick();
  }

  int Event_maslo_GPS_maslev_tick::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_GPS_maslev_tick::getObjectId ( ) const
  {
    return objectId_maslo_GPS;
  }

  int Event_maslo_GPS_maslev_tick::getEventId ( ) const
  {
    return maslo_GPS::eventId_maslo_GPS_maslev_tick;
  }

  Event_maslo_GPS_maslev_tick::Event_maslo_GPS_maslev_tick ( )
  {
  }

  void Event_maslo_GPS_maslev_tick::invoke ( ) const
  {
    maslo_GPS::consume_maslo_GPS_maslev_tick( getDestInstanceId() );
  }

  void maslo_GPS::process_maslo_GPS_maslev_registeringComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_registeringListener:
      {
        state_maslst_locating();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_GPS, getArchitectureId(), getCurrentState(), maslst_locating );
        setCurrentState( maslst_locating );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_GPS, eventId_maslo_GPS_maslev_registeringComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_GPS ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_GPS, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_GPS::create_maslo_GPS_maslev_registeringComplete ( int           sourceObj,
                                                                                              ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_GPS_maslev_registeringComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_GPS::consume_maslo_GPS_maslev_registeringComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_GPS> instance = getInstance( id );
    if ( instance ) instance->process_maslo_GPS_maslev_registeringComplete();
  }

  int Event_maslo_GPS_maslev_registeringComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_GPS_maslev_registeringComplete::getObjectId ( ) const
  {
    return objectId_maslo_GPS;
  }

  int Event_maslo_GPS_maslev_registeringComplete::getEventId ( ) const
  {
    return maslo_GPS::eventId_maslo_GPS_maslev_registeringComplete;
  }

  Event_maslo_GPS_maslev_registeringComplete::Event_maslo_GPS_maslev_registeringComplete ( )
  {
  }

  void Event_maslo_GPS_maslev_registeringComplete::invoke ( ) const
  {
    maslo_GPS::consume_maslo_GPS_maslev_registeringComplete( getDestInstanceId() );
  }

  void maslo_GPS::process_maslo_GPS_maslev_registerListener ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_idle:
      {
        state_maslst_registeringListener();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_GPS, getArchitectureId(), getCurrentState(), maslst_registeringListener );
        setCurrentState( maslst_registeringListener );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_GPS, eventId_maslo_GPS_maslev_registerListener ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_GPS ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_GPS, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_GPS::create_maslo_GPS_maslev_registerListener ( int           sourceObj,
                                                                                           ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_GPS_maslev_registerListener());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_GPS::consume_maslo_GPS_maslev_registerListener ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_GPS> instance = getInstance( id );
    if ( instance ) instance->process_maslo_GPS_maslev_registerListener();
  }

  int Event_maslo_GPS_maslev_registerListener::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_GPS_maslev_registerListener::getObjectId ( ) const
  {
    return objectId_maslo_GPS;
  }

  int Event_maslo_GPS_maslev_registerListener::getEventId ( ) const
  {
    return maslo_GPS::eventId_maslo_GPS_maslev_registerListener;
  }

  Event_maslo_GPS_maslev_registerListener::Event_maslo_GPS_maslev_registerListener ( )
  {
  }

  void Event_maslo_GPS_maslev_registerListener::invoke ( ) const
  {
    maslo_GPS::consume_maslo_GPS_maslev_registerListener( getDestInstanceId() );
  }

  void maslo_GPS::process_maslo_GPS_maslev_unregisterListener ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_locating:
      {
        state_maslst_unregistering();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_GPS, getArchitectureId(), getCurrentState(), maslst_unregistering );
        setCurrentState( maslst_unregistering );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_GPS, eventId_maslo_GPS_maslev_unregisterListener ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_GPS ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_GPS, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_GPS::create_maslo_GPS_maslev_unregisterListener ( int           sourceObj,
                                                                                             ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_GPS_maslev_unregisterListener());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_GPS::consume_maslo_GPS_maslev_unregisterListener ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_GPS> instance = getInstance( id );
    if ( instance ) instance->process_maslo_GPS_maslev_unregisterListener();
  }

  int Event_maslo_GPS_maslev_unregisterListener::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_GPS_maslev_unregisterListener::getObjectId ( ) const
  {
    return objectId_maslo_GPS;
  }

  int Event_maslo_GPS_maslev_unregisterListener::getEventId ( ) const
  {
    return maslo_GPS::eventId_maslo_GPS_maslev_unregisterListener;
  }

  Event_maslo_GPS_maslev_unregisterListener::Event_maslo_GPS_maslev_unregisterListener ( )
  {
  }

  void Event_maslo_GPS_maslev_unregisterListener::invoke ( ) const
  {
    maslo_GPS::consume_maslo_GPS_maslev_unregisterListener( getDestInstanceId() );
  }

  void maslo_GPS::process_maslo_GPS_maslev_unregisterComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_unregistering:
      {
        state_maslst_idle();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_GPS, getArchitectureId(), getCurrentState(), maslst_idle );
        setCurrentState( maslst_idle );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_GPS, eventId_maslo_GPS_maslev_unregisterComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_GPS ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_GPS, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_GPS::create_maslo_GPS_maslev_unregisterComplete ( int           sourceObj,
                                                                                             ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_GPS_maslev_unregisterComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_GPS::consume_maslo_GPS_maslev_unregisterComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_GPS> instance = getInstance( id );
    if ( instance ) instance->process_maslo_GPS_maslev_unregisterComplete();
  }

  int Event_maslo_GPS_maslev_unregisterComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_GPS_maslev_unregisterComplete::getObjectId ( ) const
  {
    return objectId_maslo_GPS;
  }

  int Event_maslo_GPS_maslev_unregisterComplete::getEventId ( ) const
  {
    return maslo_GPS::eventId_maslo_GPS_maslev_unregisterComplete;
  }

  Event_maslo_GPS_maslev_unregisterComplete::Event_maslo_GPS_maslev_unregisterComplete ( )
  {
  }

  void Event_maslo_GPS_maslev_unregisterComplete::invoke ( ) const
  {
    maslo_GPS::consume_maslo_GPS_maslev_unregisterComplete( getDestInstanceId() );
  }

  maslo_GPS::maslo_GPS ( )
    : isDeletedFlag()
  {
  }

  maslo_GPS::~maslo_GPS ( )
  {
  }

  ::SWA::ObjectPtr<maslo_GPS> maslo_GPS::createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                          double                                 masla_currentLatitude,
                                                          double                                 masla_currentLongitude,
                                                          int32_t                                masla_motionSegments,
                                                          int32_t                                masla_id,
                                                          Type                                   currentState )
  {
    return maslo_GPSPopulation::getSingleton().createInstance( masla_timer, masla_currentLatitude, masla_currentLongitude, masla_motionSegments, masla_id, currentState );
  }

  void maslo_GPS::deleteInstance ( )
  {
    maslo_GPSPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_GPS>( this ) );
    ::SWA::EventTimers::getInstance().deleteTimer( get_masla_timer() );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_GPS::getPopulationSize ( )
  {
    return maslo_GPSPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_GPS> > maslo_GPS::findAll ( )
  {
    return maslo_GPSPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_GPS> maslo_GPS::findOne ( )
  {
    return maslo_GPSPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_GPS> maslo_GPS::findOnly ( )
  {
    return maslo_GPSPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&  stream,
                               const maslo_GPS& obj )
  {
    stream << "(";
    stream << obj.get_masla_timer();
    stream << ",";
    stream << obj.get_masla_currentLatitude();
    stream << ",";
    stream << obj.get_masla_currentLongitude();
    stream << ",";
    stream << obj.get_masla_motionSegments();
    stream << ",";
    stream << obj.get_masla_id();
    stream << ")";
    return stream;
  }

}
