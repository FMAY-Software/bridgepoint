//
// File: __Location__GPS__idle.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__GPS.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Location
{
  void maslo_GPS::state_maslst_idle ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_GPS, stateId_maslst_idle);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Locating::GPS::Idle")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Locating::GPS::Idle" ) );
        }
      }
    }
  }

}
