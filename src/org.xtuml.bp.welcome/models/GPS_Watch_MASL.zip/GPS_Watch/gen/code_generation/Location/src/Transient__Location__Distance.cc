//
// File: Transient__Location__Distance.cc
//
#include "Transient__Location__Distance.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Location
  {
    maslo_Distance::maslo_Distance ( int32_t masla_id,
                                     double  masla_kmPerDegree )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_kmPerDegree(masla_kmPerDegree)
    {
    }

  }
}
