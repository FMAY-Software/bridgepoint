//
// File: __Location__Distance.hh
//
#ifndef _Location_Distance_hh
#define _Location_Distance_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  class maslo_Distance;
  class maslo_Distance
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_Distance> createInstance ( int32_t masla_id,
                                                               double  masla_kmPerDegree );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_Distance> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_kmPerDegree ( double value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual double get_masla_kmPerDegree ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_Distance> > findAll ( );
      static ::SWA::ObjectPtr<maslo_Distance> findOne ( );
      static ::SWA::ObjectPtr<maslo_Distance> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_Distance ( );
      virtual ~maslo_Distance ( );


    // Prevent copy
    private:
      maslo_Distance ( const maslo_Distance& rhs );
      maslo_Distance& operator= ( const maslo_Distance& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_Distance& obj );
}
#endif // _Location_Distance_hh
