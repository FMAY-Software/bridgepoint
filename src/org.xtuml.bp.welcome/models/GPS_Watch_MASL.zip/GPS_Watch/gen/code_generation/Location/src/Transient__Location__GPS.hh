//
// File: Transient__Location__GPS.hh
//
#ifndef Transient_Location_GPS_hh
#define Transient_Location_GPS_hh

#include "__Location__GPS.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace transient
{
  namespace masld_Location
  {
    class maslo_GPS
      : public ::masld_Location::maslo_GPS
    {

      // Constructors and Destructors
      public:
        maslo_GPS ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                    double                                 masla_currentLatitude,
                    double                                 masla_currentLongitude,
                    int32_t                                masla_motionSegments,
                    int32_t                                masla_id,
                    ::masld_Location::maslo_GPS::Type      currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) { this->masla_timer = value; }
        virtual void set_masla_currentLatitude ( double value ) { this->masla_currentLatitude = value; }
        virtual void set_masla_currentLongitude ( double value ) { this->masla_currentLongitude = value; }
        virtual void set_masla_motionSegments ( int32_t value ) { this->masla_motionSegments = value; }
        virtual void setCurrentState ( ::masld_Location::maslo_GPS::Type newState ) { currentState = newState; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const { return masla_timer; }
        virtual double get_masla_currentLatitude ( ) const { return masla_currentLatitude; }
        virtual double get_masla_currentLongitude ( ) const { return masla_currentLongitude; }
        virtual int32_t get_masla_motionSegments ( ) const { return masla_motionSegments; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual ::masld_Location::maslo_GPS::Type getCurrentState ( ) const { return currentState; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::SWA::EventTimers::TimerIdType masla_timer;
        double masla_currentLatitude;
        double masla_currentLongitude;
        int32_t masla_motionSegments;
        int32_t masla_id;
        ::masld_Location::maslo_GPS::Type currentState;


    };
  }
}
#endif // Transient_Location_GPS_hh
