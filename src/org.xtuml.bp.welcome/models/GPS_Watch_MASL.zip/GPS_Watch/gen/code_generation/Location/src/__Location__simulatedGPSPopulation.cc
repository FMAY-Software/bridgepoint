//
// File: __Location__simulatedGPSPopulation.cc
//
#include "__Location__simulatedGPSPopulation.hh"

namespace masld_Location
{
  maslo_simulatedGPSPopulation::maslo_simulatedGPSPopulation ( )
  {
  }

  maslo_simulatedGPSPopulation::~maslo_simulatedGPSPopulation ( )
  {
  }

}
