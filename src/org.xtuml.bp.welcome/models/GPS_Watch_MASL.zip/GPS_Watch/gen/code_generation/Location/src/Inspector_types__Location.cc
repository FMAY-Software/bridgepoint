//
// File: Inspector_types__Location.cc
//
