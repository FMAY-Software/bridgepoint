//
// File: __Location__GPSPopulation.hh
//
#ifndef _Location_GPS_Population_hh
#define _Location_GPS_Population_hh

#include "__Location__GPS.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  class maslo_GPSPopulation
    : public ::SWA::DynamicSingleton<maslo_GPSPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_GPS> createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                           double                                 masla_currentLatitude,
                                                           double                                 masla_currentLongitude,
                                                           int32_t                                masla_motionSegments,
                                                           int32_t                                masla_id,
                                                           maslo_GPS::Type                        currentState ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_GPS> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_GPS> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_GPS> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_GPS> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_GPS> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_GPSPopulation ( );
      virtual ~maslo_GPSPopulation ( );


    // Prevent copy
    private:
      maslo_GPSPopulation ( const maslo_GPSPopulation& rhs );
      maslo_GPSPopulation& operator= ( const maslo_GPSPopulation& rhs );


  };
}
#endif // _Location_GPS_Population_hh
