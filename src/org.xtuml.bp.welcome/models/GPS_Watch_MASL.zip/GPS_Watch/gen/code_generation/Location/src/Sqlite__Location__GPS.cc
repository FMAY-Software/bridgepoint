//
// File: Sqlite__Location__GPS.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "Sqlite__Location__GPS.hh"
#include "Sqlite__Location__GPSPopulation.hh"
#include "__Location__GPS.hh"
#include "__Location__GPSEvents.hh"
#include "boost/shared_ptr.hpp"
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_GPS::maslo_GPS ( ::SWA::IdType                          architectureId,
                           const ::SWA::EventTimers::TimerIdType& masla_timer,
                           double                                 masla_currentLatitude,
                           double                                 masla_currentLongitude,
                           int32_t                                masla_motionSegments,
                           int32_t                                masla_id,
                           ::masld_Location::maslo_GPS::Type      currentState )
      : architectureId(architectureId),
        masla_timer(masla_timer),
        masla_currentLatitude(masla_currentLatitude),
        masla_currentLongitude(masla_currentLongitude),
        masla_motionSegments(masla_motionSegments),
        masla_id(masla_id),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_GPS::maslo_GPS ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_timer(),
        masla_currentLatitude(),
        masla_currentLongitude(),
        masla_motionSegments(),
        masla_id(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_GPS::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_GPS::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_GPSPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_GPS::PrimaryKeyType maslo_GPS::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_GPS::IndexKeyType_1 maslo_GPS::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

    void encode_maslo_GPS_maslev_tick ( ::boost::shared_ptr< ::SWA::Event> event,
                                        BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_GPS_maslev_tick ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Location::Event_maslo_GPS_maslev_tick() );
    }

    bool registermaslo_GPS_maslev_tick = EventParameterCodecs::getInstance().registerCodec( ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS, ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_tick, &encode_maslo_GPS_maslev_tick, &decode_maslo_GPS_maslev_tick );

    void encode_maslo_GPS_maslev_registeringComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                       BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_GPS_maslev_registeringComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Location::Event_maslo_GPS_maslev_registeringComplete() );
    }

    bool registermaslo_GPS_maslev_registeringComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS, ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_registeringComplete, &encode_maslo_GPS_maslev_registeringComplete, &decode_maslo_GPS_maslev_registeringComplete );

    void encode_maslo_GPS_maslev_registerListener ( ::boost::shared_ptr< ::SWA::Event> event,
                                                    BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_GPS_maslev_registerListener ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Location::Event_maslo_GPS_maslev_registerListener() );
    }

    bool registermaslo_GPS_maslev_registerListener = EventParameterCodecs::getInstance().registerCodec( ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS, ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_registerListener, &encode_maslo_GPS_maslev_registerListener, &decode_maslo_GPS_maslev_registerListener );

    void encode_maslo_GPS_maslev_unregisterListener ( ::boost::shared_ptr< ::SWA::Event> event,
                                                      BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_GPS_maslev_unregisterListener ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Location::Event_maslo_GPS_maslev_unregisterListener() );
    }

    bool registermaslo_GPS_maslev_unregisterListener = EventParameterCodecs::getInstance().registerCodec( ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS, ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_unregisterListener, &encode_maslo_GPS_maslev_unregisterListener, &decode_maslo_GPS_maslev_unregisterListener );

    void encode_maslo_GPS_maslev_unregisterComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                      BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_GPS_maslev_unregisterComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Location::Event_maslo_GPS_maslev_unregisterComplete() );
    }

    bool registermaslo_GPS_maslev_unregisterComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS, ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_unregisterComplete, &encode_maslo_GPS_maslev_unregisterComplete, &decode_maslo_GPS_maslev_unregisterComplete );

  }
}
