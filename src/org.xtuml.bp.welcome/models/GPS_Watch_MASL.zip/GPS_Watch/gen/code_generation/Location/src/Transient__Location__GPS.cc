//
// File: Transient__Location__GPS.cc
//
#include "Transient__Location__GPS.hh"
#include "__Location__GPS.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"

namespace transient
{
  namespace masld_Location
  {
    maslo_GPS::maslo_GPS ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                           double                                 masla_currentLatitude,
                           double                                 masla_currentLongitude,
                           int32_t                                masla_motionSegments,
                           int32_t                                masla_id,
                           ::masld_Location::maslo_GPS::Type      currentState )
      : architectureId(getNextArchId()),
        masla_timer(masla_timer),
        masla_currentLatitude(masla_currentLatitude),
        masla_currentLongitude(masla_currentLongitude),
        masla_motionSegments(masla_motionSegments),
        masla_id(masla_id),
        currentState(currentState)
    {
    }

  }
}
