//
// File: __Location_private_types.cc
//
