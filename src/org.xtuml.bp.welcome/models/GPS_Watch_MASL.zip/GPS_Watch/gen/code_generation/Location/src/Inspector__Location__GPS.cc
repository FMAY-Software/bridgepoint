//
// File: Inspector__Location__GPS.cc
//
#include "Inspector__Location__GPS.hh"
#include "__Location__GPS.hh"
#include "__Location__GPSEvents.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/EventHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Location
  {
    namespace maslo_GPS
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Location::maslo_GPS::masls_initialize(); }


      };
      class maslst_idleHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_locatingHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_registeringListenerHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_unregisteringHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_GPS_maslev_tickHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_GPS_maslev_registeringCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_GPS_maslev_registerListenerHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_GPS_maslev_unregisterListenerHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_GPS_maslev_unregisterCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write gps
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> >();
              break;

            case 1:

              // Write simgps
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> >();
              break;

          }

        }
      }

      void maslst_idleHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Location::maslo_GPS>( frame.getThis< ::masld_Location::maslo_GPS>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_locatingHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Location::maslo_GPS>( frame.getThis< ::masld_Location::maslo_GPS>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write simgps
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> >();
              break;

          }

        }
      }

      void maslst_registeringListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                               const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Location::maslo_GPS>( frame.getThis< ::masld_Location::maslo_GPS>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write simgps
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> >();
              break;

          }

        }
      }

      void maslst_unregisteringHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Location::maslo_GPS>( frame.getThis< ::masld_Location::maslo_GPS>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_GPS_maslev_tickHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_GPS_maslev_tick( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_GPS_maslev_tickHandler::writeParameters ( const ::SWA::Event&   event,
                                                           BufferedOutputStream& stream ) const
      {
        const ::masld_Location::Event_maslo_GPS_maslev_tick& typedEvent = dynamic_cast<const ::masld_Location::Event_maslo_GPS_maslev_tick&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_GPS_maslev_registeringCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_GPS_maslev_registeringComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_GPS_maslev_registeringCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                          BufferedOutputStream& stream ) const
      {
        const ::masld_Location::Event_maslo_GPS_maslev_registeringComplete& typedEvent = dynamic_cast<const ::masld_Location::Event_maslo_GPS_maslev_registeringComplete&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_GPS_maslev_registerListenerHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_GPS_maslev_registerListener( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_GPS_maslev_registerListenerHandler::writeParameters ( const ::SWA::Event&   event,
                                                                       BufferedOutputStream& stream ) const
      {
        const ::masld_Location::Event_maslo_GPS_maslev_registerListener& typedEvent = dynamic_cast<const ::masld_Location::Event_maslo_GPS_maslev_registerListener&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_GPS_maslev_unregisterListenerHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_GPS_maslev_unregisterListener( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_GPS_maslev_unregisterListenerHandler::writeParameters ( const ::SWA::Event&   event,
                                                                         BufferedOutputStream& stream ) const
      {
        const ::masld_Location::Event_maslo_GPS_maslev_unregisterListener& typedEvent = dynamic_cast<const ::masld_Location::Event_maslo_GPS_maslev_unregisterListener&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_GPS_maslev_unregisterCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_GPS_maslev_unregisterComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_GPS_maslev_unregisterCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                         BufferedOutputStream& stream ) const
      {
        const ::masld_Location::Event_maslo_GPS_maslev_unregisterComplete& typedEvent = dynamic_cast<const ::masld_Location::Event_maslo_GPS_maslev_unregisterComplete&>( event );
      }

      maslo_GPSHandler::maslo_GPSHandler ( )
      {
        registerServiceHandler( ::masld_Location::maslo_GPS::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
        registerStateHandler( ::masld_Location::maslo_GPS::stateId_maslst_idle, ::boost::shared_ptr<ActionHandler>( new maslst_idleHandler() ) );
        registerStateHandler( ::masld_Location::maslo_GPS::stateId_maslst_locating, ::boost::shared_ptr<ActionHandler>( new maslst_locatingHandler() ) );
        registerStateHandler( ::masld_Location::maslo_GPS::stateId_maslst_registeringListener, ::boost::shared_ptr<ActionHandler>( new maslst_registeringListenerHandler() ) );
        registerStateHandler( ::masld_Location::maslo_GPS::stateId_maslst_unregistering, ::boost::shared_ptr<ActionHandler>( new maslst_unregisteringHandler() ) );
        registerEventHandler( ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_tick, ::boost::shared_ptr<EventHandler>( new maslo_GPS_maslev_tickHandler() ) );
        registerEventHandler( ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_registeringComplete, ::boost::shared_ptr<EventHandler>( new maslo_GPS_maslev_registeringCompleteHandler() ) );
        registerEventHandler( ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_registerListener, ::boost::shared_ptr<EventHandler>( new maslo_GPS_maslev_registerListenerHandler() ) );
        registerEventHandler( ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_unregisterListener, ::boost::shared_ptr<EventHandler>( new maslo_GPS_maslev_unregisterListenerHandler() ) );
        registerEventHandler( ::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_unregisterComplete, ::boost::shared_ptr<EventHandler>( new maslo_GPS_maslev_unregisterCompleteHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Location::maslo_GPS> ( const ::masld_Location::maslo_GPS& instance )
  {
    write( instance.getArchitectureId() );
    write( ::SWA::EventTimers::getInstance().getTimer( instance.get_masla_timer() ) );
    write( instance.get_masla_currentLatitude() );
    write( instance.get_masla_currentLongitude() );
    write( instance.get_masla_motionSegments() );
    write( instance.get_masla_id() );
    write( static_cast<int>( instance.getCurrentState() ) );
  }

  namespace masld_Location
  {
    namespace maslo_GPS
    {
      void maslo_GPSHandler::createInstance ( CommunicationChannel& channel ) const
      {
        double masla_currentLatitude;
        double masla_currentLongitude;
        int32_t masla_motionSegments;
        int32_t masla_id;
        int currentState;
        channel >> masla_currentLatitude >> masla_currentLongitude >> masla_motionSegments >> masla_id >> currentState;
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance = ::masld_Location::maslo_GPS::createInstance( ::SWA::EventTimers::getInstance().createTimer(), masla_currentLatitude, masla_currentLongitude, masla_motionSegments, masla_id, ::masld_Location::maslo_GPS::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_GPSHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> > ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Location::maslo_GPS::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Location
  {
    namespace maslo_GPS
    {
      void maslo_GPSHandler::writeRelatedInstances ( CommunicationChannel&                          channel,
                                                     ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance,
                                                     int                                            relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
