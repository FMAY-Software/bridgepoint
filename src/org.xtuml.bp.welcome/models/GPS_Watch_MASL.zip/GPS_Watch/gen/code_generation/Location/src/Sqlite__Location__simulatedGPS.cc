//
// File: Sqlite__Location__simulatedGPS.cc
//
#include "Sqlite__Location__simulatedGPS.hh"
#include "Sqlite__Location__simulatedGPSPopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_simulatedGPS::maslo_simulatedGPS ( ::SWA::IdType architectureId,
                                             int32_t       masla_id,
                                             double        masla_initialLatitude,
                                             double        masla_initialLongitude,
                                             double        masla_latitudeIncrement,
                                             double        masla_longitudeIncrement,
                                             int32_t       masla_updatePeriod )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_initialLatitude(masla_initialLatitude),
        masla_initialLongitude(masla_initialLongitude),
        masla_latitudeIncrement(masla_latitudeIncrement),
        masla_longitudeIncrement(masla_longitudeIncrement),
        masla_updatePeriod(masla_updatePeriod),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_simulatedGPS::maslo_simulatedGPS ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_initialLatitude(),
        masla_initialLongitude(),
        masla_latitudeIncrement(),
        masla_longitudeIncrement(),
        masla_updatePeriod(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_simulatedGPS::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_simulatedGPS::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_simulatedGPSPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_simulatedGPS::PrimaryKeyType maslo_simulatedGPS::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_simulatedGPS::IndexKeyType_1 maslo_simulatedGPS::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
