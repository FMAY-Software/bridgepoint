//
// File: Transient__Location__GPSPopulation.cc
//
#include "Transient__Location__GPS.hh"
#include "Transient__Location__GPSPopulation.hh"
#include "__Location__GPS.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Location
  {
    maslo_GPSPopulation::maslo_GPSPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> maslo_GPSPopulation::createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                         double                                 masla_currentLatitude,
                                                                                         double                                 masla_currentLongitude,
                                                                                         int32_t                                masla_motionSegments,
                                                                                         int32_t                                masla_id,
                                                                                         ::masld_Location::maslo_GPS::Type      currentState )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance(new maslo_GPS(  masla_timer,
                masla_currentLatitude,
                masla_currentLongitude,
                masla_motionSegments,
                masla_id,
                currentState ));
      addInstance( instance );
      return instance;
    }

    void maslo_GPSPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Location::maslo_GPS> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_GPSPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_GPSPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_GPSPopulation& maslo_GPSPopulation::getPopulation ( )
    {
      static maslo_GPSPopulation population;
      return population;
    }

    bool maslo_GPSPopulation::registered = maslo_GPSPopulation::registerSingleton( &maslo_GPSPopulation::getPopulation );

  }
}
