//
// File: Sqlite__Location__DistanceMapper.cc
//
#include "Sqlite__Location__Distance.hh"
#include "Sqlite__Location__DistanceMapper.hh"
#include "Sqlite__Location__DistanceMapperSql.hh"
#include "__Location__Distance.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_DistanceMapper::maslo_DistanceMapper ( )
      : ::SQL::ObjectMapper< ::masld_Location::maslo_Distance,maslo_Distance>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Location::maslo_Distance,maslo_Distance> >( new maslo_DistanceSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_DistanceMapper::~maslo_DistanceMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> maslo_DistanceMapper::createInstance ( int32_t masla_id,
                                                                                               double  masla_kmPerDegree )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_Distance::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_Distance> instance(new maslo_Distance(  uniqueId,
                     masla_id,
                     masla_kmPerDegree ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_DistanceMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance )
    {
      ::SQL::ObjectMapper< ::masld_Location::maslo_Distance,maslo_Distance>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_Distance>()->getPrimaryKey() );
    }

    bool maslo_DistanceMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
