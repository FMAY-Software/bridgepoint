//
// File: __Logger_types.cc
//
#include "Logger_OOA/__Logger_types.hh"
#include <iostream>
#include <stdint.h>
#include <string>
#include "swa/ProgramError.hh"

namespace masld_Logger
{
  maslt_Priority::maslt_Priority ( )
    : index(index_masle_Fatal)
  {
  }

  maslt_Priority::maslt_Priority ( Index index )
    : index(index)
  {
  }

  const maslt_Priority maslt_Priority::masle_Fatal = maslt_Priority( maslt_Priority::index_masle_Fatal );

  const maslt_Priority maslt_Priority::masle_Critical = maslt_Priority( maslt_Priority::index_masle_Critical );

  const maslt_Priority maslt_Priority::masle_Error = maslt_Priority( maslt_Priority::index_masle_Error );

  const maslt_Priority maslt_Priority::masle_Warning = maslt_Priority( maslt_Priority::index_masle_Warning );

  const maslt_Priority maslt_Priority::masle_Notice = maslt_Priority( maslt_Priority::index_masle_Notice );

  const maslt_Priority maslt_Priority::masle_Information = maslt_Priority( maslt_Priority::index_masle_Information );

  const maslt_Priority maslt_Priority::masle_Debug = maslt_Priority( maslt_Priority::index_masle_Debug );

  const maslt_Priority maslt_Priority::masle_Trace = maslt_Priority( maslt_Priority::index_masle_Trace );

  maslt_Priority::maslt_Priority ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_Priority::textLookup[] = { "Fatal",
     "Critical",
     "Error",
     "Warning",
     "Notice",
     "Information",
     "Debug",
     "Trace"};

  maslt_Priority::TextLookupTable maslt_Priority::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Fatal], index_masle_Fatal ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Critical], index_masle_Critical ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Error], index_masle_Error ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Warning], index_masle_Warning ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Notice], index_masle_Notice ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Information], index_masle_Information ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Debug], index_masle_Debug ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Trace], index_masle_Trace ) );
    return lookup;
  }

  maslt_Priority::Index maslt_Priority::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_Priority::maslt_Priority ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_Priority::Value maslt_Priority::valueLookup[] = { maslt_Priority::value_masle_Fatal,
     maslt_Priority::value_masle_Critical,
     maslt_Priority::value_masle_Error,
     maslt_Priority::value_masle_Warning,
     maslt_Priority::value_masle_Notice,
     maslt_Priority::value_masle_Information,
     maslt_Priority::value_masle_Debug,
     maslt_Priority::value_masle_Trace};

  maslt_Priority::Index maslt_Priority::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_Fatal:       return index_masle_Fatal;
      case value_masle_Critical:    return index_masle_Critical;
      case value_masle_Error:       return index_masle_Error;
      case value_masle_Warning:     return index_masle_Warning;
      case value_masle_Notice:      return index_masle_Notice;
      case value_masle_Information: return index_masle_Information;
      case value_masle_Debug:       return index_masle_Debug;
      case value_masle_Trace:       return index_masle_Trace;
      default:                      throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_Priority::maslt_Priority ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_Priority& maslt_Priority::operator++ ( )
  {
    if ( index == index_masle_Trace ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_Priority& maslt_Priority::operator-- ( )
  {
    if ( index == index_masle_Fatal ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslt_Priority& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_Priority& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_Priority( text );
    return stream;
  }

}
