//
// File: MetaData__if__Logger.cc
//
#include "Logger_OOA/MetaData__Logger.hh"
#include "Logger_OOA/__Logger_interface.hh"
#include "Logger_OOA/__Logger_types.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_Logger
  {
    ::SWA::EnumerateMetaData get_maslt_Priority_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Logger::getDomain().getId(), "Logger", true);
      domain.addEnumerate( get_maslt_Priority_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Logger::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_Priority_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Logger::typeId_maslt_Priority, "Priority");
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Fatal.getValue(), "Fatal" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Critical.getValue(), "Critical" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Error.getValue(), "Error" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Warning.getValue(), "Warning" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Notice.getValue(), "Notice" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Information.getValue(), "Information" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Debug.getValue(), "Debug" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Trace.getValue(), "Trace" );
      return enumeration;
    }

  }
}
