//
// File: __Logger_private_types.cc
//
