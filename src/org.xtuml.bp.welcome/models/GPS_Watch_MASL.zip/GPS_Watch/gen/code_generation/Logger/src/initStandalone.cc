//
// File: initStandalone.cc
//
#include "swa/Main.hh"
#include "swa/Process.hh"

namespace masld_Logger
{
  bool initialiseProcess ( )
  {
    ::SWA::Process::getInstance().setProjectName( "Logger" );
    return true;
  }

  const bool processInitialised = initialiseProcess();

}
int main ( int                 argc,
           const char* const * argv )
{
  return SWA::main( argc, argv );
}

