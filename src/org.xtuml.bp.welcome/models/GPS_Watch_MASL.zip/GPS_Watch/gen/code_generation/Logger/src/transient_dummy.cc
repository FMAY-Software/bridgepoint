//
// File: transient_dummy.cc
//
