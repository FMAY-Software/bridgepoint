//
// File: __Logger.cc
//
#include "Logger_OOA/__Logger_interface.hh"
#include "swa/Domain.hh"

namespace masld_Logger
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
