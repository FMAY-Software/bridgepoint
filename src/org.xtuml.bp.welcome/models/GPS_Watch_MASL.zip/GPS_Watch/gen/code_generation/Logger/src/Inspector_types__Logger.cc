//
// File: Inspector_types__Logger.cc
//
#include "Logger_OOA/__Logger_types.hh"
#include "inspector/BufferedIO.hh"

namespace Inspector
{
  template<>
  void BufferedOutputStream::write< ::masld_Logger::maslt_Priority> ( const ::masld_Logger::maslt_Priority& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Logger::maslt_Priority> ( ::masld_Logger::maslt_Priority& value )
  {
    int index;
    read( index );
    value = ::masld_Logger::maslt_Priority( ::masld_Logger::maslt_Priority::Index( index ) );
  }

}
