//
// File: __Tracking__GoalSpec.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__GoalSpecPopulation.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Bag.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_GoalSpec> maslo_GoalSpec::getInstance ( ::SWA::IdType id )
  {
    return maslo_GoalSpecPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_GoalSpec::getNextArchId ( )
  {
    return maslo_GoalSpecPopulation::getSingleton().getNextArchId();
  }

  maslo_GoalSpec::maslo_GoalSpec ( )
    : isDeletedFlag()
  {
  }

  maslo_GoalSpec::~maslo_GoalSpec ( )
  {
  }

  ::SWA::ObjectPtr<maslo_GoalSpec> maslo_GoalSpec::createInstance ( double                    masla_minimum,
                                                                    double                    masla_maximum,
                                                                    double                    masla_span,
                                                                    const maslt_GoalCriteria& masla_criteriaType,
                                                                    const maslt_GoalSpan&     masla_spanType,
                                                                    int32_t                   masla_sequenceNumber,
                                                                    const ::SWA::Timestamp&   masla_session_startTime,
                                                                    int32_t                   masla_last_goal_ID )
  {
    return maslo_GoalSpecPopulation::getSingleton().createInstance( masla_minimum, masla_maximum, masla_span, masla_criteriaType, masla_spanType, masla_sequenceNumber, masla_session_startTime, masla_last_goal_ID );
  }

  void maslo_GoalSpec::deleteInstance ( )
  {
    if ( count_R9_specifies_Goal() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R9 still linked" );
    if ( count_R10_included_in_WorkoutSession() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R10 still linked" );
    maslo_GoalSpecPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_GoalSpec>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_GoalSpec::getPopulationSize ( )
  {
    return maslo_GoalSpecPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> > maslo_GoalSpec::findAll ( )
  {
    return maslo_GoalSpecPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_GoalSpec> maslo_GoalSpec::findOne ( )
  {
    return maslo_GoalSpecPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_GoalSpec> maslo_GoalSpec::findOnly ( )
  {
    return maslo_GoalSpecPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_GoalSpec::count_R9_specifies_Goal ( ) const
  {
    return navigate_R9_specifies_Goal().size();
  }

  void maslo_GoalSpec::checked_link_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() || rhs->get_masla_spec_sequenceNumber() != get_masla_sequenceNumber() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R9_specifies_Goal( rhs );
  }

  void maslo_GoalSpec::checked_link_R9_specifies_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it )
    {
      if ( (*it)->get_masla_session_startTime() != get_masla_session_startTime() || (*it)->get_masla_spec_sequenceNumber() != get_masla_sequenceNumber() )
      {
        throw ::SWA::ProgramError( "referential integrity failure" );
      }
    }
    link_R9_specifies_Goal( rhs );
  }

  void maslo_GoalSpec::link_R9_specifies_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) link_R9_specifies_Goal( *it );
  }

  void maslo_GoalSpec::unlink_R9_specifies_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) unlink_R9_specifies_Goal( *it );
  }

  void maslo_GoalSpec::unlink_R9_specifies_Goal ( )
  {
    unlink_R9_specifies_Goal( navigate_R9_specifies_Goal() );
  }

  ::std::size_t maslo_GoalSpec::count_R10_included_in_WorkoutSession ( ) const
  {
    return navigate_R10_included_in_WorkoutSession() == ::SWA::Null ? 0
                                                                    : 1;
  }

  void maslo_GoalSpec::checked_link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R10_included_in_WorkoutSession( rhs );
  }

  void maslo_GoalSpec::unlink_R10_included_in_WorkoutSession ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs = navigate_R10_included_in_WorkoutSession();
    if ( rhs ) unlink_R10_included_in_WorkoutSession( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_GoalSpec& obj )
  {
    stream << "(";
    stream << obj.get_masla_minimum();
    stream << ",";
    stream << obj.get_masla_maximum();
    stream << ",";
    stream << obj.get_masla_span();
    stream << ",";
    stream << obj.get_masla_criteriaType();
    stream << ",";
    stream << obj.get_masla_spanType();
    stream << ",";
    stream << obj.get_masla_sequenceNumber();
    stream << ",";
    stream << obj.get_masla_session_startTime();
    stream << ",";
    stream << obj.get_masla_last_goal_ID();
    stream << ")";
    return stream;
  }

  // MASL find: (sequenceNumber = p1)
  ::SWA::ObjectPtr<maslo_GoalSpec> maslo_GoalSpec::findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 )
  {
    return maslo_GoalSpecPopulation::getSingleton().findOne_OPmasl_sequenceNumber_maslEQp1CP( p1 );
  }

}
