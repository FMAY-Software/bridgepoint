//
// File: Sqlite__Tracking__R2Mapper.hh
//
#ifndef Sqlite_Tracking_R_2_Mapper_hh
#define Sqlite_Tracking_R_2_Mapper_hh

#include "Sqlite__Tracking__TrackPoint.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToOneRelationship<2,maslo_TrackPoint,maslo_TrackPoint,true,true>::mapper_type RelationshipR2Mapper;
  }
}
#endif // Sqlite_Tracking_R_2_Mapper_hh
