//
// File: Transient__Tracking__GoalSpecConstantsPopulation.cc
//
#include "Transient__Tracking__GoalSpecConstants.hh"
#include "Transient__Tracking__GoalSpecConstantsPopulation.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalSpecConstantsPopulation::maslo_GoalSpecConstantsPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> maslo_GoalSpecConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                                     int32_t masla_GoalSpecOrigin )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance(new maslo_GoalSpecConstants(  masla_id,
                              masla_GoalSpecOrigin ));
      addInstance( instance );
      return instance;
    }

    void maslo_GoalSpecConstantsPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_GoalSpecConstantsPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_GoalSpecConstantsPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_GoalSpecConstantsPopulation& maslo_GoalSpecConstantsPopulation::getPopulation ( )
    {
      static maslo_GoalSpecConstantsPopulation population;
      return population;
    }

    bool maslo_GoalSpecConstantsPopulation::registered = maslo_GoalSpecConstantsPopulation::registerSingleton( &maslo_GoalSpecConstantsPopulation::getPopulation );

  }
}
