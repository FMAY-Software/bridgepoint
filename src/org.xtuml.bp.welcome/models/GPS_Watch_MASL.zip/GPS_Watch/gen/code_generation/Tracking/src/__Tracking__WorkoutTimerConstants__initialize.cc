//
// File: __Tracking__WorkoutTimerConstants__initialize.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void maslo_WorkoutTimerConstants::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutTimerConstants, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // wtc : instance of WorkoutTimerConstants;
        ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> maslv_wtc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_wtc(0, maslv_wtc);

        // wtc := find_one WorkoutTimerConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_wtc = findOne();
        }

        // if (null = wtc) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_wtc )
          {

            // wtc := create WorkoutTimerConstants (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_wtc = createInstance( 1ll, int32_t() );
            }

            // wtc.timerPeriod := 1;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_wtc->set_masla_timerPeriod( 1ll );
            }
          }
        }
      }
    }
  }

}
