//
// File: Transient__Tracking__GoalSpec.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include "Transient__Tracking__Goal.hh"
#include "Transient__Tracking__GoalSpec.hh"
#include "Transient__Tracking__WorkoutSession.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalSpec::maslo_GoalSpec ( double                                      masla_minimum,
                                     double                                      masla_maximum,
                                     double                                      masla_span,
                                     const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                     const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                     int32_t                                     masla_sequenceNumber,
                                     const ::SWA::Timestamp&                     masla_session_startTime,
                                     int32_t                                     masla_last_goal_ID )
      : architectureId(getNextArchId()),
        masla_minimum(masla_minimum),
        masla_maximum(masla_maximum),
        masla_span(masla_span),
        masla_criteriaType(masla_criteriaType),
        masla_spanType(masla_spanType),
        masla_sequenceNumber(masla_sequenceNumber),
        masla_session_startTime(masla_session_startTime),
        masla_last_goal_ID(masla_last_goal_ID),
        R9_specifies_Goal(),
        R10_included_in_WorkoutSession()
    {
    }

    ToManyRelationship<maslo_Goal>& maslo_GoalSpec::get_R9_specifies_Goal ( )
    {
      return R9_specifies_Goal;
    }

    const ToManyRelationship<maslo_Goal>& maslo_GoalSpec::get_R9_specifies_Goal ( ) const
    {
      return R9_specifies_Goal;
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_GoalSpec::get_R10_included_in_WorkoutSession ( )
    {
      return R10_included_in_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_GoalSpec::get_R10_included_in_WorkoutSession ( ) const
    {
      return R10_included_in_WorkoutSession;
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > maslo_GoalSpec::navigate_R9_specifies_Goal ( ) const
    {
      return get_R9_specifies_Goal().navigate();
    }

    ::std::size_t maslo_GoalSpec::count_R9_specifies_Goal ( ) const
    {
      return get_R9_specifies_Goal().count();
    }

    void maslo_GoalSpec::link_R9_specifies_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R9_specifies_Goal().link( rhs2 );
      try
      {
        rhs2->get_R9_specified_by_GoalSpec().link( ::SWA::ObjectPtr<maslo_GoalSpec>( this ) );
      }
      catch ( ... )
      {
        this->get_R9_specifies_Goal().unlink( rhs2 );
        throw;
      }
    }

    void maslo_GoalSpec::unlink_R9_specifies_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R9_specifies_Goal().unlink( rhs2 );
      try
      {
        rhs2->get_R9_specified_by_GoalSpec().unlink( ::SWA::ObjectPtr<maslo_GoalSpec>( this ) );
      }
      catch ( ... )
      {
        this->get_R9_specifies_Goal().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_GoalSpec::navigate_R10_included_in_WorkoutSession ( ) const
    {
      return get_R10_included_in_WorkoutSession().navigate();
    }

    ::std::size_t maslo_GoalSpec::count_R10_included_in_WorkoutSession ( ) const
    {
      return get_R10_included_in_WorkoutSession().count();
    }

    void maslo_GoalSpec::link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R10_included_in_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R10_includes_GoalSpec().link( ::SWA::ObjectPtr<maslo_GoalSpec>( this ) );
      }
      catch ( ... )
      {
        this->get_R10_included_in_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_GoalSpec::unlink_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R10_included_in_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R10_includes_GoalSpec().unlink( ::SWA::ObjectPtr<maslo_GoalSpec>( this ) );
      }
      catch ( ... )
      {
        this->get_R10_included_in_WorkoutSession().link( rhs2 );
        throw;
      }
    }

  }
}
