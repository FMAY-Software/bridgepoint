//
// File: Sqlite__Tracking__SpeedMapper.cc
//
#include "Sqlite__Tracking__Speed.hh"
#include "Sqlite__Tracking__SpeedMapper.hh"
#include "Sqlite__Tracking__SpeedMapperSql.hh"
#include "__Tracking__Speed.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_SpeedMapper::maslo_SpeedMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_Speed,maslo_Speed>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_Speed,maslo_Speed> >( new maslo_SpeedSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_SpeedMapper::~maslo_SpeedMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> maslo_SpeedMapper::createInstance ( int32_t masla_id,
                                                                                         int32_t masla_SpeedAveragingWindow,
                                                                                         int32_t masla_SecondsPerHour )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_Speed::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_Speed> instance(new maslo_Speed(  uniqueId,
                  masla_id,
                  masla_SpeedAveragingWindow,
                  masla_SecondsPerHour ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_SpeedMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_Speed,maslo_Speed>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_Speed>()->getPrimaryKey() );
    }

    bool maslo_SpeedMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
