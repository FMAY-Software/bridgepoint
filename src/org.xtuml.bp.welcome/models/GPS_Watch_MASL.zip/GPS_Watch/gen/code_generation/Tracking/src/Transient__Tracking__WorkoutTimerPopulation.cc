//
// File: Transient__Tracking__WorkoutTimerPopulation.cc
//
#include "Transient__Tracking__WorkoutTimer.hh"
#include "Transient__Tracking__WorkoutTimerPopulation.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerPopulation::maslo_WorkoutTimerPopulation ( )
      : masla_session_startTime_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> maslo_WorkoutTimerPopulation::createInstance ( int32_t                                    masla_time,
                                                                                                           const ::SWA::EventTimers::TimerIdType&     masla_timer,
                                                                                                           const ::SWA::Timestamp&                    masla_session_startTime,
                                                                                                           ::masld_Tracking::maslo_WorkoutTimer::Type currentState )
    {
      if ( exists_masla_session_startTime( masla_session_startTime ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance(new maslo_WorkoutTimer(  masla_time,
                         masla_timer,
                         masla_session_startTime,
                         currentState ));
      addInstance( instance );
      return instance;
    }

    void maslo_WorkoutTimerPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance )
    {
      masla_session_startTime_Lookup.insert( ::boost::unordered_map< ::boost::tuple< ::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >::value_type( ::boost::make_tuple( instance->get_masla_session_startTime() ), instance ) );
    }

    void maslo_WorkoutTimerPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance )
    {
      masla_session_startTime_Lookup.erase( ::boost::make_tuple( instance->get_masla_session_startTime() ) );
    }

    bool maslo_WorkoutTimerPopulation::exists_masla_session_startTime ( const ::SWA::Timestamp& masla_session_startTime ) const
    {
      return masla_session_startTime_Lookup.find( ::boost::make_tuple( masla_session_startTime ) ) != masla_session_startTime_Lookup.end();
    }

    maslo_WorkoutTimerPopulation& maslo_WorkoutTimerPopulation::getPopulation ( )
    {
      static maslo_WorkoutTimerPopulation population;
      return population;
    }

    bool maslo_WorkoutTimerPopulation::registered = maslo_WorkoutTimerPopulation::registerSingleton( &maslo_WorkoutTimerPopulation::getPopulation );

  }
}
