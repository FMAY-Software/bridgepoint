//
// File: Sqlite__Tracking__AchievementMapper.cc
//
#include "Sqlite__Tracking__Achievement.hh"
#include "Sqlite__Tracking__AchievementMapper.hh"
#include "Sqlite__Tracking__AchievementMapperSql.hh"
#include "__Tracking__Achievement.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_AchievementMapper::maslo_AchievementMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_Achievement,maslo_Achievement>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_Achievement,maslo_Achievement> >( new maslo_AchievementSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_AchievementMapper::~maslo_AchievementMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> maslo_AchievementMapper::createInstance ( int32_t                 masla_startTime,
                                                                                                     int32_t                 masla_endTime,
                                                                                                     const ::SWA::Timestamp& masla_session_startTime,
                                                                                                     int32_t                 masla_goal_ID,
                                                                                                     int32_t                 masla_spec_sequenceNumber )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_Achievement::PrimaryKeyType>::value_type( masla_startTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_Achievement> instance(new maslo_Achievement(  uniqueId,
                        masla_startTime,
                        masla_endTime,
                        masla_session_startTime,
                        masla_goal_ID,
                        masla_spec_sequenceNumber ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_AchievementMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_Achievement,maslo_Achievement>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_Achievement>()->getPrimaryKey() );
    }

    bool maslo_AchievementMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
