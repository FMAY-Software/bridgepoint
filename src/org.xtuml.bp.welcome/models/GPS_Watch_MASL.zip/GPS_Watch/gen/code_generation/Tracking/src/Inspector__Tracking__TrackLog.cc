//
// File: Inspector__Tracking__TrackLog.cc
//
#include "Inspector__Tracking__TrackLog.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_TrackLog
    {
      class masls_addTrackPointHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_addTrackPointInvoker
      {

        public:
          masls_addTrackPointInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_addTrackPoint(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> thisVar;


      };
      class masls_clearTrackPointsHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_clearTrackPointsInvoker
      {

        public:
          masls_clearTrackPointsInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_clearTrackPoints(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> thisVar;


      };
      class masls_addLapMarkerHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_addLapMarkerInvoker
      {

        public:
          masls_addLapMarkerInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_addLapMarker(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> thisVar;


      };
      class masls_clearLapMarkersHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_clearLapMarkersInvoker
      {

        public:
          masls_clearLapMarkersInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_clearLapMarkers(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> thisVar;


      };
      class masls_updateDisplayHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_updateDisplayInvoker
      {

        public:
          masls_updateDisplayInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_updateDisplay(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> thisVar;


      };
      Callable masls_addTrackPointHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_addTrackPointInvoker( channel );
      }

      void masls_addTrackPointHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>( frame.getThis< ::masld_Tracking::maslo_TrackLog>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 1:

              // Write trackPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 2:

              // Write firstPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 3:

              // Write lastPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 4:

              // Write isFirstTrackPoint
              channel << frame.getLocalVars()[i].getValue<bool>();
              break;

            case 5:

              // Write lastLatitude
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 6:

              // Write lastLongitude
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 7:

              // Write distance
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 8:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

          }

        }
      }

      Callable masls_clearTrackPointsHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_clearTrackPointsInvoker( channel );
      }

      void masls_clearTrackPointsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>( frame.getThis< ::masld_Tracking::maslo_TrackLog>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write nextPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 1:

              // Write lastPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 2:

              // Write prevPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

          }

        }
      }

      Callable masls_addLapMarkerHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_addLapMarkerInvoker( channel );
      }

      void masls_addLapMarkerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>( frame.getThis< ::masld_Tracking::maslo_TrackLog>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write timer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 1:

              // Write lapMarker
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> >();
              break;

          }

        }
      }

      Callable masls_clearLapMarkersHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_clearLapMarkersInvoker( channel );
      }

      void masls_clearLapMarkersHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>( frame.getThis< ::masld_Tracking::maslo_TrackLog>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write lapMarkers
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > >();
              break;

            case 1:

              // Write lapMarker
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> >();
              break;

          }

        }
      }

      Callable masls_updateDisplayHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_updateDisplayInvoker( channel );
      }

      void masls_updateDisplayHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>( frame.getThis< ::masld_Tracking::maslo_TrackLog>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write display
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> >();
              break;

          }

        }
      }

      maslo_TrackLogHandler::maslo_TrackLogHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_TrackLog::serviceId_masls_addTrackPoint, ::boost::shared_ptr<ActionHandler>( new masls_addTrackPointHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_TrackLog::serviceId_masls_clearTrackPoints, ::boost::shared_ptr<ActionHandler>( new masls_clearTrackPointsHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_TrackLog::serviceId_masls_addLapMarker, ::boost::shared_ptr<ActionHandler>( new masls_addLapMarkerHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_TrackLog::serviceId_masls_clearLapMarkers, ::boost::shared_ptr<ActionHandler>( new masls_clearLapMarkersHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_TrackLog::serviceId_masls_updateDisplay, ::boost::shared_ptr<ActionHandler>( new masls_updateDisplayHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_TrackLog> ( const ::masld_Tracking::maslo_TrackLog& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_session_startTime() );
    write( instance.navigate_R1_has_first_TrackPoint() );
    write( instance.navigate_R3_has_last_TrackPoint() );
    write<int>( instance.count_R5_has_laps_defined_by_LapMarker() );
    write( instance.navigate_R4_represents_path_for_WorkoutSession() );
  }

  namespace masld_Tracking
  {
    namespace maslo_TrackLog
    {
      void maslo_TrackLogHandler::createInstance ( CommunicationChannel& channel ) const
      {
        ::SWA::Timestamp masla_session_startTime;
        channel >> masla_session_startTime;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance = ::masld_Tracking::maslo_TrackLog::createInstance( masla_session_startTime );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_TrackLogHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_TrackLog::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_TrackLog
    {
      void maslo_TrackLogHandler::writeRelatedInstances ( CommunicationChannel&                               channel,
                                                          ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance,
                                                          int                                                 relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackPoint>( ::masld_Tracking::objectId_maslo_TrackPoint ).writeInstances( channel, instance ? instance->navigate_R1_has_first_TrackPoint()
                                                                                                                                                                                                                                           : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>() );
            break;

          case 1:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackPoint>( ::masld_Tracking::objectId_maslo_TrackPoint ).writeInstances( channel, instance ? instance->navigate_R3_has_last_TrackPoint()
                                                                                                                                                                                                                                           : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>() );
            break;

          case 2:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_LapMarker>( ::masld_Tracking::objectId_maslo_LapMarker ).writeInstances( channel, instance ? instance->navigate_R5_has_laps_defined_by_LapMarker()
                                                                                                                                                                                                                                         : ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> >() );
            break;

          case 3:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R4_represents_path_for_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

        }

      }

    }
  }
}
