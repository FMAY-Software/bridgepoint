//
// File: Transient__Tracking__LapMarkerPopulation.hh
//
#ifndef Transient_Tracking_Lap_Marker_Population_hh
#define Transient_Tracking_Lap_Marker_Population_hh

#include "__Tracking__LapMarker.hh"
#include "__Tracking__LapMarkerPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_LapMarkerPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_LapMarker,::masld_Tracking::maslo_LapMarkerPopulation>
    {

      // Instance Creation
      private:
        maslo_LapMarkerPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> createInstance ( int32_t                 masla_lapTime,
                                                                                      const ::SWA::Timestamp& masla_session_startTime );


      // Singleton Registration
      public:
        static maslo_LapMarkerPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > masla_lapTimemasla_session_startTime_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance );
      protected:
        bool exists_masla_lapTimemasla_session_startTime ( int32_t                 masla_lapTime,
                                                           const ::SWA::Timestamp& masla_session_startTime ) const;


    };
  }
}
#endif // Transient_Tracking_Lap_Marker_Population_hh
