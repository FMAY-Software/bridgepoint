//
// File: Sqlite__Tracking__LapMarker.cc
//
#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__LapMarkerPopulation.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "__Tracking__TrackLog.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_LapMarker::maslo_LapMarker ( ::SWA::IdType           architectureId,
                                       int32_t                 masla_lapTime,
                                       const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(architectureId),
        masla_lapTime(masla_lapTime),
        masla_session_startTime(masla_session_startTime),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_LapMarker::maslo_LapMarker ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_lapTime(),
        masla_session_startTime(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_LapMarker::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_LapMarker::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_LapMarkerPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_LapMarker::PrimaryKeyType maslo_LapMarker::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_lapTime, masla_session_startTime );
    }

    const maslo_LapMarker::IndexKeyType_1 maslo_LapMarker::get_index_1 ( )
    {
      return IndexKeyType_1( masla_lapTime, masla_session_startTime );
    }

    void maslo_LapMarker::link_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_LapMarkerPopulation::getPopulation().link_R5_marks_end_of_lap_in_TrackLog( ::SWA::ObjectPtr<maslo_LapMarker>( this ), derivedrhs );
    }

    void maslo_LapMarker::unlink_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_LapMarkerPopulation::getPopulation().unlink_R5_marks_end_of_lap_in_TrackLog( ::SWA::ObjectPtr<maslo_LapMarker>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_LapMarker::navigate_R5_marks_end_of_lap_in_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_LapMarker> self(const_cast<maslo_LapMarker*>( this ));
      return maslo_LapMarkerPopulation::getPopulation().navigate_R5_marks_end_of_lap_in_TrackLog( self );
    }

    ::std::size_t maslo_LapMarker::count_R5_marks_end_of_lap_in_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_LapMarker> self(const_cast<maslo_LapMarker*>( this ));
      return maslo_LapMarkerPopulation::getPopulation().count_R5_marks_end_of_lap_in_TrackLog( self );
    }

  }
}
