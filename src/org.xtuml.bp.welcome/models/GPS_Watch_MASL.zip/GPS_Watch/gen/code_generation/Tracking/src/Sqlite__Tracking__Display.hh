//
// File: Sqlite__Tracking__Display.hh
//
#ifndef Sqlite_Tracking_Display_hh
#define Sqlite_Tracking_Display_hh

#include "__Tracking__Display.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Display
      : public ::masld_Tracking::maslo_Display
    {

      // Type definitions
      public:
        typedef ::boost::tuple< ::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple< ::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_Display ( ::SWA::IdType architectureId );
        maslo_Display ( ::SWA::IdType                         architectureId,
                        const ::SWA::Timestamp&               masla_session_startTime,
                        ::masld_Tracking::maslo_Display::Type currentState );


      // Setters for each object attribute
      public:
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }
        virtual void setCurrentState ( ::masld_Tracking::maslo_Display::Type newState )
        {
          currentState = newState;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual ::masld_Tracking::maslo_Display::Type getCurrentState ( ) const { return currentState; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R7_indicates_current_status_of_WorkoutSession ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R7_indicates_current_status_of_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::SWA::Timestamp masla_session_startTime;
        ::masld_Tracking::maslo_Display::Type currentState;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Display_hh
