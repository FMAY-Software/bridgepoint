//
// File: Sqlite__Tracking__Goal.cc
//
#include "Sqlite__Tracking__Achievement.hh"
#include "Sqlite__Tracking__Goal.hh"
#include "Sqlite__Tracking__GoalPopulation.hh"
#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalEvents.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_Goal::maslo_Goal ( ::SWA::IdType                                  architectureId,
                             const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                             double                                         masla_startingPoint,
                             int32_t                                        masla_ID,
                             const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                             const ::SWA::Timestamp&                        masla_session_startTime,
                             int32_t                                        masla_spec_sequenceNumber,
                             ::masld_Tracking::maslo_Goal::Type             currentState )
      : architectureId(architectureId),
        masla_disposition(masla_disposition),
        masla_startingPoint(masla_startingPoint),
        masla_ID(masla_ID),
        masla_evaluationTimer(masla_evaluationTimer),
        masla_session_startTime(masla_session_startTime),
        masla_spec_sequenceNumber(masla_spec_sequenceNumber),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_Goal::maslo_Goal ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_disposition(),
        masla_startingPoint(),
        masla_ID(),
        masla_evaluationTimer(),
        masla_session_startTime(),
        masla_spec_sequenceNumber(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_Goal::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_Goal::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_GoalPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_Goal::PrimaryKeyType maslo_Goal::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_ID, masla_session_startTime, masla_spec_sequenceNumber );
    }

    const maslo_Goal::IndexKeyType_1 maslo_Goal::get_index_1 ( )
    {
      return IndexKeyType_1( masla_ID, masla_session_startTime, masla_spec_sequenceNumber );
    }

    void maslo_Goal::link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> derivedrhs(rhs.downcast<maslo_GoalSpec>());
      maslo_GoalPopulation::getPopulation().link_R9_specified_by_GoalSpec( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    void maslo_Goal::unlink_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> derivedrhs(rhs.downcast<maslo_GoalSpec>());
      maslo_GoalPopulation::getPopulation().unlink_R9_specified_by_GoalSpec( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_Goal::navigate_R9_specified_by_GoalSpec ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().navigate_R9_specified_by_GoalSpec( self );
    }

    ::std::size_t maslo_Goal::count_R9_specified_by_GoalSpec ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().count_R9_specified_by_GoalSpec( self );
    }

    void maslo_Goal::link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_GoalPopulation::getPopulation().link_R11_is_currently_executing_within_WorkoutSession( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    void maslo_Goal::unlink_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_GoalPopulation::getPopulation().unlink_R11_is_currently_executing_within_WorkoutSession( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_Goal::navigate_R11_is_currently_executing_within_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().navigate_R11_is_currently_executing_within_WorkoutSession( self );
    }

    ::std::size_t maslo_Goal::count_R11_is_currently_executing_within_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().count_R11_is_currently_executing_within_WorkoutSession( self );
    }

    void maslo_Goal::link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> derivedrhs(rhs.downcast<maslo_Achievement>());
      maslo_GoalPopulation::getPopulation().link_R12_has_recorded_Achievement( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    void maslo_Goal::unlink_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> derivedrhs(rhs.downcast<maslo_Achievement>());
      maslo_GoalPopulation::getPopulation().unlink_R12_has_recorded_Achievement( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > maslo_Goal::navigate_R12_has_recorded_Achievement ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().navigate_R12_has_recorded_Achievement( self );
    }

    ::std::size_t maslo_Goal::count_R12_has_recorded_Achievement ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().count_R12_has_recorded_Achievement( self );
    }

    void maslo_Goal::link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_GoalPopulation::getPopulation().link_R13_was_executed_within_WorkoutSession( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    void maslo_Goal::unlink_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_GoalPopulation::getPopulation().unlink_R13_was_executed_within_WorkoutSession( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_Goal::navigate_R13_was_executed_within_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().navigate_R13_was_executed_within_WorkoutSession( self );
    }

    ::std::size_t maslo_Goal::count_R13_was_executed_within_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().count_R13_was_executed_within_WorkoutSession( self );
    }

    void maslo_Goal::link_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> derivedrhs(rhs.downcast<maslo_Achievement>());
      maslo_GoalPopulation::getPopulation().link_R14_has_open_Achievement( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    void maslo_Goal::unlink_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> derivedrhs(rhs.downcast<maslo_Achievement>());
      maslo_GoalPopulation::getPopulation().unlink_R14_has_open_Achievement( ::SWA::ObjectPtr<maslo_Goal>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> maslo_Goal::navigate_R14_has_open_Achievement ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().navigate_R14_has_open_Achievement( self );
    }

    ::std::size_t maslo_Goal::count_R14_has_open_Achievement ( ) const
    {
      ::SWA::ObjectPtr<maslo_Goal> self(const_cast<maslo_Goal*>( this ));
      return maslo_GoalPopulation::getPopulation().count_R14_has_open_Achievement( self );
    }

    void encode_maslo_Goal_maslev_Completed ( ::boost::shared_ptr< ::SWA::Event> event,
                                              BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_Goal_maslev_Completed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_Goal_maslev_Completed() );
    }

    bool registermaslo_Goal_maslev_Completed = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal, ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Completed, &encode_maslo_Goal_maslev_Completed, &decode_maslo_Goal_maslev_Completed );

    void encode_maslo_Goal_maslev_Evaluate ( ::boost::shared_ptr< ::SWA::Event> event,
                                             BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_Goal_maslev_Evaluate ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_Goal_maslev_Evaluate() );
    }

    bool registermaslo_Goal_maslev_Evaluate = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal, ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Evaluate, &encode_maslo_Goal_maslev_Evaluate, &decode_maslo_Goal_maslev_Evaluate );

    void encode_maslo_Goal_maslev_Pause ( ::boost::shared_ptr< ::SWA::Event> event,
                                          BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_Goal_maslev_Pause ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_Goal_maslev_Pause() );
    }

    bool registermaslo_Goal_maslev_Pause = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal, ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Pause, &encode_maslo_Goal_maslev_Pause, &decode_maslo_Goal_maslev_Pause );

    void encode_maslo_Goal_maslev_evaluationComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                       BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_Goal_maslev_evaluationComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_Goal_maslev_evaluationComplete() );
    }

    bool registermaslo_Goal_maslev_evaluationComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal, ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_evaluationComplete, &encode_maslo_Goal_maslev_evaluationComplete, &decode_maslo_Goal_maslev_evaluationComplete );

  }
}
