//
// File: Sqlite__Tracking__R10Mapper.hh
//
#ifndef Sqlite_Tracking_R_10_Mapper_hh
#define Sqlite_Tracking_R_10_Mapper_hh

#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToManyRelationship<10,maslo_WorkoutSession,maslo_GoalSpec,false,true>::mapper_type RelationshipR10Mapper;
  }
}
#endif // Sqlite_Tracking_R_10_Mapper_hh
