//
// File: Sqlite__Tracking__WorkoutSessionPopulation.hh
//
#ifndef Sqlite_Tracking_Workout_Session_Population_hh
#define Sqlite_Tracking_Workout_Session_Population_hh

#include "Sqlite__Tracking__R10Mapper.hh"
#include "Sqlite__Tracking__R11Mapper.hh"
#include "Sqlite__Tracking__R13Mapper.hh"
#include "Sqlite__Tracking__R4Mapper.hh"
#include "Sqlite__Tracking__R6Mapper.hh"
#include "Sqlite__Tracking__R7Mapper.hh"
#include "Sqlite__Tracking__R8Mapper.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionMapper.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutSessionPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Display;
  }
  namespace masld_Tracking
  {
    class maslo_WorkoutTimer;
  }
  namespace masld_Tracking
  {
    class maslo_TrackLog;
  }
  namespace masld_Tracking
  {
    class maslo_HeartRateSample;
  }
  namespace masld_Tracking
  {
    class maslo_GoalSpec;
  }
  namespace masld_Tracking
  {
    class maslo_Goal;
  }
}
namespace masld_Tracking
{
  class maslo_Display;
  class maslo_WorkoutTimer;
  class maslo_TrackLog;
  class maslo_HeartRateSample;
  class maslo_GoalSpec;
  class maslo_Goal;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSessionPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_WorkoutSession,maslo_WorkoutSession,maslo_WorkoutSessionMapper,::masld_Tracking::maslo_WorkoutSessionPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_WorkoutSessionPopulation ( );
        ~maslo_WorkoutSessionPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                           double                  masla_accumulatedDistance );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::std::size_t count_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::std::size_t count_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::std::size_t count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::std::size_t count_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::std::size_t count_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::std::size_t count_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );


      // Relationship Links
      public:
        void link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                           const ::SWA::ObjectPtr<maslo_Display>&        rhs );
        void unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                             const ::SWA::ObjectPtr<maslo_Display>&        rhs );
        void link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                const ::SWA::ObjectPtr<maslo_WorkoutTimer>&   rhs );
        void unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                  const ::SWA::ObjectPtr<maslo_WorkoutTimer>&   rhs );
        void link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                 const ::SWA::ObjectPtr<maslo_TrackLog>&       rhs );
        void unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                   const ::SWA::ObjectPtr<maslo_TrackLog>&       rhs );
        void link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>&  lhs,
                                                                      const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs );
        void unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>&  lhs,
                                                                        const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs );
        void link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                          const ::SWA::ObjectPtr<maslo_GoalSpec>&       rhs );
        void unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                            const ::SWA::ObjectPtr<maslo_GoalSpec>&       rhs );
        void link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                    const ::SWA::ObjectPtr<maslo_Goal>&           rhs );
        void unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                      const ::SWA::ObjectPtr<maslo_Goal>&           rhs );
        void link_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                          const ::SWA::ObjectPtr<maslo_Goal>&           rhs );
        void unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                            const ::SWA::ObjectPtr<maslo_Goal>&           rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> navigate_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> navigate_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > navigate_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > navigate_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs );


      // Singleton Registration
      public:
        static maslo_WorkoutSessionPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR7Mapper& R7Mapper;
        RelationshipR8Mapper& R8Mapper;
        RelationshipR4Mapper& R4Mapper;
        RelationshipR6Mapper& R6Mapper;
        RelationshipR10Mapper& R10Mapper;
        RelationshipR11Mapper& R11Mapper;
        RelationshipR13Mapper& R13Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Session_Population_hh
