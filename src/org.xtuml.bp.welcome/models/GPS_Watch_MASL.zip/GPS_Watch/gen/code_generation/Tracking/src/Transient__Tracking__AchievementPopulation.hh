//
// File: Transient__Tracking__AchievementPopulation.hh
//
#ifndef Transient_Tracking_Achievement_Population_hh
#define Transient_Tracking_Achievement_Population_hh

#include "__Tracking__Achievement.hh"
#include "__Tracking__AchievementPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_AchievementPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_Achievement,::masld_Tracking::maslo_AchievementPopulation>
    {

      // Instance Creation
      private:
        maslo_AchievementPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> createInstance ( int32_t                 masla_startTime,
                                                                                        int32_t                 masla_endTime,
                                                                                        const ::SWA::Timestamp& masla_session_startTime,
                                                                                        int32_t                 masla_goal_ID,
                                                                                        int32_t                 masla_spec_sequenceNumber );


      // Singleton Registration
      public:
        static maslo_AchievementPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp,int32_t,int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance );
      protected:
        bool exists_masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber ( int32_t                 masla_startTime,
                                                                                                   const ::SWA::Timestamp& masla_session_startTime,
                                                                                                   int32_t                 masla_goal_ID,
                                                                                                   int32_t                 masla_spec_sequenceNumber ) const;


    };
  }
}
#endif // Transient_Tracking_Achievement_Population_hh
