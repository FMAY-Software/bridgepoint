//
// File: Transient__Tracking__LapMarkerPopulation.cc
//
#include "Transient__Tracking__LapMarker.hh"
#include "Transient__Tracking__LapMarkerPopulation.hh"
#include "__Tracking__LapMarker.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_LapMarkerPopulation::maslo_LapMarkerPopulation ( )
      : masla_lapTimemasla_session_startTime_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> maslo_LapMarkerPopulation::createInstance ( int32_t                 masla_lapTime,
                                                                                                     const ::SWA::Timestamp& masla_session_startTime )
    {
      if ( exists_masla_lapTimemasla_session_startTime( masla_lapTime, masla_session_startTime ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance(new maslo_LapMarker(  masla_lapTime,
                      masla_session_startTime ));
      addInstance( instance );
      return instance;
    }

    void maslo_LapMarkerPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance )
    {
      masla_lapTimemasla_session_startTime_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> >::value_type( ::boost::make_tuple( instance->get_masla_lapTime(), instance->get_masla_session_startTime() ), instance ) );
    }

    void maslo_LapMarkerPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance )
    {
      masla_lapTimemasla_session_startTime_Lookup.erase( ::boost::make_tuple( instance->get_masla_lapTime(), instance->get_masla_session_startTime() ) );
    }

    bool maslo_LapMarkerPopulation::exists_masla_lapTimemasla_session_startTime ( int32_t                 masla_lapTime,
                                                                                  const ::SWA::Timestamp& masla_session_startTime ) const
    {
      return masla_lapTimemasla_session_startTime_Lookup.find( ::boost::make_tuple( masla_lapTime, masla_session_startTime ) ) != masla_lapTimemasla_session_startTime_Lookup.end();
    }

    maslo_LapMarkerPopulation& maslo_LapMarkerPopulation::getPopulation ( )
    {
      static maslo_LapMarkerPopulation population;
      return population;
    }

    bool maslo_LapMarkerPopulation::registered = maslo_LapMarkerPopulation::registerSingleton( &maslo_LapMarkerPopulation::getPopulation );

  }
}
