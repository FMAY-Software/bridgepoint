//
// File: Sqlite__Tracking__R1MapperSql.cc
//
#include "Sqlite__Tracking__R1MapperSql.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <sstream>
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE Tracking_R1_LINK_TABLE (R1_lhs INTEGER, R1_rhs INTEGER, PRIMARY KEY (R1_lhs,R1_rhs));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "Tracking_R1_LINK_TABLE", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    RelationshipR1SqlGenerator::RelationshipR1SqlGenerator ( )
      : tableName("Tracking_R1_LINK_TABLE"),
        relationshipName("Tracking_R1"),
        pepreparedLink("INSERT INTO Tracking_R1_LINK_TABLE VALUES(:1,:2);"),
        pepreparedUnlink("DELETE FROM Tracking_R1_LINK_TABLE WHERE R1_lhs = :1 AND R1_rhs= :2;")
    {
    }

    void RelationshipR1SqlGenerator::initialise ( )
    {
      pepreparedLink.prepare();
      pepreparedUnlink.prepare();
    }

    const ::std::string& RelationshipR1SqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string RelationshipR1SqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string RelationshipR1SqlGenerator::getLhsColumnName ( ) const
    {
      return "R1_lhs";
    }

    const ::std::string RelationshipR1SqlGenerator::getRhsColumnName ( ) const
    {
      return "R1_rhs";
    }

    const ::std::string& RelationshipR1SqlGenerator::getRelationshipName ( ) const
    {
      return relationshipName;
    }

    ::SWA::IdType RelationshipR1SqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM Tracking_R1_LINK_TABLE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "RelationshipR1SqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "RelationshipR1SqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    void RelationshipR1SqlGenerator::commitLink ( const LinkedPairType& linkObjects ) const
    {
      pepreparedLink.execute( ::boost::make_tuple( linkObjects.first.getChecked()->getArchitectureId(), linkObjects.second.getChecked()->getArchitectureId() ) );
    }

    void RelationshipR1SqlGenerator::commitUnlink ( const LinkedPairType& unlinkObjects ) const
    {
      pepreparedUnlink.execute( ::boost::make_tuple( unlinkObjects.first.getChecked()->getArchitectureId(), unlinkObjects.second.getChecked()->getArchitectureId() ) );
    }

    void RelationshipR1SqlGenerator::loadAll ( LhsToRhsContainerType& lhsToRhsLinkSet,
                                               RhsToLhsContainerType& rhsToLhsLinkSet ) const
    {
      const ::std::string query("SELECT R1_lhs,R1_rhs FROM Tracking_R1_LINK_TABLE;");

      Database& database = Database::singleton();

      sqlite3_stmt* ppStmt = 0;
      Database::ScopedFinalise finaliser("R1::loadAll", ppStmt);
      int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

      database.checkCompile( "R1::loadAll", compile_result, query );
      database.checkColumnCount( "R1::loadAll", sqlite3_column_count( ppStmt ), 2, query );

      while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
      {

        int32_t lhsColumnValue = sqlite3_column_int( ppStmt, 0 );

        int32_t rhsColumnValue = sqlite3_column_int( ppStmt, 1 );
        lhsToRhsLinkSet[lhsColumnValue].link( rhsColumnValue );
        rhsToLhsLinkSet[rhsColumnValue].link( lhsColumnValue );
      }
      SqlQueryMonitor queryMonitor(query);
    }

    void RelationshipR1SqlGenerator::loadLhs ( const ::SWA::IdType&   rhsIdentity,
                                               LhsToRhsContainerType& lhsToRhsLinkSet,
                                               RhsToLhsContainerType& rhsToLhsLinkSet ) const
    {
      ::std::ostringstream query;
      query << "SELECT R1_lhs FROM Tracking_R1_LINK_TABLE WHERE R1_rhs = " << rhsIdentity << ";";

      Database& database = Database::singleton();

      sqlite3_stmt* ppStmt = 0;
      Database::ScopedFinalise finaliser("R1::loadLhs", ppStmt);
      int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.str().c_str(), -1, &ppStmt, 0 );

      database.checkCompile( "R1::loadLhs", compile_result, query.str() );
      database.checkColumnCount( "R1::loadLhs", sqlite3_column_count( ppStmt ), 1, query.str() );

      while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
      {

        int32_t lhsColumnValue = sqlite3_column_int( ppStmt, 0 );
        rhsToLhsLinkSet[rhsIdentity].link( lhsColumnValue );
        lhsToRhsLinkSet[lhsColumnValue].link( rhsIdentity );
      }
      SqlQueryMonitor queryMonitor(query.str());
    }

    void RelationshipR1SqlGenerator::loadRhs ( const ::SWA::IdType&   lhsIdentity,
                                               LhsToRhsContainerType& lhsToRhsLinkSet,
                                               RhsToLhsContainerType& rhsToLhsLinkSet ) const
    {
      ::std::ostringstream query;
      query << "SELECT R1_rhs FROM Tracking_R1_LINK_TABLE WHERE R1_lhs = " << lhsIdentity << ";";

      Database& database = Database::singleton();

      sqlite3_stmt* ppStmt = 0;
      Database::ScopedFinalise finaliser("R1::loadRhs", ppStmt);
      int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.str().c_str(), -1, &ppStmt, 0 );

      database.checkCompile( "R1::loadRhs", compile_result, query.str() );
      database.checkColumnCount( "R1::loadRhs", sqlite3_column_count( ppStmt ), 1, query.str() );

      while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
      {

        int32_t rhsColumnValue = sqlite3_column_int( ppStmt, 0 );
        lhsToRhsLinkSet[lhsIdentity].link( rhsColumnValue );
        rhsToLhsLinkSet[rhsColumnValue].link( lhsIdentity );
      }
      SqlQueryMonitor queryMonitor(query.str());
    }

  }
}
