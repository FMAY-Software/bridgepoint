//
// File: Transient__Tracking__WorkoutTimer.cc
//
#include "Transient__Tracking__WorkoutSession.hh"
#include "Transient__Tracking__WorkoutTimer.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimer::maslo_WorkoutTimer ( int32_t                                    masla_time,
                                             const ::SWA::EventTimers::TimerIdType&     masla_timer,
                                             const ::SWA::Timestamp&                    masla_session_startTime,
                                             ::masld_Tracking::maslo_WorkoutTimer::Type currentState )
      : architectureId(getNextArchId()),
        masla_time(masla_time),
        masla_timer(masla_timer),
        masla_session_startTime(masla_session_startTime),
        currentState(currentState),
        R8_acts_as_the_stopwatch_for_WorkoutSession()
    {
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_WorkoutTimer::get_R8_acts_as_the_stopwatch_for_WorkoutSession ( )
    {
      return R8_acts_as_the_stopwatch_for_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_WorkoutTimer::get_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const
    {
      return R8_acts_as_the_stopwatch_for_WorkoutSession;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_WorkoutTimer::navigate_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const
    {
      return get_R8_acts_as_the_stopwatch_for_WorkoutSession().navigate();
    }

    ::std::size_t maslo_WorkoutTimer::count_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const
    {
      return get_R8_acts_as_the_stopwatch_for_WorkoutSession().count();
    }

    void maslo_WorkoutTimer::link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R8_acts_as_the_stopwatch_for_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R8_is_timed_by_WorkoutTimer().link( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ) );
      }
      catch ( ... )
      {
        this->get_R8_acts_as_the_stopwatch_for_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutTimer::unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R8_acts_as_the_stopwatch_for_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R8_is_timed_by_WorkoutTimer().unlink( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ) );
      }
      catch ( ... )
      {
        this->get_R8_acts_as_the_stopwatch_for_WorkoutSession().link( rhs2 );
        throw;
      }
    }

  }
}
