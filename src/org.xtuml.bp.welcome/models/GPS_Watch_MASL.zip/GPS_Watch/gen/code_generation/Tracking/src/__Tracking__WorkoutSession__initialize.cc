//
// File: __Tracking__WorkoutSession__initialize.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"

namespace masld_Tracking
{
  void maslo_WorkoutSession::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutSession, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(6);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(1, maslv_workoutTimer);

        // trackLog : instance of TrackLog;
        ::SWA::ObjectPtr<maslo_TrackLog> maslv_trackLog;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_trackLog(2, maslv_trackLog);

        // display : instance of Display;
        ::SWA::ObjectPtr<maslo_Display> maslv_display;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_display(3, maslv_display);

        // session := find_one WorkoutSession ();
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          maslv_session = findOne();
        }

        // if (null = session) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          if ( ::SWA::Null == maslv_session )
          {

            // session := create WorkoutSession (
            //            startTime => timestamp'now );
            {
              ::SWA::Stack::ExecutingStatement statement(15);
              maslv_session = createInstance( ::SWA::Timestamp::now(), double() );
            }

            // session.accumulatedDistance := 0.0;
            {
              ::SWA::Stack::ExecutingStatement statement(17);
              maslv_session->set_masla_accumulatedDistance( 0.0 );
            }

            // workoutTimer := create WorkoutTimer (
            //               session_startTime => session.startTime ,
            // Current_State => stopped);
            {
              ::SWA::Stack::ExecutingStatement statement(20);
              maslv_workoutTimer = maslo_WorkoutTimer::createInstance( int32_t(), ::SWA::EventTimers::getInstance().createTimer(), maslv_session->get_masla_startTime(), maslo_WorkoutTimer::maslst_stopped );
            }

            // workoutTimer.initialize()
            {
              ::SWA::Stack::ExecutingStatement statement(21);
              maslv_workoutTimer->masls_initialize();
            }

            // trackLog := create TrackLog (
            //            session_startTime => session.startTime );
            {
              ::SWA::Stack::ExecutingStatement statement(24);
              maslv_trackLog = maslo_TrackLog::createInstance( maslv_session->get_masla_startTime() );
            }

            // display := create Display (
            //               session_startTime => session.startTime ,
            // Current_State => displayDistance);
            {
              ::SWA::Stack::ExecutingStatement statement(27);
              maslv_display = maslo_Display::createInstance( maslv_session->get_masla_startTime(), maslo_Display::maslst_displayDistance );
            }

            // link trackLog R4.represents_path_for.WorkoutSession  session;
            {
              ::SWA::Stack::ExecutingStatement statement(30);
              maslv_trackLog->checked_link_R4_represents_path_for_WorkoutSession( maslv_session );
            }

            // link workoutTimer R8.acts_as_the_stopwatch_for.WorkoutSession  session;
            {
              ::SWA::Stack::ExecutingStatement statement(31);
              maslv_workoutTimer->checked_link_R8_acts_as_the_stopwatch_for_WorkoutSession( maslv_session );
            }

            // link display R7.indicates_current_status_of.WorkoutSession  session;
            {
              ::SWA::Stack::ExecutingStatement statement(32);
              maslv_display->checked_link_R7_indicates_current_status_of_WorkoutSession( maslv_session );
            }
          }
        }
      }
    }
  }

}
