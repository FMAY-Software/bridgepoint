//
// File: Sqlite__Tracking__GoalSpecMapperSql.cc
//
#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__GoalSpecMapperSql.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__GoalSpec.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Tracking_GOALSPEC(   architecture_id  INTEGER ,   masla_minimum REAL,   masla_maximum REAL,   masla_span REAL,   masla_criteriaType TEXT,   masla_spanType TEXT,   masla_sequenceNumber INTEGER,   masla_session_startTime INTEGER,   masla_last_goal_ID INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Tracking_GOALSPEC", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecSqlGenerator::maslo_GoalSpecSqlGenerator ( )
      : tableName("S_Tracking_GOALSPEC"),
        objectName("GoalSpec"),
        insertStatement("INSERT INTO S_Tracking_GOALSPEC VALUES(:1,:2,:3,:4,:5,:6,:7,:8,:9);"),
        updateStatement("UPDATE S_Tracking_GOALSPEC SET masla_minimum = :2  , masla_maximum = :3  , masla_span = :4  , masla_criteriaType = :5  , masla_spanType = :6  , masla_sequenceNumber = :7  , masla_session_startTime = :8  , masla_last_goal_ID = :9  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Tracking_GOALSPEC WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_GoalSpecSqlGenerator::~maslo_GoalSpecSqlGenerator ( )
    {
    }

    void maslo_GoalSpecSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["minimum"] = ::std::string( "masla_minimum" );
      columnNameMapper["maximum"] = ::std::string( "masla_maximum" );
      columnNameMapper["span"] = ::std::string( "masla_span" );
      columnNameMapper["criteriaType"] = ::std::string( "masla_criteriaType" );
      columnNameMapper["spanType"] = ::std::string( "masla_spanType" );
      columnNameMapper["sequenceNumber"] = ::std::string( "masla_sequenceNumber" );
      columnNameMapper["session_startTime"] = ::std::string( "masla_session_startTime" );
      columnNameMapper["last_goal_ID"] = ::std::string( "masla_last_goal_ID" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_GoalSpecSqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string& maslo_GoalSpecSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_GoalSpecSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_GoalSpecSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_GoalSpecSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_GoalSpecSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_GOALSPEC;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GoalSpecSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GoalSpecSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_GoalSpecSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_GOALSPEC;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GoalSpecSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GoalSpecSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_GoalSpecSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Tracking_GOALSPEC;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GoalSpecSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GoalSpecSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_GoalSpecSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_GoalSpecSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_minimum(), object.getChecked()->get_masla_maximum(), object.getChecked()->get_masla_span(), object.getChecked()->get_masla_criteriaType().getText(), object.getChecked()->get_masla_spanType().getText(), object.getChecked()->get_masla_sequenceNumber(), object.getChecked()->get_masla_session_startTime(), object.getChecked()->get_masla_last_goal_ID() ) );
    }

    void maslo_GoalSpecSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_minimum(), object.getChecked()->get_masla_maximum(), object.getChecked()->get_masla_span(), object.getChecked()->get_masla_criteriaType().getText(), object.getChecked()->get_masla_spanType().getText(), object.getChecked()->get_masla_sequenceNumber(), object.getChecked()->get_masla_session_startTime(), object.getChecked()->get_masla_last_goal_ID() ) );
    }

    void maslo_GoalSpecSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_GoalSpecSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_GoalSpecSqlGenerator::executeSelect ( CacheType&             cache,
                                                     const ::SQL::Criteria& criteria,
                                                     PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("GoalSpec::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "GoalSpec::executeSelect", compile_result, query );
        database.checkColumnCount( "GoalSpec::executeSelect", sqlite3_column_count( ppStmt ), 9, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_GoalSpec(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            double minimum = sqlite3_column_double( ppStmt, 1 );
            currentObject->set_masla_minimum( minimum );

            double maximum = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_maximum( maximum );

            double span = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_span( span );

            ::std::string criteriaType = reinterpret_cast<const char*>( sqlite3_column_text( ppStmt, 4 ) );
            ::masld_Tracking::maslt_GoalCriteria column4(criteriaType);
            currentObject->set_masla_criteriaType( column4 );

            ::std::string spanType = reinterpret_cast<const char*>( sqlite3_column_text( ppStmt, 5 ) );
            ::masld_Tracking::maslt_GoalSpan column5(spanType);
            currentObject->set_masla_spanType( column5 );

            int32_t sequenceNumber = sqlite3_column_int( ppStmt, 6 );
            currentObject->set_masla_sequenceNumber( sequenceNumber );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 7 ) );
            currentObject->set_masla_session_startTime( session_startTime );

            int32_t last_goal_ID = sqlite3_column_int( ppStmt, 8 );
            currentObject->set_masla_last_goal_ID( last_goal_ID );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_GoalSpecSqlGenerator::executeSelect ( CacheType&             cache,
                                                     const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("GoalSpec::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "GoalSpec::executeSelect", compile_result, query );
        database.checkColumnCount( "GoalSpec::executeSelect", sqlite3_column_count( ppStmt ), 9, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_GoalSpec(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            double minimum = sqlite3_column_double( ppStmt, 1 );
            currentObject->set_masla_minimum( minimum );

            double maximum = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_maximum( maximum );

            double span = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_span( span );

            ::std::string criteriaType = reinterpret_cast<const char*>( sqlite3_column_text( ppStmt, 4 ) );
            ::masld_Tracking::maslt_GoalCriteria column4(criteriaType);
            currentObject->set_masla_criteriaType( column4 );

            ::std::string spanType = reinterpret_cast<const char*>( sqlite3_column_text( ppStmt, 5 ) );
            ::masld_Tracking::maslt_GoalSpan column5(spanType);
            currentObject->set_masla_spanType( column5 );

            int32_t sequenceNumber = sqlite3_column_int( ppStmt, 6 );
            currentObject->set_masla_sequenceNumber( sequenceNumber );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 7 ) );
            currentObject->set_masla_session_startTime( session_startTime );

            int32_t last_goal_ID = sqlite3_column_int( ppStmt, 8 );
            currentObject->set_masla_last_goal_ID( last_goal_ID );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
