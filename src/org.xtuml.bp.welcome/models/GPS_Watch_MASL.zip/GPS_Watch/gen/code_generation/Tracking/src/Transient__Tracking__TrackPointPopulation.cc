//
// File: Transient__Tracking__TrackPointPopulation.cc
//
#include "Transient__Tracking__TrackPoint.hh"
#include "Transient__Tracking__TrackPointPopulation.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_TrackPointPopulation::maslo_TrackPointPopulation ( )
      : masla_timemasla_session_startTime_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPointPopulation::createInstance ( int32_t                 masla_time,
                                                                                                       double                  masla_longitude,
                                                                                                       double                  masla_latitude,
                                                                                                       const ::SWA::Timestamp& masla_session_startTime )
    {
      if ( exists_masla_timemasla_session_startTime( masla_time, masla_session_startTime ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance(new maslo_TrackPoint(  masla_time,
                       masla_longitude,
                       masla_latitude,
                       masla_session_startTime ));
      addInstance( instance );
      return instance;
    }

    void maslo_TrackPointPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance )
    {
      masla_timemasla_session_startTime_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >::value_type( ::boost::make_tuple( instance->get_masla_time(), instance->get_masla_session_startTime() ), instance ) );
    }

    void maslo_TrackPointPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance )
    {
      masla_timemasla_session_startTime_Lookup.erase( ::boost::make_tuple( instance->get_masla_time(), instance->get_masla_session_startTime() ) );
    }

    bool maslo_TrackPointPopulation::exists_masla_timemasla_session_startTime ( int32_t                 masla_time,
                                                                                const ::SWA::Timestamp& masla_session_startTime ) const
    {
      return masla_timemasla_session_startTime_Lookup.find( ::boost::make_tuple( masla_time, masla_session_startTime ) ) != masla_timemasla_session_startTime_Lookup.end();
    }

    maslo_TrackPointPopulation& maslo_TrackPointPopulation::getPopulation ( )
    {
      static maslo_TrackPointPopulation population;
      return population;
    }

    bool maslo_TrackPointPopulation::registered = maslo_TrackPointPopulation::registerSingleton( &maslo_TrackPointPopulation::getPopulation );

  }
}
