//
// File: Sqlite__Tracking__HeartRateConstantsPopulation.hh
//
#ifndef Sqlite_Tracking_Heart_Rate_Constants_Population_hh
#define Sqlite_Tracking_Heart_Rate_Constants_Population_hh

#include "Sqlite__Tracking__HeartRateConstants.hh"
#include "Sqlite__Tracking__HeartRateConstantsMapper.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "__Tracking__HeartRateConstantsPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_HeartRateConstantsPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_HeartRateConstants,maslo_HeartRateConstants,maslo_HeartRateConstantsMapper,::masld_Tracking::maslo_HeartRateConstantsPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_HeartRateConstantsPopulation ( );
        ~maslo_HeartRateConstantsPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> createInstance ( int32_t masla_id,
                                                                                               int32_t masla_HeartRateAveragingWindow,
                                                                                               int32_t masla_HeartRateSamplingPeriod );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_HeartRateConstantsPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_Tracking_Heart_Rate_Constants_Population_hh
