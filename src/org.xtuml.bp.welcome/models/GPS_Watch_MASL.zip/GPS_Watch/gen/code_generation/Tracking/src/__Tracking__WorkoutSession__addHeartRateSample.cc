//
// File: __Tracking__WorkoutSession__addHeartRateSample.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/navigate.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_WorkoutSession::masls_addHeartRateSample ( int32_t maslp_heartRate )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutSession, serviceId_masls_addHeartRateSample);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::DeclareParameter pm_maslp_heartRate(maslp_heartRate);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(5);
      {

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(0, maslv_workoutTimer);

        // sample : instance of HeartRateSample;
        ::SWA::ObjectPtr<maslo_HeartRateSample> maslv_sample;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_sample(1, maslv_sample);

        // display : instance of Display;
        ::SWA::ObjectPtr<maslo_Display> maslv_display;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_display(2, maslv_display);

        // workoutTimer := this -> R8.is_timed_by.WorkoutTimer;
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          maslv_workoutTimer = ::SWA::navigate_one<maslo_WorkoutTimer>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer, _1 ) );
        }

        // sample := create HeartRateSample (
        //            session_startTime => this.startTime,
        //            time              => workoutTimer.time );
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          maslv_sample = maslo_HeartRateSample::createInstance( int32_t(), maslv_workoutTimer->get_masla_time(), ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->get_masla_startTime() );
        }

        // sample.heartRate := heartRate;
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          maslv_sample->set_masla_heartRate( maslp_heartRate );
        }

        // link this R6.tracks_heart_rate_over_time_as.HeartRateSample  sample;
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->checked_link_R6_tracks_heart_rate_over_time_as_HeartRateSample( maslv_sample );
        }

        // display := this -> R7.current_status_indicated_on.Display;
        {
          ::SWA::Stack::ExecutingStatement statement(16);
          maslv_display = ::SWA::navigate_one<maslo_Display>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R7_current_status_indicated_on_Display, _1 ) );
        }

        // generate Display.refresh () to display;
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_display->create_maslo_Display_maslev_refresh( objectId_maslo_WorkoutSession, getArchitectureId() ) );
        }
      }
    }
  }

}
