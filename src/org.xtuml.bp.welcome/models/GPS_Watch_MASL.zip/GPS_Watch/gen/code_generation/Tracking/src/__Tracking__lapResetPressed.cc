//
// File: __Tracking__lapResetPressed.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void masls_lapResetPressed ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_lapResetPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(0, maslv_workoutTimer);

        // workoutTimer := find_one WorkoutTimer ();
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_workoutTimer = maslo_WorkoutTimer::findOne();
        }

        // if (null /= workoutTimer) then ...
        // else ...
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          if ( ::SWA::Null != maslv_workoutTimer )
          {

            // generate WorkoutTimer.lapResetPressed () to workoutTimer;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_workoutTimer->create_maslo_WorkoutTimer_maslev_lapResetPressed() );
            }
          }
          else
          {

            // LOG::LogFailure("Tracking:UI:lapResetPressed - No WorkoutTimer, so nothing to do.")
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              ::masld_LOG::interceptor_masls_LogFailure::instance().callService()( ::SWA::String( "Tracking:UI:lapResetPressed - No WorkoutTimer, so nothing to do." ) );
            }
          }
        }
      }
    }
  }

  const bool localServiceRegistration_masls_lapResetPressed = interceptor_masls_lapResetPressed::instance().registerLocal( &masls_lapResetPressed );

}
