//
// File: Transient__Tracking__HeartRateSamplePopulation.cc
//
#include "Transient__Tracking__HeartRateSample.hh"
#include "Transient__Tracking__HeartRateSamplePopulation.hh"
#include "__Tracking__HeartRateSample.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_HeartRateSamplePopulation::maslo_HeartRateSamplePopulation ( )
      : masla_timemasla_session_startTime_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> maslo_HeartRateSamplePopulation::createInstance ( int32_t                 masla_heartRate,
                                                                                                                 int32_t                 masla_time,
                                                                                                                 const ::SWA::Timestamp& masla_session_startTime )
    {
      if ( exists_masla_timemasla_session_startTime( masla_time, masla_session_startTime ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance(new maslo_HeartRateSample(  masla_heartRate,
                            masla_time,
                            masla_session_startTime ));
      addInstance( instance );
      return instance;
    }

    void maslo_HeartRateSamplePopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance )
    {
      masla_timemasla_session_startTime_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >::value_type( ::boost::make_tuple( instance->get_masla_time(), instance->get_masla_session_startTime() ), instance ) );
    }

    void maslo_HeartRateSamplePopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance )
    {
      masla_timemasla_session_startTime_Lookup.erase( ::boost::make_tuple( instance->get_masla_time(), instance->get_masla_session_startTime() ) );
    }

    bool maslo_HeartRateSamplePopulation::exists_masla_timemasla_session_startTime ( int32_t                 masla_time,
                                                                                     const ::SWA::Timestamp& masla_session_startTime ) const
    {
      return masla_timemasla_session_startTime_Lookup.find( ::boost::make_tuple( masla_time, masla_session_startTime ) ) != masla_timemasla_session_startTime_Lookup.end();
    }

    maslo_HeartRateSamplePopulation& maslo_HeartRateSamplePopulation::getPopulation ( )
    {
      static maslo_HeartRateSamplePopulation population;
      return population;
    }

    bool maslo_HeartRateSamplePopulation::registered = maslo_HeartRateSamplePopulation::registerSingleton( &maslo_HeartRateSamplePopulation::getPopulation );

  }
}
