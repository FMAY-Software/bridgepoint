//
// File: __Tracking__WorkoutTimer__processingStart.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_WorkoutTimer::state_maslst_processingStart ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutTimer, stateId_maslst_processingStart);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // this.activate()
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::SWA::ObjectPtr<maslo_WorkoutTimer>( this )->masls_activate();
        }

        // generate WorkoutTimer.startTimer () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this )->create_maslo_WorkoutTimer_maslev_startTimer( objectId_maslo_WorkoutTimer, getArchitectureId() ) );
        }
      }
    }
  }

}
