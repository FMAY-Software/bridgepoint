//
// File: __Tracking__Speed.cc
//
#include "__Tracking__Speed.hh"
#include "__Tracking__SpeedPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_Speed> maslo_Speed::getInstance ( ::SWA::IdType id )
  {
    return maslo_SpeedPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_Speed::getNextArchId ( )
  {
    return maslo_SpeedPopulation::getSingleton().getNextArchId();
  }

  maslo_Speed::maslo_Speed ( )
    : isDeletedFlag()
  {
  }

  maslo_Speed::~maslo_Speed ( )
  {
  }

  ::SWA::ObjectPtr<maslo_Speed> maslo_Speed::createInstance ( int32_t masla_id,
                                                              int32_t masla_SpeedAveragingWindow,
                                                              int32_t masla_SecondsPerHour )
  {
    return maslo_SpeedPopulation::getSingleton().createInstance( masla_id, masla_SpeedAveragingWindow, masla_SecondsPerHour );
  }

  void maslo_Speed::deleteInstance ( )
  {
    maslo_SpeedPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_Speed>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_Speed::getPopulationSize ( )
  {
    return maslo_SpeedPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_Speed> > maslo_Speed::findAll ( )
  {
    return maslo_SpeedPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_Speed> maslo_Speed::findOne ( )
  {
    return maslo_SpeedPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_Speed> maslo_Speed::findOnly ( )
  {
    return maslo_SpeedPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&    stream,
                               const maslo_Speed& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_SpeedAveragingWindow();
    stream << ",";
    stream << obj.get_masla_SecondsPerHour();
    stream << ")";
    return stream;
  }

}
