//
// File: __Tracking__WorkoutTimer.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "__Tracking__WorkoutTimerEvents.hh"
#include "__Tracking__WorkoutTimerPopulation.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_WorkoutTimer> maslo_WorkoutTimer::getInstance ( ::SWA::IdType id )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_WorkoutTimer::getNextArchId ( )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().getNextArchId();
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_startStopPressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_stopped:
      {
        state_maslst_processingStart();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_processingStart );
        setCurrentState( maslst_processingStart );
        break;
      }
      case maslst_running:
      {
        state_maslst_paused();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_paused );
        setCurrentState( maslst_paused );
        break;
      }
      case maslst_paused:
      {
        state_maslst_processingStart();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_processingStart );
        setCurrentState( maslst_processingStart );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_startStopPressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_startStopPressed ( int           sourceObj,
                                                                                                             ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_startStopPressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_startStopPressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_startStopPressed();
  }

  int Event_maslo_WorkoutTimer_maslev_startStopPressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_startStopPressed::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_startStopPressed::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startStopPressed;
  }

  Event_maslo_WorkoutTimer_maslev_startStopPressed::Event_maslo_WorkoutTimer_maslev_startStopPressed ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_startStopPressed::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_startStopPressed( getDestInstanceId() );
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_lapResetPressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_stopped:
        /* Ignore */
        break;

      case maslst_running:
      {
        state_maslst_resetLap();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_resetLap );
        setCurrentState( maslst_resetLap );
        break;
      }
      case maslst_paused:
      {
        state_maslst_stopped();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_stopped );
        setCurrentState( maslst_stopped );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_lapResetPressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_lapResetPressed ( int           sourceObj,
                                                                                                            ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_lapResetPressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_lapResetPressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_lapResetPressed();
  }

  int Event_maslo_WorkoutTimer_maslev_lapResetPressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_lapResetPressed::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_lapResetPressed::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetPressed;
  }

  Event_maslo_WorkoutTimer_maslev_lapResetPressed::Event_maslo_WorkoutTimer_maslev_lapResetPressed ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_lapResetPressed::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_lapResetPressed( getDestInstanceId() );
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_tick ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_stopped:
        /* Ignore */
        break;

      case maslst_running:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      case maslst_paused:
        /* Ignore */
        break;

      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_tick ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_tick ( int           sourceObj,
                                                                                                 ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_tick());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_tick ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_tick();
  }

  int Event_maslo_WorkoutTimer_maslev_tick::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_tick::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_tick::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_tick;
  }

  Event_maslo_WorkoutTimer_maslev_tick::Event_maslo_WorkoutTimer_maslev_tick ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_tick::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_tick( getDestInstanceId() );
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_pause ( )
  {
    switch ( getCurrentState() )
    {
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_pause ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_pause ( int           sourceObj,
                                                                                                  ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_pause());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_pause ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_pause();
  }

  int Event_maslo_WorkoutTimer_maslev_pause::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_pause::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_pause::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_pause;
  }

  Event_maslo_WorkoutTimer_maslev_pause::Event_maslo_WorkoutTimer_maslev_pause ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_pause::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_pause( getDestInstanceId() );
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_resume ( )
  {
    switch ( getCurrentState() )
    {
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_resume ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_resume ( int           sourceObj,
                                                                                                   ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_resume());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_resume ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_resume();
  }

  int Event_maslo_WorkoutTimer_maslev_resume::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_resume::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_resume::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_resume;
  }

  Event_maslo_WorkoutTimer_maslev_resume::Event_maslo_WorkoutTimer_maslev_resume ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_resume::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_resume( getDestInstanceId() );
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_startTimer ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_processingStart:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_startTimer ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_startTimer ( int           sourceObj,
                                                                                                       ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_startTimer());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_startTimer ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_startTimer();
  }

  int Event_maslo_WorkoutTimer_maslev_startTimer::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_startTimer::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_startTimer::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startTimer;
  }

  Event_maslo_WorkoutTimer_maslev_startTimer::Event_maslo_WorkoutTimer_maslev_startTimer ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_startTimer::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_startTimer( getDestInstanceId() );
  }

  void maslo_WorkoutTimer::process_maslo_WorkoutTimer_maslev_lapResetComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_resetLap:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_WorkoutTimer, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_WorkoutTimer, eventId_maslo_WorkoutTimer_maslev_lapResetComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_WorkoutTimer ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_WorkoutTimer, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer::create_maslo_WorkoutTimer_maslev_lapResetComplete ( int           sourceObj,
                                                                                                             ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_WorkoutTimer_maslev_lapResetComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_lapResetComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_WorkoutTimer> instance = getInstance( id );
    if ( instance ) instance->process_maslo_WorkoutTimer_maslev_lapResetComplete();
  }

  int Event_maslo_WorkoutTimer_maslev_lapResetComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_WorkoutTimer_maslev_lapResetComplete::getObjectId ( ) const
  {
    return objectId_maslo_WorkoutTimer;
  }

  int Event_maslo_WorkoutTimer_maslev_lapResetComplete::getEventId ( ) const
  {
    return maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetComplete;
  }

  Event_maslo_WorkoutTimer_maslev_lapResetComplete::Event_maslo_WorkoutTimer_maslev_lapResetComplete ( )
  {
  }

  void Event_maslo_WorkoutTimer_maslev_lapResetComplete::invoke ( ) const
  {
    maslo_WorkoutTimer::consume_maslo_WorkoutTimer_maslev_lapResetComplete( getDestInstanceId() );
  }

  maslo_WorkoutTimer::maslo_WorkoutTimer ( )
    : isDeletedFlag()
  {
  }

  maslo_WorkoutTimer::~maslo_WorkoutTimer ( )
  {
  }

  ::SWA::ObjectPtr<maslo_WorkoutTimer> maslo_WorkoutTimer::createInstance ( int32_t                                masla_time,
                                                                            const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                            const ::SWA::Timestamp&                masla_session_startTime,
                                                                            Type                                   currentState )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().createInstance( masla_time, masla_timer, masla_session_startTime, currentState );
  }

  void maslo_WorkoutTimer::deleteInstance ( )
  {
    if ( count_R8_acts_as_the_stopwatch_for_WorkoutSession() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R8 still linked" );
    maslo_WorkoutTimerPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ) );
    ::SWA::EventTimers::getInstance().deleteTimer( get_masla_timer() );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_WorkoutTimer::getPopulationSize ( )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutTimer> > maslo_WorkoutTimer::findAll ( )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_WorkoutTimer> maslo_WorkoutTimer::findOne ( )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_WorkoutTimer> maslo_WorkoutTimer::findOnly ( )
  {
    return maslo_WorkoutTimerPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_WorkoutTimer::count_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const
  {
    return navigate_R8_acts_as_the_stopwatch_for_WorkoutSession() == ::SWA::Null ? 0
                                                                                 : 1;
  }

  void maslo_WorkoutTimer::checked_link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R8_acts_as_the_stopwatch_for_WorkoutSession( rhs );
  }

  void maslo_WorkoutTimer::unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs = navigate_R8_acts_as_the_stopwatch_for_WorkoutSession();
    if ( rhs ) unlink_R8_acts_as_the_stopwatch_for_WorkoutSession( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&           stream,
                               const maslo_WorkoutTimer& obj )
  {
    stream << "(";
    stream << obj.get_masla_time();
    stream << ",";
    stream << obj.get_masla_timer();
    stream << ",";
    stream << obj.get_masla_session_startTime();
    stream << ")";
    return stream;
  }

}
