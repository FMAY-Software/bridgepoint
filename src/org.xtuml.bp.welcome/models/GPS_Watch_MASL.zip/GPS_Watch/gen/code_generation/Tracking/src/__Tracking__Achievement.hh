//
// File: __Tracking__Achievement.hh
//
#ifndef _Tracking_Achievement_hh
#define _Tracking_Achievement_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_Goal;
  class maslo_Achievement;
  class maslo_Achievement
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_Achievement> createInstance ( int32_t                 masla_startTime,
                                                                  int32_t                 masla_endTime,
                                                                  const ::SWA::Timestamp& masla_session_startTime,
                                                                  int32_t                 masla_goal_ID,
                                                                  int32_t                 masla_spec_sequenceNumber );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_Achievement> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_endTime ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_startTime ( ) const = 0;
      virtual int32_t get_masla_endTime ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;
      virtual int32_t get_masla_goal_ID ( ) const = 0;
      virtual int32_t get_masla_spec_sequenceNumber ( ) const = 0;


    // Instance Services
    public:
      void masls_close ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_Achievement> > findAll ( );
      static ::SWA::ObjectPtr<maslo_Achievement> findOne ( );
      static ::SWA::ObjectPtr<maslo_Achievement> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_Achievement ( );
      virtual ~maslo_Achievement ( );


    // Prevent copy
    private:
      maslo_Achievement ( const maslo_Achievement& rhs );
      maslo_Achievement& operator= ( const maslo_Achievement& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_close };


    // Relationship R12.specifies_achievement_of.Goal
    public:
      virtual ::SWA::ObjectPtr<maslo_Goal> navigate_R12_specifies_achievement_of_Goal ( ) const = 0;
      virtual ::std::size_t count_R12_specifies_achievement_of_Goal ( ) const;
      virtual void link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      void checked_link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs );
      virtual void unlink_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void unlink_R12_specifies_achievement_of_Goal ( );


    // Relationship R14.is_open_for.Goal
    public:
      virtual ::SWA::ObjectPtr<maslo_Goal> navigate_R14_is_open_for_Goal ( ) const = 0;
      virtual ::std::size_t count_R14_is_open_for_Goal ( ) const;
      virtual void link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      void checked_link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs );
      virtual void unlink_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void unlink_R14_is_open_for_Goal ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&          stream,
                               const maslo_Achievement& obj );
}
#endif // _Tracking_Achievement_hh
