//
// File: __Tracking__DisplayEvents.hh
//
#ifndef _Tracking_Display_Events_hh
#define _Tracking_Display_Events_hh

#include "swa/Event.hh"

namespace masld_Tracking
{
  class Event_maslo_Display_maslev_modeChange
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_Display_maslev_modeChange ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_Display_maslev_refresh
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_Display_maslev_refresh ( );
      virtual void invoke ( ) const;


  };
}
#endif // _Tracking_Display_Events_hh
