//
// File: Inspector__Tracking__Goal.cc
//
#include "Inspector__Tracking__Goal.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalAchievement.hh"
#include "__Tracking__GoalEvents.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/EventHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_Goal
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )
            : maslp_sequenceNumber()
 { channel >> maslp_sequenceNumber; }
          void operator() ( ) { ::masld_Tracking::maslo_Goal::masls_initialize( maslp_sequenceNumber ); }


        private:
          int32_t maslp_sequenceNumber;


      };
      class masls_calculateStartHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_calculateStartInvoker
      {

        public:
          masls_calculateStartInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_calculateStart(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;


      };
      class masls_evaluateAchievementHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_evaluateAchievementInvoker
      {

        public:
          masls_evaluateAchievementInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_evaluateAchievement(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;


      };
      class masls_evaluateCompletionHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_evaluateCompletionInvoker
      {

        public:
          masls_evaluateCompletionInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_evaluateCompletion(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;


      };
      class masls_nextGoalHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_nextGoalInvoker
      {

        public:
          masls_nextGoalInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslo_Goal::masls_nextGoal(); }


      };
      class maslst_ExecutingHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_CompletedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_PausedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_EvaluatingHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_Goal_maslev_CompletedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_Goal_maslev_EvaluateHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_Goal_maslev_PauseHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_Goal_maslev_evaluationCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write sequenceNumber
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write goalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

            case 1:

              // Write goal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

            case 2:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 3:

              // Write goalachievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> >();
              break;

          }

        }
      }

      Callable masls_calculateStartHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_calculateStartInvoker( channel );
      }

      void masls_calculateStartHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write goalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

            case 1:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 2:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

          }

        }
      }

      Callable masls_evaluateAchievementHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_evaluateAchievementInvoker( channel );
      }

      void masls_evaluateAchievementHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                              const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write goalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

            case 1:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 2:

              // Write currentValue
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 3:

              // Write goalDisposition
              channel << frame.getLocalVars()[i].getValue< ::masld_Tracking::maslt_GoalDisposition>();
              break;

          }

        }
      }

      Callable masls_evaluateCompletionHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_evaluateCompletionInvoker( channel );
      }

      void masls_evaluateCompletionHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write goalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

            case 1:

              // Write elapsedSpan
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 2:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 3:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 4:

              // Write openAchievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >();
              break;

          }

        }
      }

      Callable masls_nextGoalHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_nextGoalInvoker( channel );
      }

      void masls_nextGoalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write goal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

            case 2:

              // Write gsc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> >();
              break;

          }

        }
      }

      void maslst_ExecutingHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write disposition
              channel << frame.getLocalVars()[i].getValue< ::masld_Tracking::maslt_GoalDisposition>();
              break;

            case 1:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 2:

              // Write achievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >();
              break;

          }

        }
      }

      void maslst_CompletedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write openAchievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >();
              break;

            case 1:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 2:

              // Write currentGoalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

            case 3:

              // Write nextGoalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

          }

        }
      }

      void maslst_PausedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_EvaluatingHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>( frame.getThis< ::masld_Tracking::maslo_Goal>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write goalachievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> >();
              break;

          }

        }
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_Goal_maslev_CompletedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_Goal_maslev_Completed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_Goal_maslev_CompletedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                 BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_Goal_maslev_Completed& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_Goal_maslev_Completed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_Goal_maslev_EvaluateHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_Goal_maslev_Evaluate( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_Goal_maslev_EvaluateHandler::writeParameters ( const ::SWA::Event&   event,
                                                                BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_Goal_maslev_Evaluate& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_Goal_maslev_Evaluate&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_Goal_maslev_PauseHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_Goal_maslev_Pause( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_Goal_maslev_PauseHandler::writeParameters ( const ::SWA::Event&   event,
                                                             BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_Goal_maslev_Pause& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_Goal_maslev_Pause&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_Goal_maslev_evaluationCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_Goal_maslev_evaluationComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_Goal_maslev_evaluationCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                          BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_Goal_maslev_evaluationComplete& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_Goal_maslev_evaluationComplete&>( event );
      }

      maslo_GoalHandler::maslo_GoalHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_Goal::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_Goal::serviceId_masls_calculateStart, ::boost::shared_ptr<ActionHandler>( new masls_calculateStartHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_Goal::serviceId_masls_evaluateAchievement, ::boost::shared_ptr<ActionHandler>( new masls_evaluateAchievementHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_Goal::serviceId_masls_evaluateCompletion, ::boost::shared_ptr<ActionHandler>( new masls_evaluateCompletionHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_Goal::serviceId_masls_nextGoal, ::boost::shared_ptr<ActionHandler>( new masls_nextGoalHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Goal::stateId_maslst_Executing, ::boost::shared_ptr<ActionHandler>( new maslst_ExecutingHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Goal::stateId_maslst_Completed, ::boost::shared_ptr<ActionHandler>( new maslst_CompletedHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Goal::stateId_maslst_Paused, ::boost::shared_ptr<ActionHandler>( new maslst_PausedHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Goal::stateId_maslst_Evaluating, ::boost::shared_ptr<ActionHandler>( new maslst_EvaluatingHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Completed, ::boost::shared_ptr<EventHandler>( new maslo_Goal_maslev_CompletedHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Evaluate, ::boost::shared_ptr<EventHandler>( new maslo_Goal_maslev_EvaluateHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Pause, ::boost::shared_ptr<EventHandler>( new maslo_Goal_maslev_PauseHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_evaluationComplete, ::boost::shared_ptr<EventHandler>( new maslo_Goal_maslev_evaluationCompleteHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_Goal> ( const ::masld_Tracking::maslo_Goal& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_disposition() );
    write( instance.get_masla_startingPoint() );
    write( instance.get_masla_ID() );
    write( ::SWA::EventTimers::getInstance().getTimer( instance.get_masla_evaluationTimer() ) );
    write( instance.get_masla_session_startTime() );
    write( instance.get_masla_spec_sequenceNumber() );
    write( static_cast<int>( instance.getCurrentState() ) );
    write( instance.navigate_R9_specified_by_GoalSpec() );
    write( instance.navigate_R11_is_currently_executing_within_WorkoutSession() );
    write<int>( instance.count_R12_has_recorded_Achievement() );
    write( instance.navigate_R13_was_executed_within_WorkoutSession() );
    write( instance.navigate_R14_has_open_Achievement() );
  }

  namespace masld_Tracking
  {
    namespace maslo_Goal
    {
      void maslo_GoalHandler::createInstance ( CommunicationChannel& channel ) const
      {
        ::masld_Tracking::maslt_GoalDisposition masla_disposition;
        double masla_startingPoint;
        int32_t masla_ID;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_spec_sequenceNumber;
        int currentState;
        channel >> masla_disposition >> masla_startingPoint >> masla_ID >> masla_session_startTime >> masla_spec_sequenceNumber >> currentState;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance = ::masld_Tracking::maslo_Goal::createInstance( masla_disposition, masla_startingPoint, masla_ID, ::SWA::EventTimers::getInstance().createTimer(), masla_session_startTime, masla_spec_sequenceNumber, ::masld_Tracking::maslo_Goal::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_GoalHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_ID() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_spec_sequenceNumber() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_Goal::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_Goal
    {
      void maslo_GoalHandler::writeRelatedInstances ( CommunicationChannel&                           channel,
                                                      ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance,
                                                      int                                             relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_GoalSpec>( ::masld_Tracking::objectId_maslo_GoalSpec ).writeInstances( channel, instance ? instance->navigate_R9_specified_by_GoalSpec()
                                                                                                                                                                                                                                       : ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>() );
            break;

          case 1:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R11_is_currently_executing_within_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

          case 2:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Achievement>( ::masld_Tracking::objectId_maslo_Achievement ).writeInstances( channel, instance ? instance->navigate_R12_has_recorded_Achievement()
                                                                                                                                                                                                                                             : ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >() );
            break;

          case 3:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R13_was_executed_within_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

          case 4:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Achievement>( ::masld_Tracking::objectId_maslo_Achievement ).writeInstances( channel, instance ? instance->navigate_R14_has_open_Achievement()
                                                                                                                                                                                                                                             : ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>() );
            break;

        }

      }

    }
  }
}
