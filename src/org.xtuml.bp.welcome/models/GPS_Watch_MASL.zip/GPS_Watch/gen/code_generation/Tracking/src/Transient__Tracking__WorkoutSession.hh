//
// File: Transient__Tracking__WorkoutSession.hh
//
#ifndef Transient_Tracking_Workout_Session_hh
#define Transient_Tracking_Workout_Session_hh

#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace masld_Tracking
{
  class maslo_Display;
  class maslo_WorkoutTimer;
  class maslo_TrackLog;
  class maslo_HeartRateSample;
  class maslo_GoalSpec;
  class maslo_Goal;
}
namespace transient
{
  namespace masld_Tracking
  {
    class maslo_Display;
  }
  namespace masld_Tracking
  {
    class maslo_WorkoutTimer;
  }
  namespace masld_Tracking
  {
    class maslo_TrackLog;
  }
  namespace masld_Tracking
  {
    class maslo_HeartRateSample;
  }
  namespace masld_Tracking
  {
    class maslo_GoalSpec;
  }
  namespace masld_Tracking
  {
    class maslo_Goal;
  }
  namespace masld_Tracking
  {
    class maslo_WorkoutSession
      : public ::masld_Tracking::maslo_WorkoutSession
    {

      // Constructors and Destructors
      public:
        maslo_WorkoutSession ( const ::SWA::Timestamp& masla_startTime,
                               double                  masla_accumulatedDistance );


      // Setters for each object attribute
      public:
        virtual void set_masla_accumulatedDistance ( double value ) { this->masla_accumulatedDistance = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::SWA::Timestamp get_masla_startTime ( ) const { return masla_startTime; }
        virtual double get_masla_accumulatedDistance ( ) const { return masla_accumulatedDistance; }


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> navigate_R7_current_status_indicated_on_Display ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> navigate_R8_is_timed_by_WorkoutTimer ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R4_captures_path_in_TrackLog ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > navigate_R10_includes_GoalSpec ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R11_is_currently_executing_Goal ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > navigate_R13_has_executed_Goal ( ) const;


      // Relationship Counters
      public:
        virtual ::std::size_t count_R7_current_status_indicated_on_Display ( ) const;
        virtual ::std::size_t count_R8_is_timed_by_WorkoutTimer ( ) const;
        virtual ::std::size_t count_R4_captures_path_in_TrackLog ( ) const;
        virtual ::std::size_t count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const;
        virtual ::std::size_t count_R10_includes_GoalSpec ( ) const;
        virtual ::std::size_t count_R11_is_currently_executing_Goal ( ) const;
        virtual ::std::size_t count_R13_has_executed_Goal ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs );
        virtual void unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs );
        virtual void link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs );
        virtual void unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs );
        virtual void link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs );
        virtual void unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs );
        virtual void link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void link_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::SWA::Timestamp masla_startTime;
        double masla_accumulatedDistance;


      // Relationship Getters
      public:
        ToOneRelationship<maslo_Display>& get_R7_current_status_indicated_on_Display ( );
        const ToOneRelationship<maslo_Display>& get_R7_current_status_indicated_on_Display ( ) const;
        ToOneRelationship<maslo_WorkoutTimer>& get_R8_is_timed_by_WorkoutTimer ( );
        const ToOneRelationship<maslo_WorkoutTimer>& get_R8_is_timed_by_WorkoutTimer ( ) const;
        ToOneRelationship<maslo_TrackLog>& get_R4_captures_path_in_TrackLog ( );
        const ToOneRelationship<maslo_TrackLog>& get_R4_captures_path_in_TrackLog ( ) const;
        ToManyRelationship<maslo_HeartRateSample>& get_R6_tracks_heart_rate_over_time_as_HeartRateSample ( );
        const ToManyRelationship<maslo_HeartRateSample>& get_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const;
        ToManyRelationship<maslo_GoalSpec>& get_R10_includes_GoalSpec ( );
        const ToManyRelationship<maslo_GoalSpec>& get_R10_includes_GoalSpec ( ) const;
        ToOneRelationship<maslo_Goal>& get_R11_is_currently_executing_Goal ( );
        const ToOneRelationship<maslo_Goal>& get_R11_is_currently_executing_Goal ( ) const;
        ToManyRelationship<maslo_Goal>& get_R13_has_executed_Goal ( );
        const ToManyRelationship<maslo_Goal>& get_R13_has_executed_Goal ( ) const;


      // Storage for each relationship
      private:
        ToOneRelationship<maslo_Display> R7_current_status_indicated_on_Display;
        ToOneRelationship<maslo_WorkoutTimer> R8_is_timed_by_WorkoutTimer;
        ToOneRelationship<maslo_TrackLog> R4_captures_path_in_TrackLog;
        ToManyRelationship<maslo_HeartRateSample> R6_tracks_heart_rate_over_time_as_HeartRateSample;
        ToManyRelationship<maslo_GoalSpec> R10_includes_GoalSpec;
        ToOneRelationship<maslo_Goal> R11_is_currently_executing_Goal;
        ToManyRelationship<maslo_Goal> R13_has_executed_Goal;


    };
  }
}
#endif // Transient_Tracking_Workout_Session_hh
