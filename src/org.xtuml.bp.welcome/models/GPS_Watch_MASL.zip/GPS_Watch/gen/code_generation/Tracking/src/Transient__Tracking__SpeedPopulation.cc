//
// File: Transient__Tracking__SpeedPopulation.cc
//
#include "Transient__Tracking__Speed.hh"
#include "Transient__Tracking__SpeedPopulation.hh"
#include "__Tracking__Speed.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_SpeedPopulation::maslo_SpeedPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> maslo_SpeedPopulation::createInstance ( int32_t masla_id,
                                                                                             int32_t masla_SpeedAveragingWindow,
                                                                                             int32_t masla_SecondsPerHour )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance(new maslo_Speed(  masla_id,
                  masla_SpeedAveragingWindow,
                  masla_SecondsPerHour ));
      addInstance( instance );
      return instance;
    }

    void maslo_SpeedPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_SpeedPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_SpeedPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_SpeedPopulation& maslo_SpeedPopulation::getPopulation ( )
    {
      static maslo_SpeedPopulation population;
      return population;
    }

    bool maslo_SpeedPopulation::registered = maslo_SpeedPopulation::registerSingleton( &maslo_SpeedPopulation::getPopulation );

  }
}
