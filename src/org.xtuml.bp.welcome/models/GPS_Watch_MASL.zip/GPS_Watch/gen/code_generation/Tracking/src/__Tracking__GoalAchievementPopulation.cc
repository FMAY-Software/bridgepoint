//
// File: __Tracking__GoalAchievementPopulation.cc
//
#include "__Tracking__GoalAchievementPopulation.hh"

namespace masld_Tracking
{
  maslo_GoalAchievementPopulation::maslo_GoalAchievementPopulation ( )
  {
  }

  maslo_GoalAchievementPopulation::~maslo_GoalAchievementPopulation ( )
  {
  }

}
