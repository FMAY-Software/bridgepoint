//
// File: __Tracking__GoalSpecPopulation.cc
//
#include "__Tracking__GoalSpecPopulation.hh"

namespace masld_Tracking
{
  maslo_GoalSpecPopulation::maslo_GoalSpecPopulation ( )
  {
  }

  maslo_GoalSpecPopulation::~maslo_GoalSpecPopulation ( )
  {
  }

}
