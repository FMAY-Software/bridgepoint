//
// File: Sqlite__Tracking__SpeedPopulation.cc
//
#include "Sqlite__Tracking__SpeedPopulation.hh"
#include "__Tracking__Speed.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_SpeedPopulation::maslo_SpeedPopulation ( )
    {
    }

    maslo_SpeedPopulation::~maslo_SpeedPopulation ( )
    {
    }

    void maslo_SpeedPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_SpeedPopulation& maslo_SpeedPopulation::getPopulation ( )
    {
      static maslo_SpeedPopulation population;
      return population;
    }

    bool maslo_SpeedPopulation::registered = maslo_SpeedPopulation::registerSingleton( &maslo_SpeedPopulation::getPopulation );

    ::boost::signals2::connection maslo_SpeedPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_SpeedPopulation::initialise, ::boost::bind( &maslo_SpeedPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> maslo_SpeedPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> > maslo_SpeedPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> maslo_SpeedPopulation::createInstance ( int32_t masla_id,
                                                                                             int32_t masla_SpeedAveragingWindow,
                                                                                             int32_t masla_SecondsPerHour )
    {
      return mapper->createInstance( masla_id, masla_SpeedAveragingWindow, masla_SecondsPerHour );
    }

    void maslo_SpeedPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
