//
// File: __Tracking__GoalSpec.hh
//
#ifndef _Tracking_Goal_Spec_hh
#define _Tracking_Goal_Spec_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Bag.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslt_GoalCriteria;
  class maslt_GoalSpan;
  class maslo_Goal;
  class maslo_WorkoutSession;
  class maslo_GoalSpec;
  class maslo_GoalSpec
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_GoalSpec> createInstance ( double                    masla_minimum,
                                                               double                    masla_maximum,
                                                               double                    masla_span,
                                                               const maslt_GoalCriteria& masla_criteriaType,
                                                               const maslt_GoalSpan&     masla_spanType,
                                                               int32_t                   masla_sequenceNumber,
                                                               const ::SWA::Timestamp&   masla_session_startTime,
                                                               int32_t                   masla_last_goal_ID );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_GoalSpec> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_minimum ( double value ) = 0;
      virtual void set_masla_maximum ( double value ) = 0;
      virtual void set_masla_span ( double value ) = 0;
      virtual void set_masla_criteriaType ( const maslt_GoalCriteria& value ) = 0;
      virtual void set_masla_spanType ( const maslt_GoalSpan& value ) = 0;
      virtual void set_masla_last_goal_ID ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual double get_masla_minimum ( ) const = 0;
      virtual double get_masla_maximum ( ) const = 0;
      virtual double get_masla_span ( ) const = 0;
      virtual maslt_GoalCriteria get_masla_criteriaType ( ) const = 0;
      virtual maslt_GoalSpan get_masla_spanType ( ) const = 0;
      virtual int32_t get_masla_sequenceNumber ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;
      virtual int32_t get_masla_last_goal_ID ( ) const = 0;


    // Find Predicates
    public:
      // MASL find: (sequenceNumber = p1)
      bool findPredicate_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 ) const { return !isDeleted() && get_masla_sequenceNumber() == p1; }


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> > findAll ( );
      static ::SWA::ObjectPtr<maslo_GoalSpec> findOne ( );
      static ::SWA::ObjectPtr<maslo_GoalSpec> findOnly ( );
      // MASL find: (sequenceNumber = p1)
      static ::SWA::ObjectPtr<maslo_GoalSpec> findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 );


    // Constructors and Destructors
    public:
      maslo_GoalSpec ( );
      virtual ~maslo_GoalSpec ( );


    // Prevent copy
    private:
      maslo_GoalSpec ( const maslo_GoalSpec& rhs );
      maslo_GoalSpec& operator= ( const maslo_GoalSpec& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {};


    // Relationship R9.specifies.Goal
    public:
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > navigate_R9_specifies_Goal ( ) const = 0;
      virtual ::std::size_t count_R9_specifies_Goal ( ) const;
      virtual void link_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void link_R9_specifies_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs );
      void checked_link_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs );
      void checked_link_R9_specifies_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs );
      virtual void unlink_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void unlink_R9_specifies_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs );
      virtual void unlink_R9_specifies_Goal ( );


    // Relationship R10.included_in.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R10_included_in_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R10_included_in_WorkoutSession ( ) const;
      virtual void link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R10_included_in_WorkoutSession ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_GoalSpec& obj );
}
#endif // _Tracking_Goal_Spec_hh
