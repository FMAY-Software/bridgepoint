//
// File: __Tracking__WorkoutSessionPopulation.cc
//
#include "__Tracking__WorkoutSessionPopulation.hh"

namespace masld_Tracking
{
  maslo_WorkoutSessionPopulation::maslo_WorkoutSessionPopulation ( )
  {
  }

  maslo_WorkoutSessionPopulation::~maslo_WorkoutSessionPopulation ( )
  {
  }

}
