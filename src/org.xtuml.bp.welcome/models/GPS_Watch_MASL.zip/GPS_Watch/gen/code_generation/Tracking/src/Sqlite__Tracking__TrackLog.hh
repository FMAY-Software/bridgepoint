//
// File: Sqlite__Tracking__TrackLog.hh
//
#ifndef Sqlite_Tracking_Track_Log_hh
#define Sqlite_Tracking_Track_Log_hh

#include "__Tracking__TrackLog.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_TrackPoint;
  class maslo_LapMarker;
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_TrackLog
      : public ::masld_Tracking::maslo_TrackLog
    {

      // Type definitions
      public:
        typedef ::boost::tuple< ::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple< ::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_TrackLog ( ::SWA::IdType architectureId );
        maslo_TrackLog ( ::SWA::IdType           architectureId,
                         const ::SWA::Timestamp& masla_session_startTime );


      // Setters for each object attribute
      public:
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> navigate_R1_has_first_TrackPoint ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> navigate_R3_has_last_TrackPoint ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > navigate_R5_has_laps_defined_by_LapMarker ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R4_represents_path_for_WorkoutSession ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R1_has_first_TrackPoint ( ) const;
        virtual ::std::size_t count_R3_has_last_TrackPoint ( ) const;
        virtual ::std::size_t count_R5_has_laps_defined_by_LapMarker ( ) const;
        virtual ::std::size_t count_R4_represents_path_for_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void unlink_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void unlink_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& rhs );
        virtual void unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& rhs );
        virtual void link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::SWA::Timestamp masla_session_startTime;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Track_Log_hh
