//
// File: Inspector__Tracking__WorkoutSession.cc
//
#include "Inspector__Tracking__WorkoutSession.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__Speed.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_WorkoutSession
    {
      class masls_addHeartRateSampleHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_addHeartRateSampleInvoker
      {

        public:
          masls_addHeartRateSampleInvoker ( CommunicationChannel& channel )
            : thisVar(),
              maslp_heartRate()

          {
            channel >> thisVar;
            channel >> maslp_heartRate;
          }
          void operator() ( ) { if ( thisVar ) thisVar->masls_addHeartRateSample( maslp_heartRate ); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> thisVar;
          int32_t maslp_heartRate;


      };
      class masls_clearHeartRateSamplesHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_clearHeartRateSamplesInvoker
      {

        public:
          masls_clearHeartRateSamplesInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_clearHeartRateSamples(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> thisVar;


      };
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslo_WorkoutSession::masls_initialize(); }


      };
      class masls_resetHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_resetInvoker
      {

        public:
          masls_resetInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_reset(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> thisVar;


      };
      class masls_getCurrentSpeedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_getCurrentSpeedInvoker
      {

        public:
          masls_getCurrentSpeedInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_getCurrentSpeed(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> thisVar;


      };
      class masls_getCurrentPaceHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_getCurrentPaceInvoker
      {

        public:
          masls_getCurrentPaceInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_getCurrentPace(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> thisVar;


      };
      class masls_getCurrentHeartRateHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_getCurrentHeartRateInvoker
      {

        public:
          masls_getCurrentHeartRateInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_getCurrentHeartRate(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> thisVar;


      };
      Callable masls_addHeartRateSampleHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_addHeartRateSampleInvoker( channel );
      }

      void masls_addHeartRateSampleHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>( frame.getThis< ::masld_Tracking::maslo_WorkoutSession>() );

        // Write heartRate
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 1:

              // Write sample
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >();
              break;

            case 2:

              // Write display
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> >();
              break;

          }

        }
      }

      Callable masls_clearHeartRateSamplesHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_clearHeartRateSamplesInvoker( channel );
      }

      void masls_clearHeartRateSamplesHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>( frame.getThis< ::masld_Tracking::maslo_WorkoutSession>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write samples
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > >();
              break;

            case 1:

              // Write sample
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >();
              break;

          }

        }
      }

      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 2:

              // Write trackLog
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> >();
              break;

            case 3:

              // Write display
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> >();
              break;

          }

        }
      }

      Callable masls_resetHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_resetInvoker( channel );
      }

      void masls_resetHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>( frame.getThis< ::masld_Tracking::maslo_WorkoutSession>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 1:

              // Write trackLog
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> >();
              break;

            case 2:

              // Write goalSpecs
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > >();
              break;

            case 3:

              // Write executingGoal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

            case 4:

              // Write openAchievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >();
              break;

            case 5:

              // Write goals
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > >();
              break;

            case 6:

              // Write achievements
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > >();
              break;

            case 7:

              // Write goalSpec
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
              break;

            case 8:

              // Write goal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

            case 9:

              // Write achievement
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >();
              break;

          }

        }
      }

      Callable masls_getCurrentSpeedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_getCurrentSpeedInvoker( channel );
      }

      void masls_getCurrentSpeedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>( frame.getThis< ::masld_Tracking::maslo_WorkoutSession>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write lastPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 1:

              // Write speed
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 2:

              // Write cursor
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 3:

              // Write spd
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> >();
              break;

            case 4:

              // Write index
              channel << frame.getLocalVars()[i].getValue<int32_t>();
              break;

            case 5:

              // Write totalDistance
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 6:

              // Write elapsedTime
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

            case 7:

              // Write previousPoint
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >();
              break;

            case 8:

              // Write distance
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

          }

        }
      }

      Callable masls_getCurrentPaceHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_getCurrentPaceInvoker( channel );
      }

      void masls_getCurrentPaceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>( frame.getThis< ::masld_Tracking::maslo_WorkoutSession>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write result
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

          }

        }
      }

      Callable masls_getCurrentHeartRateHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_getCurrentHeartRateInvoker( channel );
      }

      void masls_getCurrentHeartRateHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                              const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>( frame.getThis< ::masld_Tracking::maslo_WorkoutSession>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write hrc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> >();
              break;

            case 1:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

            case 2:

              // Write samples
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > >();
              break;

            case 3:

              // Write sample
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >();
              break;

            case 4:

              // Write numberOfSamples
              channel << frame.getLocalVars()[i].getValue<int32_t>();
              break;

            case 5:

              // Write sum
              channel << frame.getLocalVars()[i].getValue<int32_t>();
              break;

            case 6:

              // Write result
              channel << frame.getLocalVars()[i].getValue<int32_t>();
              break;

            case 7:

              // Write sample
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >();
              break;

          }

        }
      }

      maslo_WorkoutSessionHandler::maslo_WorkoutSessionHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_addHeartRateSample, ::boost::shared_ptr<ActionHandler>( new masls_addHeartRateSampleHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_clearHeartRateSamples, ::boost::shared_ptr<ActionHandler>( new masls_clearHeartRateSamplesHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_reset, ::boost::shared_ptr<ActionHandler>( new masls_resetHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_getCurrentSpeed, ::boost::shared_ptr<ActionHandler>( new masls_getCurrentSpeedHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_getCurrentPace, ::boost::shared_ptr<ActionHandler>( new masls_getCurrentPaceHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutSession::serviceId_masls_getCurrentHeartRate, ::boost::shared_ptr<ActionHandler>( new masls_getCurrentHeartRateHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_WorkoutSession> ( const ::masld_Tracking::maslo_WorkoutSession& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_startTime() );
    write( instance.get_masla_accumulatedDistance() );
    write( instance.navigate_R7_current_status_indicated_on_Display() );
    write( instance.navigate_R8_is_timed_by_WorkoutTimer() );
    write( instance.navigate_R4_captures_path_in_TrackLog() );
    write<int>( instance.count_R6_tracks_heart_rate_over_time_as_HeartRateSample() );
    write<int>( instance.count_R10_includes_GoalSpec() );
    write( instance.navigate_R11_is_currently_executing_Goal() );
    write<int>( instance.count_R13_has_executed_Goal() );
  }

  namespace masld_Tracking
  {
    namespace maslo_WorkoutSession
    {
      void maslo_WorkoutSessionHandler::createInstance ( CommunicationChannel& channel ) const
      {
        ::SWA::Timestamp masla_startTime;
        double masla_accumulatedDistance;
        channel >> masla_startTime >> masla_accumulatedDistance;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance = ::masld_Tracking::maslo_WorkoutSession::createInstance( masla_startTime, masla_accumulatedDistance );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_WorkoutSessionHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_WorkoutSession::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_WorkoutSession
    {
      void maslo_WorkoutSessionHandler::writeRelatedInstances ( CommunicationChannel&                                     channel,
                                                                ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance,
                                                                int                                                       relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Display>( ::masld_Tracking::objectId_maslo_Display ).writeInstances( channel, instance ? instance->navigate_R7_current_status_indicated_on_Display()
                                                                                                                                                                                                                                     : ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>() );
            break;

          case 1:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutTimer>( ::masld_Tracking::objectId_maslo_WorkoutTimer ).writeInstances( channel, instance ? instance->navigate_R8_is_timed_by_WorkoutTimer()
                                                                                                                                                                                                                                               : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>() );
            break;

          case 2:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackLog>( ::masld_Tracking::objectId_maslo_TrackLog ).writeInstances( channel, instance ? instance->navigate_R4_captures_path_in_TrackLog()
                                                                                                                                                                                                                                       : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>() );
            break;

          case 3:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_HeartRateSample>( ::masld_Tracking::objectId_maslo_HeartRateSample ).writeInstances( channel, instance ? instance->navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample()
                                                                                                                                                                                                                                                     : ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >() );
            break;

          case 4:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_GoalSpec>( ::masld_Tracking::objectId_maslo_GoalSpec ).writeInstances( channel, instance ? instance->navigate_R10_includes_GoalSpec()
                                                                                                                                                                                                                                       : ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >() );
            break;

          case 5:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Goal>( ::masld_Tracking::objectId_maslo_Goal ).writeInstances( channel, instance ? instance->navigate_R11_is_currently_executing_Goal()
                                                                                                                                                                                                                               : ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>() );
            break;

          case 6:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Goal>( ::masld_Tracking::objectId_maslo_Goal ).writeInstances( channel, instance ? instance->navigate_R13_has_executed_Goal()
                                                                                                                                                                                                                               : ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >() );
            break;

        }

      }

    }
  }
}
