//
// File: Transient__Tracking__Speed.hh
//
#ifndef Transient_Tracking_Speed_hh
#define Transient_Tracking_Speed_hh

#include "__Tracking__Speed.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_Speed
      : public ::masld_Tracking::maslo_Speed
    {

      // Constructors and Destructors
      public:
        maslo_Speed ( int32_t masla_id,
                      int32_t masla_SpeedAveragingWindow,
                      int32_t masla_SecondsPerHour );


      // Setters for each object attribute
      public:
        virtual void set_masla_SpeedAveragingWindow ( int32_t value ) { this->masla_SpeedAveragingWindow = value; }
        virtual void set_masla_SecondsPerHour ( int32_t value ) { this->masla_SecondsPerHour = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_SpeedAveragingWindow ( ) const { return masla_SpeedAveragingWindow; }
        virtual int32_t get_masla_SecondsPerHour ( ) const { return masla_SecondsPerHour; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_SpeedAveragingWindow;
        int32_t masla_SecondsPerHour;


    };
  }
}
#endif // Transient_Tracking_Speed_hh
