//
// File: Inspector__Tracking__GoalAchievement.hh
//
#ifndef Inspector_Tracking_Goal_Achievement_hh
#define Inspector_Tracking_Goal_Achievement_hh

#include "__Tracking__GoalAchievement.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_GoalAchievement
    {
      class maslo_GoalAchievementHandler
        : public ObjectHandler< ::masld_Tracking::maslo_GoalAchievement>
      {

        // Constructors
        public:
          maslo_GoalAchievementHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                      channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance,
                                       int                                                        relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Goal_Achievement_hh
