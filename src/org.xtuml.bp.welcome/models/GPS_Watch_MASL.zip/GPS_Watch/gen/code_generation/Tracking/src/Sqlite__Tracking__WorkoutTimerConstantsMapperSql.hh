//
// File: Sqlite__Tracking__WorkoutTimerConstantsMapperSql.hh
//
#ifndef Sqlite_Tracking_Workout_Timer_Constants_Mapper_Sql_hh
#define Sqlite_Tracking_Workout_Timer_Constants_Mapper_Sql_hh

#include "Sqlite__Tracking__WorkoutTimerConstants.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sqlite/PreparedStatement.hh"
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutTimerConstantsSqlGenerator
      : public ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_WorkoutTimerConstants,maslo_WorkoutTimerConstants>
    {

      // execute methods
      public:
        void executeGetMaxColumnValue ( const ::std::string& attribute,
                                        int32_t&             value ) const;
        void executeGetMaxColumnValue ( const ::std::string& attribute,
                                        int64_t&             value ) const;
        ::SWA::IdType executeGetRowCount ( ) const;
        ::SWA::IdType executeGetMaxIdentifier ( ) const;
        void executeUpdate ( const PsObjectPtr& object ) const;
        void executeInsert ( const PsObjectPtr& object ) const;
        void executeRemove ( const PsObjectPtr& object ) const;
        void executeRemoveId ( const ::SWA::IdType object ) const;
        void executeSelect ( CacheType&             cache,
                             const ::SQL::Criteria& criteria,
                             PsBaseObjectPtrSwaSet& result ) const;
        void executeSelect ( CacheType&             cache,
                             const ::SQL::Criteria& criteria ) const;


      // getter methods
      public:
        const ::std::string getDomainName ( ) const;
        const ::std::string& getTableName ( ) const;
        const ::std::string& getObjectName ( ) const;
        const ::std::string getColumnName ( const ::std::string& attribute ) const;


      // Constructors and Destructors
      public:
        maslo_WorkoutTimerConstantsSqlGenerator ( );
        ~maslo_WorkoutTimerConstantsSqlGenerator ( );
        void initialise ( );


      // Data Members
      private:
        ::std::string tableName;
        ::std::string objectName;
        PreparedStatement insertStatement;
        PreparedStatement updateStatement;
        PreparedStatement deleteStatement;
        ::std::map< ::std::string,::std::string> columnNameMapper;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Timer_Constants_Mapper_Sql_hh
