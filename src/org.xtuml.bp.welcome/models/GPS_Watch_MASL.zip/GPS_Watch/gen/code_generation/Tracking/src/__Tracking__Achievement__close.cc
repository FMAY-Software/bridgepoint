//
// File: __Tracking__Achievement__close.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_Achievement::masls_close ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Achievement, serviceId_masls_close);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // goal : instance of Goal;
        ::SWA::ObjectPtr<maslo_Goal> maslv_goal;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goal(0, maslv_goal);

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(1, maslv_workoutTimer);

        // goal := this -> R14.is_open_for.Goal;
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_goal = ::SWA::navigate_one<maslo_Goal>( ::SWA::ObjectPtr<maslo_Achievement>( this ), ::boost::bind( &maslo_Achievement::navigate_R14_is_open_for_Goal, _1 ) );
        }

        // workoutTimer := goal -> R11.is_currently_executing_within.WorkoutSession -> R8.is_timed_by.WorkoutTimer;
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          maslv_workoutTimer = ::SWA::navigate_one<maslo_WorkoutTimer>( ::SWA::navigate_one<maslo_WorkoutSession>( maslv_goal, ::boost::bind( &maslo_Goal::navigate_R11_is_currently_executing_within_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer, _1 ) );
        }

        // this.endTime := workoutTimer.time;
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          ::SWA::ObjectPtr<maslo_Achievement>( this )->set_masla_endTime( maslv_workoutTimer->get_masla_time() );
        }

        // unlink this R14.is_open_for.Goal  goal;
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          ::SWA::ObjectPtr<maslo_Achievement>( this )->unlink_R14_is_open_for_Goal( maslv_goal );
        }

        // link this R12.specifies_achievement_of.Goal  goal;
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          ::SWA::ObjectPtr<maslo_Achievement>( this )->checked_link_R12_specifies_achievement_of_Goal( maslv_goal );
        }
      }
    }
  }

}
