//
// File: __Tracking__HeartRateConstants.hh
//
#ifndef _Tracking_Heart_Rate_Constants_hh
#define _Tracking_Heart_Rate_Constants_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_HeartRateConstants;
  class maslo_HeartRateConstants
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_HeartRateConstants> createInstance ( int32_t masla_id,
                                                                         int32_t masla_HeartRateAveragingWindow,
                                                                         int32_t masla_HeartRateSamplingPeriod );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_HeartRateConstants> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_HeartRateAveragingWindow ( int32_t value ) = 0;
      virtual void set_masla_HeartRateSamplingPeriod ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual int32_t get_masla_HeartRateAveragingWindow ( ) const = 0;
      virtual int32_t get_masla_HeartRateSamplingPeriod ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateConstants> > findAll ( );
      static ::SWA::ObjectPtr<maslo_HeartRateConstants> findOne ( );
      static ::SWA::ObjectPtr<maslo_HeartRateConstants> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_HeartRateConstants ( );
      virtual ~maslo_HeartRateConstants ( );


    // Prevent copy
    private:
      maslo_HeartRateConstants ( const maslo_HeartRateConstants& rhs );
      maslo_HeartRateConstants& operator= ( const maslo_HeartRateConstants& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&                 stream,
                               const maslo_HeartRateConstants& obj );
}
#endif // _Tracking_Heart_Rate_Constants_hh
