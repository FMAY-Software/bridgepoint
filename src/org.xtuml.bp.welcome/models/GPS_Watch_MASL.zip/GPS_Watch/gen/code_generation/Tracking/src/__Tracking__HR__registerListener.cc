//
// File: __Tracking__HR__registerListener.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Tracking
{
  void maslb_HR::masls_registerListener ( )
  {
    getInstance().override_masls_registerListener.getFunction()();
  }

  bool maslb_HR::register_masls_registerListener ( ::SWA::FunctionOverrider<void()>::FunctionPtr override )
  {
    getInstance().override_masls_registerListener.override( override );
    return true;
  }

  bool maslb_HR::overriden_masls_registerListener ( )
  {
    return getInstance().override_masls_registerListener.isOverridden();
  }

  void maslb_HR::domain_masls_registerListener ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_HR, serviceId_masls_registerListener);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Sending message 'registerListener' on terminator HR")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'registerListener' on terminator HR" ) );
        }
      }
    }
  }

}
