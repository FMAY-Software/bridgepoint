//
// File: Inspector__Tracking__UI.cc
//
#include "Inspector__Tracking__UI.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      class masls_setDataHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setDataInvoker
      {

        public:
          masls_setDataInvoker ( CommunicationChannel& channel )
            : maslp_value(),
              maslp_unit()

          {
            channel >> maslp_value;
            channel >> maslp_unit;
          }
          void operator() ( ) { ::masld_Tracking::maslb_UI::masls_setData( maslp_value, maslp_unit ); }


        private:
          double maslp_value;
          ::masld_Tracking::maslt_Unit maslp_unit;


      };
      class masls_setIndicatorHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setIndicatorInvoker
      {

        public:
          masls_setIndicatorInvoker ( CommunicationChannel& channel )
            : maslp_indicator()
 { channel >> maslp_indicator; }
          void operator() ( ) { ::masld_Tracking::maslb_UI::masls_setIndicator( maslp_indicator ); }


        private:
          ::masld_Tracking::maslt_Indicator maslp_indicator;


      };
      class masls_setTimeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setTimeInvoker
      {

        public:
          masls_setTimeInvoker ( CommunicationChannel& channel )
            : maslp_time()
 { channel >> maslp_time; }
          void operator() ( ) { ::masld_Tracking::maslb_UI::masls_setTime( maslp_time ); }


        private:
          int32_t maslp_time;


      };
      Callable masls_setDataHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setDataInvoker( channel );
      }

      void masls_setDataHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write value
        channel << frame.getParameters()[0].getValue<double>();

        // Write unit
        channel << frame.getParameters()[1].getValue< ::masld_Tracking::maslt_Unit>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_setIndicatorHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setIndicatorInvoker( channel );
      }

      void masls_setIndicatorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write indicator
        channel << frame.getParameters()[0].getValue< ::masld_Tracking::maslt_Indicator>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_setTimeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setTimeInvoker( channel );
      }

      void masls_setTimeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write time
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      maslb_UIHandler::maslb_UIHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslb_UI::serviceId_masls_setData, ::boost::shared_ptr<ActionHandler>( new masls_setDataHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslb_UI::serviceId_masls_setIndicator, ::boost::shared_ptr<ActionHandler>( new masls_setIndicatorHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslb_UI::serviceId_masls_setTime, ::boost::shared_ptr<ActionHandler>( new masls_setTimeHandler() ) );
      }

    }
  }
}
