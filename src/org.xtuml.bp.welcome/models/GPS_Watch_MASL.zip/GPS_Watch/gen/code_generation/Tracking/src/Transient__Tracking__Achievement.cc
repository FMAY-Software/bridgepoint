//
// File: Transient__Tracking__Achievement.cc
//
#include "Transient__Tracking__Achievement.hh"
#include "Transient__Tracking__Goal.hh"
#include "__Tracking__Goal.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_Achievement::maslo_Achievement ( int32_t                 masla_startTime,
                                           int32_t                 masla_endTime,
                                           const ::SWA::Timestamp& masla_session_startTime,
                                           int32_t                 masla_goal_ID,
                                           int32_t                 masla_spec_sequenceNumber )
      : architectureId(getNextArchId()),
        masla_startTime(masla_startTime),
        masla_endTime(masla_endTime),
        masla_session_startTime(masla_session_startTime),
        masla_goal_ID(masla_goal_ID),
        masla_spec_sequenceNumber(masla_spec_sequenceNumber),
        R12_specifies_achievement_of_Goal(),
        R14_is_open_for_Goal()
    {
    }

    ToOneRelationship<maslo_Goal>& maslo_Achievement::get_R12_specifies_achievement_of_Goal ( )
    {
      return R12_specifies_achievement_of_Goal;
    }

    const ToOneRelationship<maslo_Goal>& maslo_Achievement::get_R12_specifies_achievement_of_Goal ( ) const
    {
      return R12_specifies_achievement_of_Goal;
    }

    ToOneRelationship<maslo_Goal>& maslo_Achievement::get_R14_is_open_for_Goal ( )
    {
      return R14_is_open_for_Goal;
    }

    const ToOneRelationship<maslo_Goal>& maslo_Achievement::get_R14_is_open_for_Goal ( ) const
    {
      return R14_is_open_for_Goal;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_Achievement::navigate_R12_specifies_achievement_of_Goal ( ) const
    {
      return get_R12_specifies_achievement_of_Goal().navigate();
    }

    ::std::size_t maslo_Achievement::count_R12_specifies_achievement_of_Goal ( ) const
    {
      return get_R12_specifies_achievement_of_Goal().count();
    }

    void maslo_Achievement::link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R12_specifies_achievement_of_Goal().link( rhs2 );
      try
      {
        rhs2->get_R12_has_recorded_Achievement().link( ::SWA::ObjectPtr<maslo_Achievement>( this ) );
      }
      catch ( ... )
      {
        this->get_R12_specifies_achievement_of_Goal().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Achievement::unlink_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R12_specifies_achievement_of_Goal().unlink( rhs2 );
      try
      {
        rhs2->get_R12_has_recorded_Achievement().unlink( ::SWA::ObjectPtr<maslo_Achievement>( this ) );
      }
      catch ( ... )
      {
        this->get_R12_specifies_achievement_of_Goal().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_Achievement::navigate_R14_is_open_for_Goal ( ) const
    {
      return get_R14_is_open_for_Goal().navigate();
    }

    ::std::size_t maslo_Achievement::count_R14_is_open_for_Goal ( ) const
    {
      return get_R14_is_open_for_Goal().count();
    }

    void maslo_Achievement::link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R14_is_open_for_Goal().link( rhs2 );
      try
      {
        rhs2->get_R14_has_open_Achievement().link( ::SWA::ObjectPtr<maslo_Achievement>( this ) );
      }
      catch ( ... )
      {
        this->get_R14_is_open_for_Goal().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Achievement::unlink_R14_is_open_for_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R14_is_open_for_Goal().unlink( rhs2 );
      try
      {
        rhs2->get_R14_has_open_Achievement().unlink( ::SWA::ObjectPtr<maslo_Achievement>( this ) );
      }
      catch ( ... )
      {
        this->get_R14_is_open_for_Goal().link( rhs2 );
        throw;
      }
    }

  }
}
