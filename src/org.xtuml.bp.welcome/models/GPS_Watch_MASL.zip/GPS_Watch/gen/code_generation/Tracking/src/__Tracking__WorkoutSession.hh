//
// File: __Tracking__WorkoutSession.hh
//
#ifndef _Tracking_Workout_Session_hh
#define _Tracking_Workout_Session_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Bag.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_Display;
  class maslo_WorkoutTimer;
  class maslo_TrackLog;
  class maslo_HeartRateSample;
  class maslo_GoalSpec;
  class maslo_Goal;
  class maslo_WorkoutSession;
  class maslo_WorkoutSession
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_WorkoutSession> createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                     double                  masla_accumulatedDistance );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_WorkoutSession> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_accumulatedDistance ( double value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_startTime ( ) const = 0;
      virtual double get_masla_accumulatedDistance ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Instance Services
    public:
      void masls_addHeartRateSample ( int32_t maslp_heartRate );
      void masls_clearHeartRateSamples ( );
      void masls_reset ( );
      double masls_getCurrentSpeed ( );
      double masls_getCurrentPace ( );
      int32_t masls_getCurrentHeartRate ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutSession> > findAll ( );
      static ::SWA::ObjectPtr<maslo_WorkoutSession> findOne ( );
      static ::SWA::ObjectPtr<maslo_WorkoutSession> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_WorkoutSession ( );
      virtual ~maslo_WorkoutSession ( );


    // Prevent copy
    private:
      maslo_WorkoutSession ( const maslo_WorkoutSession& rhs );
      maslo_WorkoutSession& operator= ( const maslo_WorkoutSession& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_addHeartRateSample,
                         serviceId_masls_clearHeartRateSamples,
                         serviceId_masls_initialize,
                         serviceId_masls_reset,
                         serviceId_masls_getCurrentSpeed,
                         serviceId_masls_getCurrentPace,
                         serviceId_masls_getCurrentHeartRate };


    // Relationship R7.current_status_indicated_on.Display
    public:
      virtual ::SWA::ObjectPtr<maslo_Display> navigate_R7_current_status_indicated_on_Display ( ) const = 0;
      virtual ::std::size_t count_R7_current_status_indicated_on_Display ( ) const;
      virtual void link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_Display>& rhs ) = 0;
      void checked_link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_Display>& rhs );
      virtual void unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_Display>& rhs ) = 0;
      virtual void unlink_R7_current_status_indicated_on_Display ( );


    // Relationship R8.is_timed_by.WorkoutTimer
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutTimer> navigate_R8_is_timed_by_WorkoutTimer ( ) const = 0;
      virtual ::std::size_t count_R8_is_timed_by_WorkoutTimer ( ) const;
      virtual void link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>& rhs ) = 0;
      void checked_link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>& rhs );
      virtual void unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>& rhs ) = 0;
      virtual void unlink_R8_is_timed_by_WorkoutTimer ( );


    // Relationship R4.captures_path_in.TrackLog
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackLog> navigate_R4_captures_path_in_TrackLog ( ) const = 0;
      virtual ::std::size_t count_R4_captures_path_in_TrackLog ( ) const;
      virtual void link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs ) = 0;
      void checked_link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs );
      virtual void unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs ) = 0;
      virtual void unlink_R4_captures_path_in_TrackLog ( );


    // Relationship R6.tracks_heart_rate_over_time_as.HeartRateSample
    public:
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const = 0;
      virtual ::std::size_t count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const;
      virtual void link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs ) = 0;
      virtual void link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >& rhs );
      void checked_link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs );
      void checked_link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >& rhs );
      virtual void unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs ) = 0;
      virtual void unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >& rhs );
      virtual void unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( );


    // Relationship R10.includes.GoalSpec
    public:
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> > navigate_R10_includes_GoalSpec ( ) const = 0;
      virtual ::std::size_t count_R10_includes_GoalSpec ( ) const;
      virtual void link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs ) = 0;
      virtual void link_R10_includes_GoalSpec ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >& rhs );
      void checked_link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs );
      void checked_link_R10_includes_GoalSpec ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >& rhs );
      virtual void unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs ) = 0;
      virtual void unlink_R10_includes_GoalSpec ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >& rhs );
      virtual void unlink_R10_includes_GoalSpec ( );


    // Relationship R11.is_currently_executing.Goal
    public:
      virtual ::SWA::ObjectPtr<maslo_Goal> navigate_R11_is_currently_executing_Goal ( ) const = 0;
      virtual ::std::size_t count_R11_is_currently_executing_Goal ( ) const;
      virtual void link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      void checked_link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs );
      virtual void unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void unlink_R11_is_currently_executing_Goal ( );


    // Relationship R13.has_executed.Goal
    public:
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > navigate_R13_has_executed_Goal ( ) const = 0;
      virtual ::std::size_t count_R13_has_executed_Goal ( ) const;
      virtual void link_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void link_R13_has_executed_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs );
      void checked_link_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs );
      void checked_link_R13_has_executed_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs );
      virtual void unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs ) = 0;
      virtual void unlink_R13_has_executed_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs );
      virtual void unlink_R13_has_executed_Goal ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&             stream,
                               const maslo_WorkoutSession& obj );
}
#endif // _Tracking_Workout_Session_hh
