//
// File: Sqlite__Tracking__TrackPoint.hh
//
#ifndef Sqlite_Tracking_Track_Point_hh
#define Sqlite_Tracking_Track_Point_hh

#include "__Tracking__TrackPoint.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_TrackLog;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_TrackPoint
      : public ::masld_Tracking::maslo_TrackPoint
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t,::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple<int32_t,::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_TrackPoint ( ::SWA::IdType architectureId );
        maslo_TrackPoint ( ::SWA::IdType           architectureId,
                           int32_t                 masla_time,
                           double                  masla_longitude,
                           double                  masla_latitude,
                           const ::SWA::Timestamp& masla_session_startTime );


      // Setters for each object attribute
      public:
        void set_masla_time ( int32_t value )
        {
          this->masla_time = value;
          markAsModified();
        }
        virtual void set_masla_longitude ( double value )
        {
          this->masla_longitude = value;
          markAsModified();
        }
        virtual void set_masla_latitude ( double value )
        {
          this->masla_latitude = value;
          markAsModified();
        }
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_time ( ) const { return masla_time; }
        virtual double get_masla_longitude ( ) const { return masla_longitude; }
        virtual double get_masla_latitude ( ) const { return masla_latitude; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R1_is_start_of_TrackLog ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> navigate_R2_follows_TrackPoint ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> navigate_R2_preceeds_TrackPoint ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R3_is_last_for_TrackLog ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R1_is_start_of_TrackLog ( ) const;
        virtual ::std::size_t count_R2_follows_TrackPoint ( ) const;
        virtual ::std::size_t count_R2_preceeds_TrackPoint ( ) const;
        virtual ::std::size_t count_R3_is_last_for_TrackLog ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void unlink_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void unlink_R2_follows_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void unlink_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs );
        virtual void link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void unlink_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_time;
        double masla_longitude;
        double masla_latitude;
        ::SWA::Timestamp masla_session_startTime;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Track_Point_hh
