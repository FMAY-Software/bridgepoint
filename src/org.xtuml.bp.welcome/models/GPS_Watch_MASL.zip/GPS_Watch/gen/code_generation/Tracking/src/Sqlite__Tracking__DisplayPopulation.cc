//
// File: Sqlite__Tracking__DisplayPopulation.cc
//
#include "Sqlite__Tracking__Display.hh"
#include "Sqlite__Tracking__DisplayPopulation.hh"
#include "Sqlite__Tracking__R7Mapper.hh"
#include "Sqlite__Tracking__R7MapperSql.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionPopulation.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/signals2.hpp"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_DisplayPopulation::maslo_DisplayPopulation ( )
      : R7Mapper(RelationshipR7Mapper::singleton())
    {
    }

    maslo_DisplayPopulation::~maslo_DisplayPopulation ( )
    {
    }

    void maslo_DisplayPopulation::initialise ( )
    {
      mapper->initialise();
      if ( R7Mapper.isInitialised() == false )
      {
        R7Mapper.initialise( ::boost::shared_ptr<RelationshipR7Mapper::RelSqlGeneratorType>( new RelationshipR7SqlGenerator() ) );
      }

    }

    maslo_DisplayPopulation& maslo_DisplayPopulation::getPopulation ( )
    {
      static maslo_DisplayPopulation population;
      return population;
    }

    bool maslo_DisplayPopulation::registered = maslo_DisplayPopulation::registerSingleton( &maslo_DisplayPopulation::getPopulation );

    ::boost::signals2::connection maslo_DisplayPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_DisplayPopulation::initialise, ::boost::bind( &maslo_DisplayPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> maslo_DisplayPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> > maslo_DisplayPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> maslo_DisplayPopulation::createInstance ( const ::SWA::Timestamp&               masla_session_startTime,
                                                                                                 ::masld_Tracking::maslo_Display::Type currentState )
    {
      return mapper->createInstance( masla_session_startTime, currentState );
    }

    void maslo_DisplayPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance )
    {
      {
        R7Mapper.objectDeletedRhs( instance.downcast<maslo_Display>() );
      }
      mapper->deleteInstance( instance );
    }

    void maslo_DisplayPopulation::link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Display>&        lhs,
                                                                                       const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
    {
      R7Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_DisplayPopulation::unlink_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Display>&        lhs,
                                                                                         const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
    {
      R7Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_DisplayPopulation::navigate_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Display>& lhs )
    {
      const RelationshipR7Mapper::NavigatedLhsType& navigated(R7Mapper.navigateFromRhsToLhs( lhs ));
      return maslo_WorkoutSessionPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_DisplayPopulation::count_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Display>& lhs )
    {
      return R7Mapper.countFromRhsToLhs( lhs );
    }

  }
}
