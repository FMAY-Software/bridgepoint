//
// File: Sqlite__Tracking__R12MapperSql.cc
//
#include "Sqlite__Tracking__R12MapperSql.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <sstream>
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE Tracking_R12_LINK_TABLE (R12_lhs INTEGER, R12_rhs INTEGER, PRIMARY KEY (R12_lhs,R12_rhs));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "Tracking_R12_LINK_TABLE", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    RelationshipR12SqlGenerator::RelationshipR12SqlGenerator ( )
      : tableName("Tracking_R12_LINK_TABLE"),
        relationshipName("Tracking_R12"),
        pepreparedLink("INSERT INTO Tracking_R12_LINK_TABLE VALUES(:1,:2);"),
        pepreparedUnlink("DELETE FROM Tracking_R12_LINK_TABLE WHERE R12_lhs = :1 AND R12_rhs= :2;")
    {
    }

    void RelationshipR12SqlGenerator::initialise ( )
    {
      pepreparedLink.prepare();
      pepreparedUnlink.prepare();
    }

    const ::std::string& RelationshipR12SqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string RelationshipR12SqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string RelationshipR12SqlGenerator::getLhsColumnName ( ) const
    {
      return "R12_lhs";
    }

    const ::std::string RelationshipR12SqlGenerator::getRhsColumnName ( ) const
    {
      return "R12_rhs";
    }

    const ::std::string& RelationshipR12SqlGenerator::getRelationshipName ( ) const
    {
      return relationshipName;
    }

    ::SWA::IdType RelationshipR12SqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM Tracking_R12_LINK_TABLE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "RelationshipR12SqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "RelationshipR12SqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    void RelationshipR12SqlGenerator::commitLink ( const LinkedPairType& linkObjects ) const
    {
      pepreparedLink.execute( ::boost::make_tuple( linkObjects.first.getChecked()->getArchitectureId(), linkObjects.second.getChecked()->getArchitectureId() ) );
    }

    void RelationshipR12SqlGenerator::commitUnlink ( const LinkedPairType& unlinkObjects ) const
    {
      pepreparedUnlink.execute( ::boost::make_tuple( unlinkObjects.first.getChecked()->getArchitectureId(), unlinkObjects.second.getChecked()->getArchitectureId() ) );
    }

    void RelationshipR12SqlGenerator::loadAll ( LhsToRhsContainerType& lhsToRhsLinkSet,
                                                RhsToLhsContainerType& rhsToLhsLinkSet ) const
    {
      const ::std::string query("SELECT R12_lhs,R12_rhs FROM Tracking_R12_LINK_TABLE;");

      Database& database = Database::singleton();

      sqlite3_stmt* ppStmt = 0;
      Database::ScopedFinalise finaliser("R12::loadAll", ppStmt);
      int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

      database.checkCompile( "R12::loadAll", compile_result, query );
      database.checkColumnCount( "R12::loadAll", sqlite3_column_count( ppStmt ), 2, query );

      while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
      {

        int32_t lhsColumnValue = sqlite3_column_int( ppStmt, 0 );

        int32_t rhsColumnValue = sqlite3_column_int( ppStmt, 1 );
        lhsToRhsLinkSet[lhsColumnValue].link( rhsColumnValue );
        rhsToLhsLinkSet[rhsColumnValue].link( lhsColumnValue );
      }
      SqlQueryMonitor queryMonitor(query);
    }

    void RelationshipR12SqlGenerator::loadLhs ( const ::SWA::IdType&   rhsIdentity,
                                                LhsToRhsContainerType& lhsToRhsLinkSet,
                                                RhsToLhsContainerType& rhsToLhsLinkSet ) const
    {
      ::std::ostringstream query;
      query << "SELECT R12_lhs FROM Tracking_R12_LINK_TABLE WHERE R12_rhs = " << rhsIdentity << ";";

      Database& database = Database::singleton();

      sqlite3_stmt* ppStmt = 0;
      Database::ScopedFinalise finaliser("R12::loadLhs", ppStmt);
      int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.str().c_str(), -1, &ppStmt, 0 );

      database.checkCompile( "R12::loadLhs", compile_result, query.str() );
      database.checkColumnCount( "R12::loadLhs", sqlite3_column_count( ppStmt ), 1, query.str() );

      while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
      {

        int32_t lhsColumnValue = sqlite3_column_int( ppStmt, 0 );
        rhsToLhsLinkSet[rhsIdentity].link( lhsColumnValue );
        lhsToRhsLinkSet[lhsColumnValue].link( rhsIdentity );
      }
      SqlQueryMonitor queryMonitor(query.str());
    }

    void RelationshipR12SqlGenerator::loadRhs ( const ::SWA::IdType&   lhsIdentity,
                                                LhsToRhsContainerType& lhsToRhsLinkSet,
                                                RhsToLhsContainerType& rhsToLhsLinkSet ) const
    {
      ::std::ostringstream query;
      query << "SELECT R12_rhs FROM Tracking_R12_LINK_TABLE WHERE R12_lhs = " << lhsIdentity << ";";

      Database& database = Database::singleton();

      sqlite3_stmt* ppStmt = 0;
      Database::ScopedFinalise finaliser("R12::loadRhs", ppStmt);
      int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.str().c_str(), -1, &ppStmt, 0 );

      database.checkCompile( "R12::loadRhs", compile_result, query.str() );
      database.checkColumnCount( "R12::loadRhs", sqlite3_column_count( ppStmt ), 1, query.str() );

      while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
      {

        int32_t rhsColumnValue = sqlite3_column_int( ppStmt, 0 );
        lhsToRhsLinkSet[lhsIdentity].link( rhsColumnValue );
        rhsToLhsLinkSet[rhsColumnValue].link( lhsIdentity );
      }
      SqlQueryMonitor queryMonitor(query.str());
    }

  }
}
