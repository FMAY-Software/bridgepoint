//
// File: Sqlite__Tracking__LapMarkerMapperSql.cc
//
#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__LapMarkerMapperSql.hh"
#include "__Tracking__LapMarker.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Tracking_LAPMARKER(   architecture_id  INTEGER ,   masla_lapTime INTEGER,   masla_session_startTime INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Tracking_LAPMARKER", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_LapMarkerSqlGenerator::maslo_LapMarkerSqlGenerator ( )
      : tableName("S_Tracking_LAPMARKER"),
        objectName("LapMarker"),
        insertStatement("INSERT INTO S_Tracking_LAPMARKER VALUES(:1,:2,:3);"),
        updateStatement("UPDATE S_Tracking_LAPMARKER SET masla_lapTime = :2  , masla_session_startTime = :3  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Tracking_LAPMARKER WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_LapMarkerSqlGenerator::~maslo_LapMarkerSqlGenerator ( )
    {
    }

    void maslo_LapMarkerSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["lapTime"] = ::std::string( "masla_lapTime" );
      columnNameMapper["session_startTime"] = ::std::string( "masla_session_startTime" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_LapMarkerSqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string& maslo_LapMarkerSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_LapMarkerSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_LapMarkerSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_LapMarkerSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_LapMarkerSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                 int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_LAPMARKER;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_LapMarkerSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_LapMarkerSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_LapMarkerSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                 int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_LAPMARKER;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_LapMarkerSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_LapMarkerSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_LapMarkerSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Tracking_LAPMARKER;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_LapMarkerSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_LapMarkerSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_LapMarkerSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_LapMarkerSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_lapTime(), object.getChecked()->get_masla_session_startTime() ) );
    }

    void maslo_LapMarkerSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_lapTime(), object.getChecked()->get_masla_session_startTime() ) );
    }

    void maslo_LapMarkerSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_LapMarkerSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_LapMarkerSqlGenerator::executeSelect ( CacheType&             cache,
                                                      const ::SQL::Criteria& criteria,
                                                      PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("LapMarker::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "LapMarker::executeSelect", compile_result, query );
        database.checkColumnCount( "LapMarker::executeSelect", sqlite3_column_count( ppStmt ), 3, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_LapMarker(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t lapTime = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_lapTime( lapTime );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 2 ) );
            currentObject->set_masla_session_startTime( session_startTime );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_LapMarkerSqlGenerator::executeSelect ( CacheType&             cache,
                                                      const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("LapMarker::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "LapMarker::executeSelect", compile_result, query );
        database.checkColumnCount( "LapMarker::executeSelect", sqlite3_column_count( ppStmt ), 3, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_LapMarker(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t lapTime = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_lapTime( lapTime );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 2 ) );
            currentObject->set_masla_session_startTime( session_startTime );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
