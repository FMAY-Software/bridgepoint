//
// File: Sqlite__Tracking__R7Mapper.hh
//
#ifndef Sqlite_Tracking_R_7_Mapper_hh
#define Sqlite_Tracking_R_7_Mapper_hh

#include "Sqlite__Tracking__Display.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToOneRelationship<7,maslo_WorkoutSession,maslo_Display,false,false>::mapper_type RelationshipR7Mapper;
  }
}
#endif // Sqlite_Tracking_R_7_Mapper_hh
