//
// File: Transient__Tracking__Display.cc
//
#include "Transient__Tracking__Display.hh"
#include "Transient__Tracking__WorkoutSession.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_Display::maslo_Display ( const ::SWA::Timestamp&               masla_session_startTime,
                                   ::masld_Tracking::maslo_Display::Type currentState )
      : architectureId(getNextArchId()),
        masla_session_startTime(masla_session_startTime),
        currentState(currentState),
        R7_indicates_current_status_of_WorkoutSession()
    {
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_Display::get_R7_indicates_current_status_of_WorkoutSession ( )
    {
      return R7_indicates_current_status_of_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_Display::get_R7_indicates_current_status_of_WorkoutSession ( ) const
    {
      return R7_indicates_current_status_of_WorkoutSession;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_Display::navigate_R7_indicates_current_status_of_WorkoutSession ( ) const
    {
      return get_R7_indicates_current_status_of_WorkoutSession().navigate();
    }

    ::std::size_t maslo_Display::count_R7_indicates_current_status_of_WorkoutSession ( ) const
    {
      return get_R7_indicates_current_status_of_WorkoutSession().count();
    }

    void maslo_Display::link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R7_indicates_current_status_of_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R7_current_status_indicated_on_Display().link( ::SWA::ObjectPtr<maslo_Display>( this ) );
      }
      catch ( ... )
      {
        this->get_R7_indicates_current_status_of_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Display::unlink_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R7_indicates_current_status_of_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R7_current_status_indicated_on_Display().unlink( ::SWA::ObjectPtr<maslo_Display>( this ) );
      }
      catch ( ... )
      {
        this->get_R7_indicates_current_status_of_WorkoutSession().link( rhs2 );
        throw;
      }
    }

  }
}
