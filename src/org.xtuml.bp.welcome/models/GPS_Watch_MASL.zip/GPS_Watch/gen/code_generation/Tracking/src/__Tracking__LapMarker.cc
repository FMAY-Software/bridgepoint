//
// File: __Tracking__LapMarker.cc
//
#include "__Tracking__LapMarker.hh"
#include "__Tracking__LapMarkerPopulation.hh"
#include "__Tracking__TrackLog.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_LapMarker> maslo_LapMarker::getInstance ( ::SWA::IdType id )
  {
    return maslo_LapMarkerPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_LapMarker::getNextArchId ( )
  {
    return maslo_LapMarkerPopulation::getSingleton().getNextArchId();
  }

  maslo_LapMarker::maslo_LapMarker ( )
    : isDeletedFlag()
  {
  }

  maslo_LapMarker::~maslo_LapMarker ( )
  {
  }

  ::SWA::ObjectPtr<maslo_LapMarker> maslo_LapMarker::createInstance ( int32_t                 masla_lapTime,
                                                                      const ::SWA::Timestamp& masla_session_startTime )
  {
    return maslo_LapMarkerPopulation::getSingleton().createInstance( masla_lapTime, masla_session_startTime );
  }

  void maslo_LapMarker::deleteInstance ( )
  {
    if ( count_R5_marks_end_of_lap_in_TrackLog() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R5 still linked" );
    maslo_LapMarkerPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_LapMarker>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_LapMarker::getPopulationSize ( )
  {
    return maslo_LapMarkerPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_LapMarker> > maslo_LapMarker::findAll ( )
  {
    return maslo_LapMarkerPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_LapMarker> maslo_LapMarker::findOne ( )
  {
    return maslo_LapMarkerPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_LapMarker> maslo_LapMarker::findOnly ( )
  {
    return maslo_LapMarkerPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_LapMarker::count_R5_marks_end_of_lap_in_TrackLog ( ) const
  {
    return navigate_R5_marks_end_of_lap_in_TrackLog() == ::SWA::Null ? 0
                                                                     : 1;
  }

  void maslo_LapMarker::checked_link_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R5_marks_end_of_lap_in_TrackLog( rhs );
  }

  void maslo_LapMarker::unlink_R5_marks_end_of_lap_in_TrackLog ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackLog>& rhs = navigate_R5_marks_end_of_lap_in_TrackLog();
    if ( rhs ) unlink_R5_marks_end_of_lap_in_TrackLog( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&        stream,
                               const maslo_LapMarker& obj )
  {
    stream << "(";
    stream << obj.get_masla_lapTime();
    stream << ",";
    stream << obj.get_masla_session_startTime();
    stream << ")";
    return stream;
  }

}
