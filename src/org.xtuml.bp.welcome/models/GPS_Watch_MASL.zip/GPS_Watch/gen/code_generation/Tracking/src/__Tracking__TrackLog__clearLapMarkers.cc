//
// File: __Tracking__TrackLog__clearLapMarkers.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "boost/bind.hpp"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_TrackLog::masls_clearLapMarkers ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_TrackLog, serviceId_masls_clearLapMarkers);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // lapMarkers : set of instance of LapMarker;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_LapMarker> > maslv_lapMarkers;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_lapMarkers(0, maslv_lapMarkers);

        // lapMarkers := this -> R5.has_laps_defined_by.LapMarker;
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_lapMarkers = ::SWA::navigate_many<maslo_LapMarker>( ::SWA::ObjectPtr<maslo_TrackLog>( this ), ::boost::bind( &maslo_TrackLog::navigate_R5_has_laps_defined_by_LapMarker, _1 ) );
        }

        // for lapMarker in lapMarkers'elements loop ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::SWA::Set< ::SWA::ObjectPtr<maslo_LapMarker> > collection = maslv_lapMarkers;
          for ( ::SWA::Set< ::SWA::ObjectPtr<maslo_LapMarker> >::const_iterator i = collection.begin(); i != collection.end(); ++i )
          {
            const ::SWA::ObjectPtr<maslo_LapMarker>& maslv_lapMarker = *i;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_lapMarker(1, maslv_lapMarker);

            // unlink this R5.has_laps_defined_by.LapMarker  lapMarker;
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              ::SWA::ObjectPtr<maslo_TrackLog>( this )->unlink_R5_has_laps_defined_by_LapMarker( maslv_lapMarker );
            }

            // delete lapMarker;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_lapMarker.deleteInstance();
            }
          }
        }
      }
    }
  }

}
