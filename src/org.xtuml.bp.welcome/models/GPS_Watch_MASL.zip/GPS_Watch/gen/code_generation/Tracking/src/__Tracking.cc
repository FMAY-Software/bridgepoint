//
// File: __Tracking.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "swa/Domain.hh"

namespace masld_Tracking
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
