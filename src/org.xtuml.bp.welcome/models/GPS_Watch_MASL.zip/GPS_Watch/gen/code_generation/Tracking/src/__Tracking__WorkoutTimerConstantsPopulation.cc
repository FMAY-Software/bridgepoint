//
// File: __Tracking__WorkoutTimerConstantsPopulation.cc
//
#include "__Tracking__WorkoutTimerConstantsPopulation.hh"

namespace masld_Tracking
{
  maslo_WorkoutTimerConstantsPopulation::maslo_WorkoutTimerConstantsPopulation ( )
  {
  }

  maslo_WorkoutTimerConstantsPopulation::~maslo_WorkoutTimerConstantsPopulation ( )
  {
  }

}
