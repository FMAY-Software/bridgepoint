//
// File: __Tracking__HeartRateSample.hh
//
#ifndef _Tracking_Heart_Rate_Sample_hh
#define _Tracking_Heart_Rate_Sample_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
  class maslo_HeartRateSample;
  class maslo_HeartRateSample
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_HeartRateSample> createInstance ( int32_t                 masla_heartRate,
                                                                      int32_t                 masla_time,
                                                                      const ::SWA::Timestamp& masla_session_startTime );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_HeartRateSample> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_heartRate ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_heartRate ( ) const = 0;
      virtual int32_t get_masla_time ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;


    // Find Predicates
    public:
      // MASL find: (time >= p1)
      bool findPredicate_OPmasl_time_maslGEp1CP ( int32_t p1 ) const { return !isDeleted() && get_masla_time() >= p1; }


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > findAll ( );
      static ::SWA::ObjectPtr<maslo_HeartRateSample> findOne ( );
      static ::SWA::ObjectPtr<maslo_HeartRateSample> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_HeartRateSample ( );
      virtual ~maslo_HeartRateSample ( );


    // Prevent copy
    private:
      maslo_HeartRateSample ( const maslo_HeartRateSample& rhs );
      maslo_HeartRateSample& operator= ( const maslo_HeartRateSample& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {};


    // Relationship R6.was_collected_during.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R6_was_collected_during_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R6_was_collected_during_WorkoutSession ( ) const;
      virtual void link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R6_was_collected_during_WorkoutSession ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&              stream,
                               const maslo_HeartRateSample& obj );
}
#endif // _Tracking_Heart_Rate_Sample_hh
