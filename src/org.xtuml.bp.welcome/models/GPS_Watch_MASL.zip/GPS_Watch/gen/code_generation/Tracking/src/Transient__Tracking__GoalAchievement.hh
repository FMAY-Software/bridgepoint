//
// File: Transient__Tracking__GoalAchievement.hh
//
#ifndef Transient_Tracking_Goal_Achievement_hh
#define Transient_Tracking_Goal_Achievement_hh

#include "__Tracking__GoalAchievement.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_GoalAchievement
      : public ::masld_Tracking::maslo_GoalAchievement
    {

      // Constructors and Destructors
      public:
        maslo_GoalAchievement ( int32_t masla_id,
                                int32_t masla_evaluationPeriod );


      // Setters for each object attribute
      public:
        virtual void set_masla_evaluationPeriod ( int32_t value ) { this->masla_evaluationPeriod = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_evaluationPeriod ( ) const { return masla_evaluationPeriod; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_evaluationPeriod;


    };
  }
}
#endif // Transient_Tracking_Goal_Achievement_hh
