//
// File: __Tracking__LOC__getDistance.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Tracking
{
  void maslb_LOC::masls_getDistance ( double& maslp_result,
                                      double  maslp_toLong,
                                      double  maslp_toLat,
                                      double  maslp_fromLong,
                                      double  maslp_fromLat )
  {
    getInstance().override_masls_getDistance.getFunction()( maslp_result, maslp_toLong, maslp_toLat, maslp_fromLong, maslp_fromLat );
  }

  bool maslb_LOC::register_masls_getDistance ( ::SWA::FunctionOverrider<void (double&,double,double,double,double)>::FunctionPtr override )
  {
    getInstance().override_masls_getDistance.override( override );
    return true;
  }

  bool maslb_LOC::overriden_masls_getDistance ( )
  {
    return getInstance().override_masls_getDistance.isOverridden();
  }

  void maslb_LOC::domain_masls_getDistance ( double& maslp_result,
                                             double  maslp_toLong,
                                             double  maslp_toLat,
                                             double  maslp_fromLong,
                                             double  maslp_fromLat )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_LOC, serviceId_masls_getDistance);
      ::SWA::Stack::DeclareParameter pm_maslp_result(maslp_result);
      ::SWA::Stack::DeclareParameter pm_maslp_toLong(maslp_toLong);
      ::SWA::Stack::DeclareParameter pm_maslp_toLat(maslp_toLat);
      ::SWA::Stack::DeclareParameter pm_maslp_fromLong(maslp_fromLong);
      ::SWA::Stack::DeclareParameter pm_maslp_fromLat(maslp_fromLat);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(6);
      {

        // LOG::LogInfo("Sending message 'getDistance' on terminator LOC")
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'getDistance' on terminator LOC" ) );
        }
      }
    }
  }

}
