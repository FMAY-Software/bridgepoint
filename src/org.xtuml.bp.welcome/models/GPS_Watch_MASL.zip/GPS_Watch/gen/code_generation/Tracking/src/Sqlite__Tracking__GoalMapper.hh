//
// File: Sqlite__Tracking__GoalMapper.hh
//
#ifndef Sqlite_Tracking_Goal_Mapper_hh
#define Sqlite_Tracking_Goal_Mapper_hh

#include "Sqlite__Tracking__Goal.hh"
#include "__Tracking__Goal.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"

namespace masld_Tracking
{
  class maslt_GoalDisposition;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_Goal,maslo_Goal>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> createInstance ( const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                                                                                 double                                         masla_startingPoint,
                                                                                 int32_t                                        masla_ID,
                                                                                 const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                                                                                 const ::SWA::Timestamp&                        masla_session_startTime,
                                                                                 int32_t                                        masla_spec_sequenceNumber,
                                                                                 ::masld_Tracking::maslo_Goal::Type             currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_GoalMapper ( );
        virtual ~maslo_GoalMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_Goal::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Mapper_hh
