//
// File: Sqlite__Tracking__HeartRateSamplePopulation.cc
//
#include "Sqlite__Tracking__HeartRateSample.hh"
#include "Sqlite__Tracking__HeartRateSamplePopulation.hh"
#include "Sqlite__Tracking__R6Mapper.hh"
#include "Sqlite__Tracking__R6MapperSql.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionPopulation.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/signals2.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_HeartRateSamplePopulation::maslo_HeartRateSamplePopulation ( )
      : R6Mapper(RelationshipR6Mapper::singleton())
    {
    }

    maslo_HeartRateSamplePopulation::~maslo_HeartRateSamplePopulation ( )
    {
    }

    void maslo_HeartRateSamplePopulation::initialise ( )
    {
      mapper->initialise();
      if ( R6Mapper.isInitialised() == false )
      {
        R6Mapper.initialise( ::boost::shared_ptr<RelationshipR6Mapper::RelSqlGeneratorType>( new RelationshipR6SqlGenerator() ) );
      }

    }

    maslo_HeartRateSamplePopulation& maslo_HeartRateSamplePopulation::getPopulation ( )
    {
      static maslo_HeartRateSamplePopulation population;
      return population;
    }

    bool maslo_HeartRateSamplePopulation::registered = maslo_HeartRateSamplePopulation::registerSingleton( &maslo_HeartRateSamplePopulation::getPopulation );

    ::boost::signals2::connection maslo_HeartRateSamplePopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_HeartRateSamplePopulation::initialise, ::boost::bind( &maslo_HeartRateSamplePopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> maslo_HeartRateSamplePopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > maslo_HeartRateSamplePopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> maslo_HeartRateSamplePopulation::createInstance ( int32_t                 masla_heartRate,
                                                                                                                 int32_t                 masla_time,
                                                                                                                 const ::SWA::Timestamp& masla_session_startTime )
    {
      return mapper->createInstance( masla_heartRate, masla_time, masla_session_startTime );
    }

    void maslo_HeartRateSamplePopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance )
    {
      {
        R6Mapper.objectDeletedRhs( instance.downcast<maslo_HeartRateSample>() );
      }
      mapper->deleteInstance( instance );
    }

    void maslo_HeartRateSamplePopulation::link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs,
                                                                                        const ::SWA::ObjectPtr<maslo_WorkoutSession>&  rhs )
    {
      R6Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_HeartRateSamplePopulation::unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs,
                                                                                          const ::SWA::ObjectPtr<maslo_WorkoutSession>&  rhs )
    {
      R6Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_HeartRateSamplePopulation::navigate_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs )
    {
      const RelationshipR6Mapper::NavigatedLhsType& navigated(R6Mapper.navigateFromRhsToLhs( lhs ));
      return maslo_WorkoutSessionPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_HeartRateSamplePopulation::count_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs )
    {
      return R6Mapper.countFromRhsToLhs( lhs );
    }

  }
}
