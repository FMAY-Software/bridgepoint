//
// File: Sqlite__Tracking__WorkoutTimer.hh
//
#ifndef Sqlite_Tracking_Workout_Timer_hh
#define Sqlite_Tracking_Workout_Timer_hh

#include "__Tracking__WorkoutTimer.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutTimer
      : public ::masld_Tracking::maslo_WorkoutTimer
    {

      // Type definitions
      public:
        typedef ::boost::tuple< ::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple< ::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_WorkoutTimer ( ::SWA::IdType architectureId );
        maslo_WorkoutTimer ( ::SWA::IdType                              architectureId,
                             int32_t                                    masla_time,
                             const ::SWA::EventTimers::TimerIdType&     masla_timer,
                             const ::SWA::Timestamp&                    masla_session_startTime,
                             ::masld_Tracking::maslo_WorkoutTimer::Type currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_time ( int32_t value )
        {
          this->masla_time = value;
          markAsModified();
        }
        virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value )
        {
          this->masla_timer = value;
          markAsModified();
        }
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }
        virtual void setCurrentState ( ::masld_Tracking::maslo_WorkoutTimer::Type newState )
        {
          currentState = newState;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_time ( ) const { return masla_time; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const { return masla_timer; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual ::masld_Tracking::maslo_WorkoutTimer::Type getCurrentState ( ) const { return currentState; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_time;
        ::SWA::EventTimers::TimerIdType masla_timer;
        ::SWA::Timestamp masla_session_startTime;
        ::masld_Tracking::maslo_WorkoutTimer::Type currentState;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Timer_hh
