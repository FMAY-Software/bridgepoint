//
// File: Transient__Tracking__GoalPopulation.hh
//
#ifndef Transient_Tracking_Goal_Population_hh
#define Transient_Tracking_Goal_Population_hh

#include "__Tracking__Goal.hh"
#include "__Tracking__GoalPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace masld_Tracking
{
  class maslt_GoalDisposition;
}
namespace transient
{
  namespace masld_Tracking
  {
    class maslo_GoalPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_Goal,::masld_Tracking::maslo_GoalPopulation>
    {

      // Instance Creation
      private:
        maslo_GoalPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> createInstance ( const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                                                                                 double                                         masla_startingPoint,
                                                                                 int32_t                                        masla_ID,
                                                                                 const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                                                                                 const ::SWA::Timestamp&                        masla_session_startTime,
                                                                                 int32_t                                        masla_spec_sequenceNumber,
                                                                                 ::masld_Tracking::maslo_Goal::Type             currentState );


      // Singleton Registration
      public:
        static maslo_GoalPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp,int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > masla_IDmasla_session_startTimemasla_spec_sequenceNumber_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance );
      protected:
        bool exists_masla_IDmasla_session_startTimemasla_spec_sequenceNumber ( int32_t                 masla_ID,
                                                                               const ::SWA::Timestamp& masla_session_startTime,
                                                                               int32_t                 masla_spec_sequenceNumber ) const;


    };
  }
}
#endif // Transient_Tracking_Goal_Population_hh
