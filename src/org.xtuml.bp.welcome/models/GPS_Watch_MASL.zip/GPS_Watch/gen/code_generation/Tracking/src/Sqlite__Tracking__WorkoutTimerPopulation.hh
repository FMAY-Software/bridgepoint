//
// File: Sqlite__Tracking__WorkoutTimerPopulation.hh
//
#ifndef Sqlite_Tracking_Workout_Timer_Population_hh
#define Sqlite_Tracking_Workout_Timer_Population_hh

#include "Sqlite__Tracking__R8Mapper.hh"
#include "Sqlite__Tracking__WorkoutTimer.hh"
#include "Sqlite__Tracking__WorkoutTimerMapper.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "__Tracking__WorkoutTimerPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
}
namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutTimerPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_WorkoutTimer,maslo_WorkoutTimer,maslo_WorkoutTimerMapper,::masld_Tracking::maslo_WorkoutTimerPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_WorkoutTimerPopulation ( );
        ~maslo_WorkoutTimerPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> createInstance ( int32_t                                    masla_time,
                                                                                         const ::SWA::EventTimers::TimerIdType&     masla_timer,
                                                                                         const ::SWA::Timestamp&                    masla_session_startTime,
                                                                                         ::masld_Tracking::maslo_WorkoutTimer::Type currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>& lhs );


      // Relationship Links
      public:
        void link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>&   lhs,
                                                                const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
        void unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>&   lhs,
                                                                  const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>& lhs );


      // Singleton Registration
      public:
        static maslo_WorkoutTimerPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR8Mapper& R8Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Timer_Population_hh
