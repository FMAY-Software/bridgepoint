//
// File: Inspector__Tracking__TrackLog.hh
//
#ifndef Inspector_Tracking_Track_Log_hh
#define Inspector_Tracking_Track_Log_hh

#include "__Tracking__TrackLog.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_TrackLog
    {
      class maslo_TrackLogHandler
        : public ObjectHandler< ::masld_Tracking::maslo_TrackLog>
      {

        // Constructors
        public:
          maslo_TrackLogHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                               channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance,
                                       int                                                 relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Track_Log_hh
