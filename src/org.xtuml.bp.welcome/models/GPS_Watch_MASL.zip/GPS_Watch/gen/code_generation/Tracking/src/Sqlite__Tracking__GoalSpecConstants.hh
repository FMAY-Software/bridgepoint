//
// File: Sqlite__Tracking__GoalSpecConstants.hh
//
#ifndef Sqlite_Tracking_Goal_Spec_Constants_hh
#define Sqlite_Tracking_Goal_Spec_Constants_hh

#include "__Tracking__GoalSpecConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecConstants
      : public ::masld_Tracking::maslo_GoalSpecConstants
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_GoalSpecConstants ( ::SWA::IdType architectureId );
        maslo_GoalSpecConstants ( ::SWA::IdType architectureId,
                                  int32_t       masla_id,
                                  int32_t       masla_GoalSpecOrigin );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_GoalSpecOrigin ( int32_t value )
        {
          this->masla_GoalSpecOrigin = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_GoalSpecOrigin ( ) const { return masla_GoalSpecOrigin; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_GoalSpecOrigin;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Spec_Constants_hh
