//
// File: Inspector__Tracking__LOC.hh
//
#ifndef Inspector_Tracking_LOC_hh
#define Inspector_Tracking_LOC_hh

#include "inspector/TerminatorHandler.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      class maslb_LOCHandler
        : public TerminatorHandler
      {

        // Constructors
        public:
          maslb_LOCHandler ( );


      };
    }
  }
}
#endif // Inspector_Tracking_LOC_hh
