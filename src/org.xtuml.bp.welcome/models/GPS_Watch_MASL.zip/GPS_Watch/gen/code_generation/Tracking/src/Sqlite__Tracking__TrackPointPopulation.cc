//
// File: Sqlite__Tracking__TrackPointPopulation.cc
//
#include "Sqlite__Tracking__R1Mapper.hh"
#include "Sqlite__Tracking__R1MapperSql.hh"
#include "Sqlite__Tracking__R2Mapper.hh"
#include "Sqlite__Tracking__R2MapperSql.hh"
#include "Sqlite__Tracking__R3Mapper.hh"
#include "Sqlite__Tracking__R3MapperSql.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackLogPopulation.hh"
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__TrackPointPopulation.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/signals2.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackPointPopulation::maslo_TrackPointPopulation ( )
      : R1Mapper(RelationshipR1Mapper::singleton()),
        R2Mapper(RelationshipR2Mapper::singleton()),
        R3Mapper(RelationshipR3Mapper::singleton())
    {
    }

    maslo_TrackPointPopulation::~maslo_TrackPointPopulation ( )
    {
    }

    void maslo_TrackPointPopulation::initialise ( )
    {
      mapper->initialise();
      if ( R1Mapper.isInitialised() == false )
      {
        R1Mapper.initialise( ::boost::shared_ptr<RelationshipR1Mapper::RelSqlGeneratorType>( new RelationshipR1SqlGenerator() ) );
      }

      if ( R2Mapper.isInitialised() == false )
      {
        R2Mapper.initialise( ::boost::shared_ptr<RelationshipR2Mapper::RelSqlGeneratorType>( new RelationshipR2SqlGenerator() ) );
      }

      if ( R3Mapper.isInitialised() == false )
      {
        R3Mapper.initialise( ::boost::shared_ptr<RelationshipR3Mapper::RelSqlGeneratorType>( new RelationshipR3SqlGenerator() ) );
      }

    }

    maslo_TrackPointPopulation& maslo_TrackPointPopulation::getPopulation ( )
    {
      static maslo_TrackPointPopulation population;
      return population;
    }

    bool maslo_TrackPointPopulation::registered = maslo_TrackPointPopulation::registerSingleton( &maslo_TrackPointPopulation::getPopulation );

    ::boost::signals2::connection maslo_TrackPointPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_TrackPointPopulation::initialise, ::boost::bind( &maslo_TrackPointPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPointPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> > maslo_TrackPointPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPointPopulation::createInstance ( int32_t                 masla_time,
                                                                                                       double                  masla_longitude,
                                                                                                       double                  masla_latitude,
                                                                                                       const ::SWA::Timestamp& masla_session_startTime )
    {
      return mapper->createInstance( masla_time, masla_longitude, masla_latitude, masla_session_startTime );
    }

    void maslo_TrackPointPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance )
    {
      {
        R1Mapper.objectDeletedRhs( instance.downcast<maslo_TrackPoint>() );
        R2Mapper.objectDeletedLhs( instance.downcast<maslo_TrackPoint>() );
        R3Mapper.objectDeletedRhs( instance.downcast<maslo_TrackPoint>() );
      }
      mapper->deleteInstance( instance );
    }

    void maslo_TrackPointPopulation::link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                    const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs )
    {
      R1Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_TrackPointPopulation::unlink_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                      const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs )
    {
      R1Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackPointPopulation::navigate_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      const RelationshipR1Mapper::NavigatedLhsType& navigated(R1Mapper.navigateFromRhsToLhs( lhs ));
      return maslo_TrackLogPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackPointPopulation::count_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      return R1Mapper.countFromRhsToLhs( lhs );
    }

    void maslo_TrackPointPopulation::link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                  const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R2Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_TrackPointPopulation::unlink_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                    const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R2Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPointPopulation::navigate_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      const RelationshipR2Mapper::NavigatedRhsType& navigated(R2Mapper.navigateFromLhsToRhs( lhs ));
      return getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackPointPopulation::count_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      return R2Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_TrackPointPopulation::link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                   const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R2Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_TrackPointPopulation::unlink_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                     const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R2Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPointPopulation::navigate_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      const RelationshipR2Mapper::NavigatedLhsType& navigated(R2Mapper.navigateFromRhsToLhs( lhs ));
      return getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackPointPopulation::count_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      return R2Mapper.countFromRhsToLhs( lhs );
    }

    void maslo_TrackPointPopulation::link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                    const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs )
    {
      R3Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_TrackPointPopulation::unlink_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                                                      const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs )
    {
      R3Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackPointPopulation::navigate_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      const RelationshipR3Mapper::NavigatedLhsType& navigated(R3Mapper.navigateFromRhsToLhs( lhs ));
      return maslo_TrackLogPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackPointPopulation::count_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs )
    {
      return R3Mapper.countFromRhsToLhs( lhs );
    }

  }
}
