//
// File: __Tracking__HeartRateConstants.cc
//
#include "__Tracking__HeartRateConstants.hh"
#include "__Tracking__HeartRateConstantsPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_HeartRateConstants> maslo_HeartRateConstants::getInstance ( ::SWA::IdType id )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_HeartRateConstants::getNextArchId ( )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().getNextArchId();
  }

  maslo_HeartRateConstants::maslo_HeartRateConstants ( )
    : isDeletedFlag()
  {
  }

  maslo_HeartRateConstants::~maslo_HeartRateConstants ( )
  {
  }

  ::SWA::ObjectPtr<maslo_HeartRateConstants> maslo_HeartRateConstants::createInstance ( int32_t masla_id,
                                                                                        int32_t masla_HeartRateAveragingWindow,
                                                                                        int32_t masla_HeartRateSamplingPeriod )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().createInstance( masla_id, masla_HeartRateAveragingWindow, masla_HeartRateSamplingPeriod );
  }

  void maslo_HeartRateConstants::deleteInstance ( )
  {
    maslo_HeartRateConstantsPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_HeartRateConstants>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_HeartRateConstants::getPopulationSize ( )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateConstants> > maslo_HeartRateConstants::findAll ( )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_HeartRateConstants> maslo_HeartRateConstants::findOne ( )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_HeartRateConstants> maslo_HeartRateConstants::findOnly ( )
  {
    return maslo_HeartRateConstantsPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&                 stream,
                               const maslo_HeartRateConstants& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_HeartRateAveragingWindow();
    stream << ",";
    stream << obj.get_masla_HeartRateSamplingPeriod();
    stream << ")";
    return stream;
  }

}
