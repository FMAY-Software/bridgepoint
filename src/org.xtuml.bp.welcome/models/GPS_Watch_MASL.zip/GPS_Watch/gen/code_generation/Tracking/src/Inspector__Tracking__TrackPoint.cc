//
// File: Inspector__Tracking__TrackPoint.cc
//
#include "Inspector__Tracking__TrackPoint.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/lexical_cast.hpp"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_TrackPoint
    {
      maslo_TrackPointHandler::maslo_TrackPointHandler ( )
      {
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_TrackPoint> ( const ::masld_Tracking::maslo_TrackPoint& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_time() );
    write( instance.get_masla_longitude() );
    write( instance.get_masla_latitude() );
    write( instance.get_masla_session_startTime() );
    {
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> related = instance.navigate_R2_preceeds_TrackPoint();
      if ( related )
      {
        write( true );
        write( related->get_masla_time() );
      }
      else
      {
        write( false );
      }
    }
    write( instance.navigate_R1_is_start_of_TrackLog() );
    write( instance.navigate_R2_follows_TrackPoint() );
    write( instance.navigate_R2_preceeds_TrackPoint() );
    write( instance.navigate_R3_is_last_for_TrackLog() );
  }

  namespace masld_Tracking
  {
    namespace maslo_TrackPoint
    {
      void maslo_TrackPointHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_time;
        double masla_longitude;
        double masla_latitude;
        ::SWA::Timestamp masla_session_startTime;
        channel >> masla_time >> masla_longitude >> masla_latitude >> masla_session_startTime;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance = ::masld_Tracking::maslo_TrackPoint::createInstance( masla_time, masla_longitude, masla_latitude, masla_session_startTime );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_TrackPointHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_time() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_TrackPoint::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_TrackPoint
    {
      void maslo_TrackPointHandler::writeRelatedInstances ( CommunicationChannel&                                 channel,
                                                            ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance,
                                                            int                                                   relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackLog>( ::masld_Tracking::objectId_maslo_TrackLog ).writeInstances( channel, instance ? instance->navigate_R1_is_start_of_TrackLog()
                                                                                                                                                                                                                                       : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>() );
            break;

          case 1:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackPoint>( ::masld_Tracking::objectId_maslo_TrackPoint ).writeInstances( channel, instance ? instance->navigate_R2_follows_TrackPoint()
                                                                                                                                                                                                                                           : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>() );
            break;

          case 2:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackPoint>( ::masld_Tracking::objectId_maslo_TrackPoint ).writeInstances( channel, instance ? instance->navigate_R2_preceeds_TrackPoint()
                                                                                                                                                                                                                                           : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>() );
            break;

          case 3:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackLog>( ::masld_Tracking::objectId_maslo_TrackLog ).writeInstances( channel, instance ? instance->navigate_R3_is_last_for_TrackLog()
                                                                                                                                                                                                                                       : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>() );
            break;

        }

      }

    }
  }
}
