//
// File: Inspector__Tracking__LapMarker.hh
//
#ifndef Inspector_Tracking_Lap_Marker_hh
#define Inspector_Tracking_Lap_Marker_hh

#include "__Tracking__LapMarker.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_LapMarker
    {
      class maslo_LapMarkerHandler
        : public ObjectHandler< ::masld_Tracking::maslo_LapMarker>
      {

        // Constructors
        public:
          maslo_LapMarkerHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance,
                                       int                                                  relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Lap_Marker_hh
