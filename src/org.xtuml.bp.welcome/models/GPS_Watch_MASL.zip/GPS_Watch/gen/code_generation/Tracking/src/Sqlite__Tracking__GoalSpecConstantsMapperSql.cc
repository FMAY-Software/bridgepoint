//
// File: Sqlite__Tracking__GoalSpecConstantsMapperSql.cc
//
#include "Sqlite__Tracking__GoalSpecConstants.hh"
#include "Sqlite__Tracking__GoalSpecConstantsMapperSql.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Tracking_GOALSPECCONSTANTS(   architecture_id  INTEGER ,   masla_id INTEGER,   masla_GoalSpecOrigin INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Tracking_GOALSPECCONSTANTS", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecConstantsSqlGenerator::maslo_GoalSpecConstantsSqlGenerator ( )
      : tableName("S_Tracking_GOALSPECCONSTANTS"),
        objectName("GoalSpecConstants"),
        insertStatement("INSERT INTO S_Tracking_GOALSPECCONSTANTS VALUES(:1,:2,:3);"),
        updateStatement("UPDATE S_Tracking_GOALSPECCONSTANTS SET masla_id = :2  , masla_GoalSpecOrigin = :3  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Tracking_GOALSPECCONSTANTS WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_GoalSpecConstantsSqlGenerator::~maslo_GoalSpecConstantsSqlGenerator ( )
    {
    }

    void maslo_GoalSpecConstantsSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["GoalSpecOrigin"] = ::std::string( "masla_GoalSpecOrigin" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_GoalSpecConstantsSqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string& maslo_GoalSpecConstantsSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_GoalSpecConstantsSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_GoalSpecConstantsSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                         int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_GOALSPECCONSTANTS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                         int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_GOALSPECCONSTANTS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Tracking_GOALSPECCONSTANTS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_GoalSpecConstantsSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_GoalSpecConstantsSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_GoalSpecOrigin() ) );
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_GoalSpecOrigin() ) );
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeSelect ( CacheType&             cache,
                                                              const ::SQL::Criteria& criteria,
                                                              PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("GoalSpecConstants::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "GoalSpecConstants::executeSelect", compile_result, query );
        database.checkColumnCount( "GoalSpecConstants::executeSelect", sqlite3_column_count( ppStmt ), 3, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_GoalSpecConstants(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            int32_t GoalSpecOrigin = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_GoalSpecOrigin( GoalSpecOrigin );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_GoalSpecConstantsSqlGenerator::executeSelect ( CacheType&             cache,
                                                              const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("GoalSpecConstants::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "GoalSpecConstants::executeSelect", compile_result, query );
        database.checkColumnCount( "GoalSpecConstants::executeSelect", sqlite3_column_count( ppStmt ), 3, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_GoalSpecConstants(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            int32_t GoalSpecOrigin = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_GoalSpecOrigin( GoalSpecOrigin );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
