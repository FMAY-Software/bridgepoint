//
// File: __UI__UIConstants.cc
//
#include "__UI__UIConstants.hh"
#include "__UI__UIConstantsPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  ::SWA::ObjectPtr<maslo_UIConstants> maslo_UIConstants::getInstance ( ::SWA::IdType id )
  {
    return maslo_UIConstantsPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_UIConstants::getNextArchId ( )
  {
    return maslo_UIConstantsPopulation::getSingleton().getNextArchId();
  }

  maslo_UIConstants::maslo_UIConstants ( )
    : isDeletedFlag()
  {
  }

  maslo_UIConstants::~maslo_UIConstants ( )
  {
  }

  ::SWA::ObjectPtr<maslo_UIConstants> maslo_UIConstants::createInstance ( int32_t masla_id,
                                                                          int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                          int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                          int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                          int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                          int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                          int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                          int32_t masla_SOCKET_ERROR,
                                                                          int32_t masla_tick_period )
  {
    return maslo_UIConstantsPopulation::getSingleton().createInstance( masla_id, masla_SIGNAL_NO_NULL_SIGNAL, masla_SIGNAL_NO_START_STOP_PRESSED, masla_SIGNAL_NO_TARGET_PRESSED, masla_SIGNAL_NO_LAP_RESET_PRESSED, masla_SIGNAL_NO_LIGHT_PRESSED, masla_SIGNAL_NO_MODE_PRESSED, masla_SOCKET_ERROR, masla_tick_period );
  }

  void maslo_UIConstants::deleteInstance ( )
  {
    maslo_UIConstantsPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_UIConstants>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_UIConstants::getPopulationSize ( )
  {
    return maslo_UIConstantsPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_UIConstants> > maslo_UIConstants::findAll ( )
  {
    return maslo_UIConstantsPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_UIConstants> maslo_UIConstants::findOne ( )
  {
    return maslo_UIConstantsPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_UIConstants> maslo_UIConstants::findOnly ( )
  {
    return maslo_UIConstantsPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&          stream,
                               const maslo_UIConstants& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_SIGNAL_NO_NULL_SIGNAL();
    stream << ",";
    stream << obj.get_masla_SIGNAL_NO_START_STOP_PRESSED();
    stream << ",";
    stream << obj.get_masla_SIGNAL_NO_TARGET_PRESSED();
    stream << ",";
    stream << obj.get_masla_SIGNAL_NO_LAP_RESET_PRESSED();
    stream << ",";
    stream << obj.get_masla_SIGNAL_NO_LIGHT_PRESSED();
    stream << ",";
    stream << obj.get_masla_SIGNAL_NO_MODE_PRESSED();
    stream << ",";
    stream << obj.get_masla_SOCKET_ERROR();
    stream << ",";
    stream << obj.get_masla_tick_period();
    stream << ")";
    return stream;
  }

}
