//
// File: Inspector__UI__TestCase.cc
//
#include "Inspector__UI__TestCase.hh"
#include "__UI__TestCase.hh"
#include "__UI__TestCaseEvents.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/EventHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslo_TestCase
    {
      class masls_executeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_executeInvoker
      {

        public:
          masls_executeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslo_TestCase::masls_execute(); }


      };
      class maslst_pressStartStopHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_testCaseFinishedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_initializeHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_IdleHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_TestCase_maslev_doDelayHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_TestCase_maslev_finishHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_TestCase_maslev_initializationCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_TestCase_maslev_initializeHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_executeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_executeInvoker( channel );
      }

      void masls_executeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write tc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> >();
              break;

          }

        }
      }

      void maslst_pressStartStopHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase>( frame.getThis< ::masld_UI::maslo_TestCase>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write handle
              channel << frame.getLocalVars()[i].getValue< ::SWA::EventTimers::TimerIdType>();
              break;

          }

        }
      }

      void maslst_testCaseFinishedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase>( frame.getThis< ::masld_UI::maslo_TestCase>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase>( frame.getThis< ::masld_UI::maslo_TestCase>() );

        // Write iterations
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_IdleHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase>( frame.getThis< ::masld_UI::maslo_TestCase>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_TestCase_maslev_doDelayHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_TestCase_maslev_doDelay( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_TestCase_maslev_doDelayHandler::writeParameters ( const ::SWA::Event&   event,
                                                                   BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_TestCase_maslev_doDelay& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_TestCase_maslev_doDelay&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_TestCase_maslev_finishHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_TestCase_maslev_finish( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_TestCase_maslev_finishHandler::writeParameters ( const ::SWA::Event&   event,
                                                                  BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_TestCase_maslev_finish& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_TestCase_maslev_finish&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_TestCase_maslev_initializationCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_TestCase_maslev_initializationComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_TestCase_maslev_initializationCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                  BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_TestCase_maslev_initializationComplete& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_TestCase_maslev_initializationComplete&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_TestCase_maslev_initializeHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> thisVar;
        channel >> thisVar;
        int32_t maslp_iterations;
        channel >> maslp_iterations;
        return thisVar ? thisVar->create_maslo_TestCase_maslev_initialize( maslp_iterations, sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_TestCase_maslev_initializeHandler::writeParameters ( const ::SWA::Event&   event,
                                                                      BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_TestCase_maslev_initialize& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_TestCase_maslev_initialize&>( event );
        stream.write( typedEvent.getmaslp_iterations() );
      }

      maslo_TestCaseHandler::maslo_TestCaseHandler ( )
      {
        registerServiceHandler( ::masld_UI::maslo_TestCase::serviceId_masls_execute, ::boost::shared_ptr<ActionHandler>( new masls_executeHandler() ) );
        registerStateHandler( ::masld_UI::maslo_TestCase::stateId_maslst_pressStartStop, ::boost::shared_ptr<ActionHandler>( new maslst_pressStartStopHandler() ) );
        registerStateHandler( ::masld_UI::maslo_TestCase::stateId_maslst_testCaseFinished, ::boost::shared_ptr<ActionHandler>( new maslst_testCaseFinishedHandler() ) );
        registerStateHandler( ::masld_UI::maslo_TestCase::stateId_maslst_initialize, ::boost::shared_ptr<ActionHandler>( new maslst_initializeHandler() ) );
        registerStateHandler( ::masld_UI::maslo_TestCase::stateId_maslst_Idle, ::boost::shared_ptr<ActionHandler>( new maslst_IdleHandler() ) );
        registerEventHandler( ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_doDelay, ::boost::shared_ptr<EventHandler>( new maslo_TestCase_maslev_doDelayHandler() ) );
        registerEventHandler( ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_finish, ::boost::shared_ptr<EventHandler>( new maslo_TestCase_maslev_finishHandler() ) );
        registerEventHandler( ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_initializationComplete, ::boost::shared_ptr<EventHandler>( new maslo_TestCase_maslev_initializationCompleteHandler() ) );
        registerEventHandler( ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_initialize, ::boost::shared_ptr<EventHandler>( new maslo_TestCase_maslev_initializeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_UI::maslo_TestCase> ( const ::masld_UI::maslo_TestCase& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_iterations() );
    write( instance.get_masla_id() );
    write( static_cast<int>( instance.getCurrentState() ) );
  }

  namespace masld_UI
  {
    namespace maslo_TestCase
    {
      void maslo_TestCaseHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_iterations;
        int32_t masla_id;
        int currentState;
        channel >> masla_iterations >> masla_id >> currentState;
        ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance = ::masld_UI::maslo_TestCase::createInstance( masla_iterations, masla_id, ::masld_UI::maslo_TestCase::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_TestCaseHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> > ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_UI::maslo_TestCase::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_UI
  {
    namespace maslo_TestCase
    {
      void maslo_TestCaseHandler::writeRelatedInstances ( CommunicationChannel&                         channel,
                                                          ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance,
                                                          int                                           relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
