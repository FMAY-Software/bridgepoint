//
// File: NativeStubs.cc
//
#include "__UI__UI.hh"

namespace masld_UI
{
  void maslo_UI::masls_connect ( )
  {
  }

}
