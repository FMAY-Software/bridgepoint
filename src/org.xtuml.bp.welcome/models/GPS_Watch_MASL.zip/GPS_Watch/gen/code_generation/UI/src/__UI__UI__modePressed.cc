//
// File: __UI__UI__modePressed.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__UI.hh"
#include "__UI_private_services.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_UI
{
  void maslo_UI::state_maslst_modePressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_UI, stateId_maslst_modePressed);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // UI::sendModePressed()
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          interceptor_masls_sendModePressed::instance().callService()();
        }

        // generate UI.running () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_UI>( this )->create_maslo_UI_maslev_running( objectId_maslo_UI, getArchitectureId() ) );
        }
      }
    }
  }

}
