//
// File: Sqlite__UI__UIMapperSql.cc
//
#include "Sqlite__UI__UI.hh"
#include "Sqlite__UI__UIMapperSql.hh"
#include "__UI__UI.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_UI_UI(   architecture_id  INTEGER ,   masla_id INTEGER,   masla_socket_id INTEGER,   masla_timer INTEGER,   CurrentState INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_UI_UI", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UISqlGenerator::maslo_UISqlGenerator ( )
      : tableName("S_UI_UI"),
        objectName("UI"),
        insertStatement("INSERT INTO S_UI_UI VALUES(:1,:2,:3,:4,:5);"),
        updateStatement("UPDATE S_UI_UI SET masla_id = :2  , masla_socket_id = :3  , masla_timer = :4  , CurrentState = :5  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_UI_UI WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_UISqlGenerator::~maslo_UISqlGenerator ( )
    {
    }

    void maslo_UISqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["socket_id"] = ::std::string( "masla_socket_id" );
      columnNameMapper["timer"] = ::std::string( "masla_timer" );
      columnNameMapper["CurrentState"] = ::std::string( "CurrentState" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_UISqlGenerator::getDomainName ( ) const
    {
      return "UI";
    }

    const ::std::string& maslo_UISqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_UISqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_UISqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_UISqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_UISqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                          int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_UI_UI;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_UISqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_UISqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_UISqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                          int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_UI_UI;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_UISqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_UISqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_UISqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_UI_UI;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_UISqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_UISqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_UISqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_UISqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_socket_id(), object.getChecked()->get_masla_timer(), object->getCurrentState() ) );
    }

    void maslo_UISqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_socket_id(), object.getChecked()->get_masla_timer(), object->getCurrentState() ) );
    }

    void maslo_UISqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_UISqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_UISqlGenerator::executeSelect ( CacheType&             cache,
                                               const ::SQL::Criteria& criteria,
                                               PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("UI::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "UI::executeSelect", compile_result, query );
        database.checkColumnCount( "UI::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_UI(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            int32_t socket_id = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_socket_id( socket_id );

            int32_t timer = sqlite3_column_int( ppStmt, 3 );
            currentObject->set_masla_timer( timer );

            int32_t currentState = sqlite3_column_int( ppStmt, 4 );
            currentObject->setCurrentState( static_cast< ::masld_UI::maslo_UI::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_UISqlGenerator::executeSelect ( CacheType&             cache,
                                               const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("UI::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "UI::executeSelect", compile_result, query );
        database.checkColumnCount( "UI::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_UI(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            int32_t socket_id = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_socket_id( socket_id );

            int32_t timer = sqlite3_column_int( ppStmt, 3 );
            currentObject->set_masla_timer( timer );

            int32_t currentState = sqlite3_column_int( ppStmt, 4 );
            currentObject->setCurrentState( static_cast< ::masld_UI::maslo_UI::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
