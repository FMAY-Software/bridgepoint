//
// File: __UI__UI__initialize.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__UI.hh"
#include "__UI__UIConstants.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void maslo_UI::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_UI, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // ui : instance of UI;
        ::SWA::ObjectPtr<maslo_UI> maslv_ui;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_ui(0, maslv_ui);

        // uiconst : instance of UIConstants;
        ::SWA::ObjectPtr<maslo_UIConstants> maslv_uiconst;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_uiconst(1, maslv_uiconst);

        // ui := find_one UI ();
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_ui = findOne();
        }

        // if (null = ui) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          if ( ::SWA::Null == maslv_ui )
          {

            // UIConstants.initialize()
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              maslo_UIConstants::masls_initialize();
            }

            // uiconst := find_one UIConstants ();
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              maslv_uiconst = maslo_UIConstants::findOne();
            }

            // ui := create UI (
            //               id => 1 ,
            // Current_State => running);
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              maslv_ui = createInstance( 1ll, int32_t(), ::SWA::EventTimers::getInstance().createTimer(), maslst_running );
            }

            // ui.socket_id := uiconst.SOCKET_ERROR;
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              maslv_ui->set_masla_socket_id( maslv_uiconst->get_masla_SOCKET_ERROR() );
            }
          }
        }
      }
    }
  }

}
