//
// File: __UI__UIConstants__initialize.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__UIConstants.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void maslo_UIConstants::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_UIConstants, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // uiconst : instance of UIConstants;
        ::SWA::ObjectPtr<maslo_UIConstants> maslv_uiconst;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_uiconst(0, maslv_uiconst);

        // uiconst := find_one UIConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_uiconst = findOne();
        }

        // if (null = uiconst) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_uiconst )
          {

            // uiconst := create UIConstants (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_uiconst = createInstance( 1ll, int32_t(), int32_t(), int32_t(), int32_t(), int32_t(), int32_t(), int32_t(), int32_t() );
            }

            // uiconst.SIGNAL_NO_NULL_SIGNAL := 0;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_uiconst->set_masla_SIGNAL_NO_NULL_SIGNAL( 0ll );
            }

            // uiconst.SIGNAL_NO_START_STOP_PRESSED := 1;
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              maslv_uiconst->set_masla_SIGNAL_NO_START_STOP_PRESSED( 1ll );
            }

            // uiconst.SIGNAL_NO_TARGET_PRESSED := 2;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              maslv_uiconst->set_masla_SIGNAL_NO_TARGET_PRESSED( 2ll );
            }

            // uiconst.SIGNAL_NO_LAP_RESET_PRESSED := 3;
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              maslv_uiconst->set_masla_SIGNAL_NO_LAP_RESET_PRESSED( 3ll );
            }

            // uiconst.SIGNAL_NO_LIGHT_PRESSED := 4;
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              maslv_uiconst->set_masla_SIGNAL_NO_LIGHT_PRESSED( 4ll );
            }

            // uiconst.SIGNAL_NO_MODE_PRESSED := 5;
            {
              ::SWA::Stack::ExecutingStatement statement(12);
              maslv_uiconst->set_masla_SIGNAL_NO_MODE_PRESSED( 5ll );
            }

            // uiconst.SOCKET_ERROR := (- 1);
            {
              ::SWA::Stack::ExecutingStatement statement(13);
              maslv_uiconst->set_masla_SOCKET_ERROR( -1ll );
            }

            // uiconst.tick_period := 100000;
            {
              ::SWA::Stack::ExecutingStatement statement(14);
              maslv_uiconst->set_masla_tick_period( 100000ll );
            }
          }
        }
      }
    }
  }

}
