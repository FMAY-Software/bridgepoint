//
// File: Sqlite__UI__UIConstantsMapper.hh
//
#ifndef Sqlite_UI_UI_Constants_Mapper_hh
#define Sqlite_UI_UI_Constants_Mapper_hh

#include "Sqlite__UI__UIConstants.hh"
#include "__UI__UIConstants.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_UIConstantsMapper
      : public ::SQL::ObjectMapper< ::masld_UI::maslo_UIConstants,maslo_UIConstants>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> createInstance ( int32_t masla_id,
                                                                                  int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                                  int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                                  int32_t masla_SOCKET_ERROR,
                                                                                  int32_t masla_tick_period );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_UIConstantsMapper ( );
        virtual ~maslo_UIConstantsMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_UIConstants::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_UI_UI_Constants_Mapper_hh
