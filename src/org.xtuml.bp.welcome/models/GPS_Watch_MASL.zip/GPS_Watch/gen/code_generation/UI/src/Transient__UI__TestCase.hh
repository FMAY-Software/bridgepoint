//
// File: Transient__UI__TestCase.hh
//
#ifndef Transient_UI_Test_Case_hh
#define Transient_UI_Test_Case_hh

#include "__UI__TestCase.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_UI
  {
    class maslo_TestCase
      : public ::masld_UI::maslo_TestCase
    {

      // Constructors and Destructors
      public:
        maslo_TestCase ( int32_t                          masla_iterations,
                         int32_t                          masla_id,
                         ::masld_UI::maslo_TestCase::Type currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_iterations ( int32_t value ) { this->masla_iterations = value; }
        virtual void setCurrentState ( ::masld_UI::maslo_TestCase::Type newState ) { currentState = newState; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_iterations ( ) const { return masla_iterations; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual ::masld_UI::maslo_TestCase::Type getCurrentState ( ) const { return currentState; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_iterations;
        int32_t masla_id;
        ::masld_UI::maslo_TestCase::Type currentState;


    };
  }
}
#endif // Transient_UI_Test_Case_hh
