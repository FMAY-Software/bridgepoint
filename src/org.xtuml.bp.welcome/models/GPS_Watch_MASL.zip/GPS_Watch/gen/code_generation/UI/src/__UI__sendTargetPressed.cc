//
// File: __UI__sendTargetPressed.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "__UI_private_services.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_sendTargetPressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_sendTargetPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // TRACK~>setTargetPressed()
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          maslb_TRACK::masls_setTargetPressed();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_sendTargetPressed = interceptor_masls_sendTargetPressed::instance().registerLocal( &masls_sendTargetPressed );

}
