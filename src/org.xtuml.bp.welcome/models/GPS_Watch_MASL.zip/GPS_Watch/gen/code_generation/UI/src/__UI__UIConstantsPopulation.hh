//
// File: __UI__UIConstantsPopulation.hh
//
#ifndef _UI_UI_Constants_Population_hh
#define _UI_UI_Constants_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  class maslo_UIConstants;
  class maslo_UIConstantsPopulation
    : public ::SWA::DynamicSingleton<maslo_UIConstantsPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_UIConstants> createInstance ( int32_t masla_id,
                                                                   int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                   int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                   int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                   int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                   int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                   int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                   int32_t masla_SOCKET_ERROR,
                                                                   int32_t masla_tick_period ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_UIConstants> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_UIConstants> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_UIConstants> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_UIConstants> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_UIConstants> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_UIConstantsPopulation ( );
      virtual ~maslo_UIConstantsPopulation ( );


    // Prevent copy
    private:
      maslo_UIConstantsPopulation ( const maslo_UIConstantsPopulation& rhs );
      maslo_UIConstantsPopulation& operator= ( const maslo_UIConstantsPopulation& rhs );


  };
}
#endif // _UI_UI_Constants_Population_hh
