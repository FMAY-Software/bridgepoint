//
// File: Transient__UI__UI.hh
//
#ifndef Transient_UI_UI_hh
#define Transient_UI_UI_hh

#include "__UI__UI.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace transient
{
  namespace masld_UI
  {
    class maslo_UI
      : public ::masld_UI::maslo_UI
    {

      // Constructors and Destructors
      public:
        maslo_UI ( int32_t                                masla_id,
                   int32_t                                masla_socket_id,
                   const ::SWA::EventTimers::TimerIdType& masla_timer,
                   ::masld_UI::maslo_UI::Type             currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_socket_id ( int32_t value ) { this->masla_socket_id = value; }
        virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) { this->masla_timer = value; }
        virtual void setCurrentState ( ::masld_UI::maslo_UI::Type newState ) { currentState = newState; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_socket_id ( ) const { return masla_socket_id; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const { return masla_timer; }
        virtual ::masld_UI::maslo_UI::Type getCurrentState ( ) const { return currentState; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_socket_id;
        ::SWA::EventTimers::TimerIdType masla_timer;
        ::masld_UI::maslo_UI::Type currentState;


    };
  }
}
#endif // Transient_UI_UI_hh
