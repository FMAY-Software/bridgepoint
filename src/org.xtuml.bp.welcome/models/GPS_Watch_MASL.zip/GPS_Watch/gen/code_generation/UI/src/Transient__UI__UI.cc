//
// File: Transient__UI__UI.cc
//
#include "Transient__UI__UI.hh"
#include "__UI__UI.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"

namespace transient
{
  namespace masld_UI
  {
    maslo_UI::maslo_UI ( int32_t                                masla_id,
                         int32_t                                masla_socket_id,
                         const ::SWA::EventTimers::TimerIdType& masla_timer,
                         ::masld_UI::maslo_UI::Type             currentState )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_socket_id(masla_socket_id),
        masla_timer(masla_timer),
        currentState(currentState)
    {
    }

  }
}
