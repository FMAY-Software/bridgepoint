//
// File: Sqlite__UI__UIConstants.hh
//
#ifndef Sqlite_UI_UI_Constants_hh
#define Sqlite_UI_UI_Constants_hh

#include "__UI__UIConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_UIConstants
      : public ::masld_UI::maslo_UIConstants
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_UIConstants ( ::SWA::IdType architectureId );
        maslo_UIConstants ( ::SWA::IdType architectureId,
                            int32_t       masla_id,
                            int32_t       masla_SIGNAL_NO_NULL_SIGNAL,
                            int32_t       masla_SIGNAL_NO_START_STOP_PRESSED,
                            int32_t       masla_SIGNAL_NO_TARGET_PRESSED,
                            int32_t       masla_SIGNAL_NO_LAP_RESET_PRESSED,
                            int32_t       masla_SIGNAL_NO_LIGHT_PRESSED,
                            int32_t       masla_SIGNAL_NO_MODE_PRESSED,
                            int32_t       masla_SOCKET_ERROR,
                            int32_t       masla_tick_period );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_SIGNAL_NO_NULL_SIGNAL ( int32_t value )
        {
          this->masla_SIGNAL_NO_NULL_SIGNAL = value;
          markAsModified();
        }
        virtual void set_masla_SIGNAL_NO_START_STOP_PRESSED ( int32_t value )
        {
          this->masla_SIGNAL_NO_START_STOP_PRESSED = value;
          markAsModified();
        }
        virtual void set_masla_SIGNAL_NO_TARGET_PRESSED ( int32_t value )
        {
          this->masla_SIGNAL_NO_TARGET_PRESSED = value;
          markAsModified();
        }
        virtual void set_masla_SIGNAL_NO_LAP_RESET_PRESSED ( int32_t value )
        {
          this->masla_SIGNAL_NO_LAP_RESET_PRESSED = value;
          markAsModified();
        }
        virtual void set_masla_SIGNAL_NO_LIGHT_PRESSED ( int32_t value )
        {
          this->masla_SIGNAL_NO_LIGHT_PRESSED = value;
          markAsModified();
        }
        virtual void set_masla_SIGNAL_NO_MODE_PRESSED ( int32_t value )
        {
          this->masla_SIGNAL_NO_MODE_PRESSED = value;
          markAsModified();
        }
        virtual void set_masla_SOCKET_ERROR ( int32_t value )
        {
          this->masla_SOCKET_ERROR = value;
          markAsModified();
        }
        virtual void set_masla_tick_period ( int32_t value )
        {
          this->masla_tick_period = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_SIGNAL_NO_NULL_SIGNAL ( ) const { return masla_SIGNAL_NO_NULL_SIGNAL; }
        virtual int32_t get_masla_SIGNAL_NO_START_STOP_PRESSED ( ) const { return masla_SIGNAL_NO_START_STOP_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_TARGET_PRESSED ( ) const { return masla_SIGNAL_NO_TARGET_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_LAP_RESET_PRESSED ( ) const { return masla_SIGNAL_NO_LAP_RESET_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_LIGHT_PRESSED ( ) const { return masla_SIGNAL_NO_LIGHT_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_MODE_PRESSED ( ) const { return masla_SIGNAL_NO_MODE_PRESSED; }
        virtual int32_t get_masla_SOCKET_ERROR ( ) const { return masla_SOCKET_ERROR; }
        virtual int32_t get_masla_tick_period ( ) const { return masla_tick_period; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_SIGNAL_NO_NULL_SIGNAL;
        int32_t masla_SIGNAL_NO_START_STOP_PRESSED;
        int32_t masla_SIGNAL_NO_TARGET_PRESSED;
        int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED;
        int32_t masla_SIGNAL_NO_LIGHT_PRESSED;
        int32_t masla_SIGNAL_NO_MODE_PRESSED;
        int32_t masla_SOCKET_ERROR;
        int32_t masla_tick_period;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_UI_UI_Constants_hh
