//
// File: MetaData__UI.cc
//
#include "UI_OOA/MetaData__UI.hh"
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "UI_OOA/__UI_types.hh"
#include "__UI__TestCase.hh"
#include "__UI__UI.hh"
#include "__UI__UIConstants.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_UI
  {
    ::SWA::EnumerateMetaData get_maslt_UIGoalCriteria_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_UIGoalSpan_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_UIIndicator_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_UIUnit_MetaData ( );
    ::SWA::ServiceMetaData get_masls_RunTestCase_MetaData ( );
    ::SWA::ServiceMetaData get_masls_createGoals_1_MetaData ( );
    ::SWA::ServiceMetaData get_masls_init_MetaData ( );
    ::SWA::ServiceMetaData get_masls_setData_MetaData ( );
    ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( );
    ::SWA::ServiceMetaData get_masls_setTime_MetaData ( );
    ::SWA::ServiceMetaData get_masls_startTest_MetaData ( );
    ::SWA::ServiceMetaData get_masls_sendLapResetPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_sendLightPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_sendModePressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_sendStartStopPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_sendTargetPressed_MetaData ( );
    namespace maslb_TRACK
    {
      ::SWA::TerminatorMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_setTargetPressed_MetaData ( );
      ::SWA::ServiceMetaData get_masls_startStopPressed_MetaData ( );
      ::SWA::ServiceMetaData get_masls_lapResetPressed_MetaData ( );
      ::SWA::ServiceMetaData get_masls_lightPressed_MetaData ( );
      ::SWA::ServiceMetaData get_masls_modePressed_MetaData ( );
      ::SWA::ServiceMetaData get_masls_newGoalSpec_MetaData ( );
    }
    namespace maslo_TestCase
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_execute_MetaData ( );
      ::SWA::StateMetaData get_maslst_pressStartStop_MetaData ( );
      ::SWA::StateMetaData get_maslst_testCaseFinished_MetaData ( );
      ::SWA::StateMetaData get_maslst_initialize_MetaData ( );
      ::SWA::StateMetaData get_maslst_Idle_MetaData ( );
      ::SWA::EventMetaData get_maslev_doDelay_MetaData ( );
      ::SWA::EventMetaData get_maslev_finish_MetaData ( );
      ::SWA::EventMetaData get_maslev_initializationComplete_MetaData ( );
      ::SWA::EventMetaData get_maslev_initialize_MetaData ( );
    }
    namespace maslo_UI
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_connect_MetaData ( );
      ::SWA::ServiceMetaData get_masls_poll_MetaData ( );
      ::SWA::ServiceMetaData get_masls_setData_MetaData ( );
      ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( );
      ::SWA::ServiceMetaData get_masls_setTime_MetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
      ::SWA::StateMetaData get_maslst_running_MetaData ( );
      ::SWA::StateMetaData get_maslst_setTargetPressed_MetaData ( );
      ::SWA::StateMetaData get_maslst_startStopPresssed_MetaData ( );
      ::SWA::StateMetaData get_maslst_lapResetPressed_MetaData ( );
      ::SWA::StateMetaData get_maslst_lightPressed_MetaData ( );
      ::SWA::StateMetaData get_maslst_modePressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_setTargetPressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_startStopPressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_lapResetPressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_lightPressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_modePressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_running_MetaData ( );
      ::SWA::EventMetaData get_maslev_tick_MetaData ( );
    }
    namespace maslo_UIConstants
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_UI::getDomain().getId(), "UI", false);
      domain.addEnumerate( get_maslt_UIGoalCriteria_MetaData() );
      domain.addEnumerate( get_maslt_UIGoalSpan_MetaData() );
      domain.addEnumerate( get_maslt_UIIndicator_MetaData() );
      domain.addEnumerate( get_maslt_UIUnit_MetaData() );
      domain.addService( get_masls_RunTestCase_MetaData() );
      domain.addService( get_masls_createGoals_1_MetaData() );
      domain.addService( get_masls_init_MetaData() );
      domain.addService( get_masls_setData_MetaData() );
      domain.addService( get_masls_setIndicator_MetaData() );
      domain.addService( get_masls_setTime_MetaData() );
      domain.addService( get_masls_startTest_MetaData() );
      domain.addService( get_masls_sendLapResetPressed_MetaData() );
      domain.addService( get_masls_sendLightPressed_MetaData() );
      domain.addService( get_masls_sendModePressed_MetaData() );
      domain.addService( get_masls_sendStartStopPressed_MetaData() );
      domain.addService( get_masls_sendTargetPressed_MetaData() );
      domain.addTerminator( maslb_TRACK::getMetaData() );
      domain.addObject( maslo_TestCase::getMetaData() );
      domain.addObject( maslo_UI::getMetaData() );
      domain.addObject( maslo_UIConstants::getMetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_UI::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_UIGoalCriteria_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIGoalCriteria, "UIGoalCriteria");
      enumeration.addValue( ::masld_UI::maslt_UIGoalCriteria::masle_HeartRate.getValue(), "HeartRate" );
      enumeration.addValue( ::masld_UI::maslt_UIGoalCriteria::masle_Pace.getValue(), "Pace" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_UIGoalSpan_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIGoalSpan, "UIGoalSpan");
      enumeration.addValue( ::masld_UI::maslt_UIGoalSpan::masle_Distance.getValue(), "Distance" );
      enumeration.addValue( ::masld_UI::maslt_UIGoalSpan::masle_Time.getValue(), "Time" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_UIIndicator_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIIndicator, "UIIndicator");
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Blank.getValue(), "Blank" );
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Down.getValue(), "Down" );
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Flat.getValue(), "Flat" );
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Up.getValue(), "Up" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_UIUnit_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIUnit, "UIUnit");
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_km.getValue(), "km" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_meters.getValue(), "meters" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_minPerKm.getValue(), "minPerKm" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_kmPerHour.getValue(), "kmPerHour" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_miles.getValue(), "miles" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_yards.getValue(), "yards" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_feet.getValue(), "feet" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_minPerMile.getValue(), "minPerMile" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_mph.getValue(), "mph" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_bpm.getValue(), "bpm" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_laps.getValue(), "laps" );
      return enumeration;
    }

    ::SWA::ServiceMetaData get_masls_RunTestCase_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_RunTestCase, ::SWA::ServiceMetaData::Domain, "RunTestCase", ::std::vector<int>( lines, lines + 2 ), "RunTestCase.svc", "9ff4cab14c850ac7abc1304a1cefe7b0");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_createGoals_1_MetaData ( )
    {
      int lines[] = { 2,
     3,
     4,
     5,
     6};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_createGoals_1, ::SWA::ServiceMetaData::Domain, "createGoals_1", ::std::vector<int>( lines, lines + 5 ), "createGoals_1.svc", "d8ccbb8e3ecb652771b389994f6760e8");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_init_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_init, ::SWA::ServiceMetaData::Domain, "init", ::std::vector<int>( lines, lines + 2 ), "init.svc", "808fbfa0ca5ca8f4da039bb71eaca6d2");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_setData_MetaData ( )
    {
      int lines[] = { 4,
     5,
     6,
     7,
     8,
     10,
     12,
     14,
     16,
     18,
     20,
     22,
     24,
     26,
     28};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_setData, ::SWA::ServiceMetaData::Domain, "setData", ::std::vector<int>( lines, lines + 15 ), "setData.svc", "b26e626be9cd21ea7a5f5ab8e9016bb5");
      service.addParameter( ::SWA::ParameterMetaData( "value", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "unit", "UI::UIUnit", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_UI::getDomain().getId(), ::masld_UI::typeId_maslt_UIUnit ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "ui", "instance of UI", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( )
    {
      int lines[] = { 3,
     5,
     6,
     7,
     8,
     10,
     12,
     14};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_setIndicator, ::SWA::ServiceMetaData::Domain, "setIndicator", ::std::vector<int>( lines, lines + 8 ), "setIndicator.svc", "14ac99cb01b4ff3f9e492485fac667da");
      service.addParameter( ::SWA::ParameterMetaData( "indicator", "UI::UIIndicator", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_UI::getDomain().getId(), ::masld_UI::typeId_maslt_UIIndicator ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "ui", "instance of UI", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_setTime_MetaData ( )
    {
      int lines[] = { 3,
     4,
     5,
     6};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_setTime, ::SWA::ServiceMetaData::Domain, "setTime", ::std::vector<int>( lines, lines + 4 ), "setTime.svc", "74fdd32735c6d528270d21cea4ee3e5f");
      service.addParameter( ::SWA::ParameterMetaData( "time", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "ui", "instance of UI", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_startTest_MetaData ( )
    {
      int lines[] = { 3,
     4,
     5};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_startTest, ::SWA::ServiceMetaData::Domain, "startTest", ::std::vector<int>( lines, lines + 3 ), "startTest.svc", "65bebe3dfecd6032668e9552ead513b5");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "tc", "instance of TestCase", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_TestCase ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_sendLapResetPressed_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_sendLapResetPressed, ::SWA::ServiceMetaData::Domain, "sendLapResetPressed", ::std::vector<int>( lines, lines + 2 ), "sendLapResetPressed.svc", "a06480476bd14914fa81eb1176ba06d1");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_sendLightPressed_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_sendLightPressed, ::SWA::ServiceMetaData::Domain, "sendLightPressed", ::std::vector<int>( lines, lines + 2 ), "sendLightPressed.svc", "e5f999f094f73219c43edaf441d4ecb1");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_sendModePressed_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_sendModePressed, ::SWA::ServiceMetaData::Domain, "sendModePressed", ::std::vector<int>( lines, lines + 2 ), "sendModePressed.svc", "0bc464af754f5f8f74d0fe27d32ab75d");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_sendStartStopPressed_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_sendStartStopPressed, ::SWA::ServiceMetaData::Domain, "sendStartStopPressed", ::std::vector<int>( lines, lines + 2 ), "sendStartStopPressed.svc", "0e600e5970aa45872cc820b543540434");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_sendTargetPressed_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_UI::serviceId_masls_sendTargetPressed, ::SWA::ServiceMetaData::Domain, "sendTargetPressed", ::std::vector<int>( lines, lines + 2 ), "sendTargetPressed.svc", "2130b099d8621d48f73368405a222a31");
      return service;
    }

    namespace maslb_TRACK
    {
      ::SWA::TerminatorMetaData getMetaData ( )
      {
        ::SWA::TerminatorMetaData terminator(::masld_UI::terminatorId_maslb_TRACK, "TRACK", "TRACK");
        terminator.addService( get_masls_setTargetPressed_MetaData() );
        terminator.addService( get_masls_startStopPressed_MetaData() );
        terminator.addService( get_masls_lapResetPressed_MetaData() );
        terminator.addService( get_masls_lightPressed_MetaData() );
        terminator.addService( get_masls_modePressed_MetaData() );
        terminator.addService( get_masls_newGoalSpec_MetaData() );
        return terminator;
      }

      ::SWA::ServiceMetaData get_masls_setTargetPressed_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_setTargetPressed, ::SWA::ServiceMetaData::Terminator, "setTargetPressed", ::std::vector<int>( lines, lines + 2 ), "TRACK_setTargetPressed.tr", "83adb499397fc61ae294816036f68f4b");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_startStopPressed_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_startStopPressed, ::SWA::ServiceMetaData::Terminator, "startStopPressed", ::std::vector<int>( lines, lines + 2 ), "TRACK_startStopPressed.tr", "eaac2b861c0b8345eab366413e4216ef");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_lapResetPressed_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_lapResetPressed, ::SWA::ServiceMetaData::Terminator, "lapResetPressed", ::std::vector<int>( lines, lines + 2 ), "TRACK_lapResetPressed.tr", "2abe1ded9e42bf6298c61e6d16ec3d6e");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_lightPressed_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_lightPressed, ::SWA::ServiceMetaData::Terminator, "lightPressed", ::std::vector<int>( lines, lines + 2 ), "TRACK_lightPressed.tr", "67986f73c40eb0f4f51274fbc4ff9f09");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_modePressed_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_modePressed, ::SWA::ServiceMetaData::Terminator, "modePressed", ::std::vector<int>( lines, lines + 2 ), "TRACK_modePressed.tr", "f9939596acaed9329a5069e3e7c72d9c");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_newGoalSpec_MetaData ( )
      {
        int lines[] = { 7,
     8};
        ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_newGoalSpec, ::SWA::ServiceMetaData::Terminator, "newGoalSpec", ::std::vector<int>( lines, lines + 2 ), "TRACK_newGoalSpec.tr", "262bc45d2a6605a2162055e525367327");
        service.addParameter( ::SWA::ParameterMetaData( "spanType", "UI::UIGoalSpan", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_UI::getDomain().getId(), ::masld_UI::typeId_maslt_UIGoalSpan ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "criteriaType", "UI::UIGoalCriteria", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_UI::getDomain().getId(), ::masld_UI::typeId_maslt_UIGoalCriteria ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "span", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "maximum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "minimum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "sequenceNumber", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return service;
      }

    }
    namespace maslo_TestCase
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_UI::objectId_maslo_TestCase, "TestCase", "TestCase");
        object.addAttribute( ::SWA::AttributeMetaData( "iterations", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_execute_MetaData() );
        object.addState( get_maslst_pressStartStop_MetaData() );
        object.addState( get_maslst_testCaseFinished_MetaData() );
        object.addState( get_maslst_initialize_MetaData() );
        object.addState( get_maslst_Idle_MetaData() );
        object.addEvent( get_maslev_doDelay_MetaData() );
        object.addEvent( get_maslev_finish_MetaData() );
        object.addEvent( get_maslev_initializationComplete_MetaData() );
        object.addEvent( get_maslev_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_execute_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_TestCase::serviceId_masls_execute, ::SWA::ServiceMetaData::Object, "execute", ::std::vector<int>( lines, lines + 3 ), "TestCase_execute.svc", "23741cc37085dc6c0f123b2ae755a1d6");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "tc", "instance of TestCase", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_TestCase ) ) );
        return service;
      }

      ::SWA::StateMetaData get_maslst_pressStartStop_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7,
     9,
     10};
        ::SWA::StateMetaData state(::masld_UI::maslo_TestCase::stateId_maslst_pressStartStop, ::SWA::StateMetaData::Normal, "pressStartStop", ::std::vector<int>( lines, lines + 7 ), "TestCase_pressStartStop.al", "34e19bc49fda91081e5ef7fdca651ec3");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "handle", "timer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timer ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_testCaseFinished_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::StateMetaData state(::masld_UI::maslo_TestCase::stateId_maslst_testCaseFinished, ::SWA::StateMetaData::Terminal, "testCaseFinished", ::std::vector<int>( lines, lines + 2 ), "TestCase_testCaseFinished.al", "6bf36daaaa5437284dd6b92d070e4215");
        return state;
      }

      ::SWA::StateMetaData get_maslst_initialize_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4,
     5};
        ::SWA::StateMetaData state(::masld_UI::maslo_TestCase::stateId_maslst_initialize, ::SWA::StateMetaData::Normal, "initialize", ::std::vector<int>( lines, lines + 4 ), "TestCase_initialize.al", "93abd9d1a4b9abf115860b104d0786fb");
        state.addParameter( ::SWA::ParameterMetaData( "iterations", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_Idle_MetaData ( )
      {
        int lines[] = { 2};
        ::SWA::StateMetaData state(::masld_UI::maslo_TestCase::stateId_maslst_Idle, ::SWA::StateMetaData::Normal, "Idle", ::std::vector<int>( lines, lines + 1 ), "TestCase_Idle.al", "d43abbba0ae2f04051b93d814cfbe42f");
        return state;
      }

      ::SWA::EventMetaData get_maslev_doDelay_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_doDelay, ::masld_UI::objectId_maslo_TestCase, ::SWA::EventMetaData::Normal, "doDelay");
        return event;
      }

      ::SWA::EventMetaData get_maslev_finish_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_finish, ::masld_UI::objectId_maslo_TestCase, ::SWA::EventMetaData::Normal, "finish");
        return event;
      }

      ::SWA::EventMetaData get_maslev_initializationComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_initializationComplete, ::masld_UI::objectId_maslo_TestCase, ::SWA::EventMetaData::Normal, "initializationComplete");
        return event;
      }

      ::SWA::EventMetaData get_maslev_initialize_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_initialize, ::masld_UI::objectId_maslo_TestCase, ::SWA::EventMetaData::Normal, "initialize");
        event.addParameter( ::SWA::ParameterMetaData( "iterations", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return event;
      }

    }
    namespace maslo_UI
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_UI::objectId_maslo_UI, "UI", "UI");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "socket_id", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "timer", false, "timer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timer ) ) );
        object.addService( get_masls_connect_MetaData() );
        object.addService( get_masls_poll_MetaData() );
        object.addService( get_masls_setData_MetaData() );
        object.addService( get_masls_setIndicator_MetaData() );
        object.addService( get_masls_setTime_MetaData() );
        object.addService( get_masls_initialize_MetaData() );
        object.addState( get_maslst_running_MetaData() );
        object.addState( get_maslst_setTargetPressed_MetaData() );
        object.addState( get_maslst_startStopPresssed_MetaData() );
        object.addState( get_maslst_lapResetPressed_MetaData() );
        object.addState( get_maslst_lightPressed_MetaData() );
        object.addState( get_maslst_modePressed_MetaData() );
        object.addEvent( get_maslev_setTargetPressed_MetaData() );
        object.addEvent( get_maslev_startStopPressed_MetaData() );
        object.addEvent( get_maslev_lapResetPressed_MetaData() );
        object.addEvent( get_maslev_lightPressed_MetaData() );
        object.addEvent( get_maslev_modePressed_MetaData() );
        object.addEvent( get_maslev_running_MetaData() );
        object.addEvent( get_maslev_tick_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_connect_MetaData ( )
      {
        int lines[] = {};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UI::serviceId_masls_connect, ::SWA::ServiceMetaData::Object, "connect", ::std::vector<int>( lines, lines + 0 ), "UI_connect.svc", "");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_poll_MetaData ( )
      {
        int lines[] = {};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UI::serviceId_masls_poll, ::SWA::ServiceMetaData::Instance, "poll", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), ::std::vector<int>( lines, lines + 0 ), "UI_poll.svc", "");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_setData_MetaData ( )
      {
        int lines[] = {};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UI::serviceId_masls_setData, ::SWA::ServiceMetaData::Instance, "setData", ::std::vector<int>( lines, lines + 0 ), "UI_setData.svc", "");
        service.addParameter( ::SWA::ParameterMetaData( "value", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "unit", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( )
      {
        int lines[] = {};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UI::serviceId_masls_setIndicator, ::SWA::ServiceMetaData::Instance, "setIndicator", ::std::vector<int>( lines, lines + 0 ), "UI_setIndicator.svc", "");
        service.addParameter( ::SWA::ParameterMetaData( "value", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_setTime_MetaData ( )
      {
        int lines[] = {};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UI::serviceId_masls_setTime, ::SWA::ServiceMetaData::Instance, "setTime", ::std::vector<int>( lines, lines + 0 ), "UI_setTime.svc", "");
        service.addParameter( ::SWA::ParameterMetaData( "time", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 4,
     6,
     7,
     8,
     9,
     10,
     11};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UI::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 7 ), "UI_initialize.svc", "d591c433d469c207769297abcbe377be");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "ui", "instance of UI", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "uiconst", "instance of UIConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UIConstants ) ) );
        return service;
      }

      ::SWA::StateMetaData get_maslst_running_MetaData ( )
      {
        int lines[] = { 5,
     6,
     7,
     8,
     9,
     10,
     11,
     13,
     15,
     17,
     19,
     21};
        ::SWA::StateMetaData state(::masld_UI::maslo_UI::stateId_maslst_running, ::SWA::StateMetaData::Normal, "running", ::std::vector<int>( lines, lines + 12 ), "UI_running.al", "2d801a3b28794ea62f2f996d5692f3cc");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "uiconst", "instance of UIConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UIConstants ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "ui", "instance of UI", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "signal_no", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_setTargetPressed_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4};
        ::SWA::StateMetaData state(::masld_UI::maslo_UI::stateId_maslst_setTargetPressed, ::SWA::StateMetaData::Normal, "setTargetPressed", ::std::vector<int>( lines, lines + 3 ), "UI_setTargetPressed.al", "f8b91a7eec7fd5d7109f920c90f751d5");
        return state;
      }

      ::SWA::StateMetaData get_maslst_startStopPresssed_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4};
        ::SWA::StateMetaData state(::masld_UI::maslo_UI::stateId_maslst_startStopPresssed, ::SWA::StateMetaData::Normal, "startStopPresssed", ::std::vector<int>( lines, lines + 3 ), "UI_startStopPresssed.al", "2480882f8b2f4cb4c3c21a064d0938c2");
        return state;
      }

      ::SWA::StateMetaData get_maslst_lapResetPressed_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4};
        ::SWA::StateMetaData state(::masld_UI::maslo_UI::stateId_maslst_lapResetPressed, ::SWA::StateMetaData::Normal, "lapResetPressed", ::std::vector<int>( lines, lines + 3 ), "UI_lapResetPressed.al", "8251ec22cb3d6bb54b084ecc3fea82dc");
        return state;
      }

      ::SWA::StateMetaData get_maslst_lightPressed_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4};
        ::SWA::StateMetaData state(::masld_UI::maslo_UI::stateId_maslst_lightPressed, ::SWA::StateMetaData::Normal, "lightPressed", ::std::vector<int>( lines, lines + 3 ), "UI_lightPressed.al", "c38c9d3b027d9b04430826760c9126cc");
        return state;
      }

      ::SWA::StateMetaData get_maslst_modePressed_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4};
        ::SWA::StateMetaData state(::masld_UI::maslo_UI::stateId_maslst_modePressed, ::SWA::StateMetaData::Normal, "modePressed", ::std::vector<int>( lines, lines + 3 ), "UI_modePressed.al", "6a884c47a02dbce6e797800c054d7346");
        return state;
      }

      ::SWA::EventMetaData get_maslev_setTargetPressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_setTargetPressed, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "setTargetPressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_startStopPressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_startStopPressed, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "startStopPressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_lapResetPressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_lapResetPressed, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "lapResetPressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_lightPressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_lightPressed, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "lightPressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_modePressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_modePressed, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "modePressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_running_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_running, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "running");
        return event;
      }

      ::SWA::EventMetaData get_maslev_tick_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_UI::maslo_UI::eventId_maslo_UI_maslev_tick, ::masld_UI::objectId_maslo_UI, ::SWA::EventMetaData::Normal, "tick");
        return event;
      }

    }
    namespace maslo_UIConstants
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_UI::objectId_maslo_UIConstants, "UIConstants", "UIConstants");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SIGNAL_NO_NULL_SIGNAL", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SIGNAL_NO_START_STOP_PRESSED", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SIGNAL_NO_TARGET_PRESSED", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SIGNAL_NO_LAP_RESET_PRESSED", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SIGNAL_NO_LIGHT_PRESSED", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SIGNAL_NO_MODE_PRESSED", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SOCKET_ERROR", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "tick_period", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7,
     8,
     9,
     10,
     11,
     12,
     13,
     14};
        ::SWA::ServiceMetaData service(::masld_UI::maslo_UIConstants::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 12 ), "UIConstants_initialize.svc", "9d83567709ec791c1da9801fb4ac235b");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "uiconst", "instance of UIConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UIConstants ) ) );
        return service;
      }

    }
  }
}
