/*
 * Core types with byte widths defined for MISRA-C compliance.
 */
typedef          int     i_t;
typedef          double  r_t;
