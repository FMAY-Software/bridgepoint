//
// File: Transient__UI__UIConstantsPopulation.cc
//
#include "Transient__UI__UIConstants.hh"
#include "Transient__UI__UIConstantsPopulation.hh"
#include "__UI__UIConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_UI
  {
    maslo_UIConstantsPopulation::maslo_UIConstantsPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> maslo_UIConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                   int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                                                   int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                                                   int32_t masla_SOCKET_ERROR,
                                                                                                   int32_t masla_tick_period )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance(new maslo_UIConstants(  masla_id,
                        masla_SIGNAL_NO_NULL_SIGNAL,
                        masla_SIGNAL_NO_START_STOP_PRESSED,
                        masla_SIGNAL_NO_TARGET_PRESSED,
                        masla_SIGNAL_NO_LAP_RESET_PRESSED,
                        masla_SIGNAL_NO_LIGHT_PRESSED,
                        masla_SIGNAL_NO_MODE_PRESSED,
                        masla_SOCKET_ERROR,
                        masla_tick_period ));
      addInstance( instance );
      return instance;
    }

    void maslo_UIConstantsPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_UIConstantsPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_UIConstantsPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_UIConstantsPopulation& maslo_UIConstantsPopulation::getPopulation ( )
    {
      static maslo_UIConstantsPopulation population;
      return population;
    }

    bool maslo_UIConstantsPopulation::registered = maslo_UIConstantsPopulation::registerSingleton( &maslo_UIConstantsPopulation::getPopulation );

  }
}
