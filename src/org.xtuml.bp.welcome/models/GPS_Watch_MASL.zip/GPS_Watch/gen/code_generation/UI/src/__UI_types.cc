//
// File: __UI_types.cc
//
#include "UI_OOA/__UI_types.hh"
#include <iostream>
#include <stdint.h>
#include <string>
#include "swa/ProgramError.hh"

namespace masld_UI
{
  maslt_UIGoalCriteria::maslt_UIGoalCriteria ( )
    : index(index_masle_HeartRate)
  {
  }

  maslt_UIGoalCriteria::maslt_UIGoalCriteria ( Index index )
    : index(index)
  {
  }

  const maslt_UIGoalCriteria maslt_UIGoalCriteria::masle_HeartRate = maslt_UIGoalCriteria( maslt_UIGoalCriteria::index_masle_HeartRate );

  const maslt_UIGoalCriteria maslt_UIGoalCriteria::masle_Pace = maslt_UIGoalCriteria( maslt_UIGoalCriteria::index_masle_Pace );

  maslt_UIGoalCriteria::maslt_UIGoalCriteria ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_UIGoalCriteria::textLookup[] = { "HeartRate",
     "Pace"};

  maslt_UIGoalCriteria::TextLookupTable maslt_UIGoalCriteria::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_HeartRate], index_masle_HeartRate ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Pace], index_masle_Pace ) );
    return lookup;
  }

  maslt_UIGoalCriteria::Index maslt_UIGoalCriteria::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_UIGoalCriteria::maslt_UIGoalCriteria ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_UIGoalCriteria::Value maslt_UIGoalCriteria::valueLookup[] = { maslt_UIGoalCriteria::value_masle_HeartRate,
     maslt_UIGoalCriteria::value_masle_Pace};

  maslt_UIGoalCriteria::Index maslt_UIGoalCriteria::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_HeartRate: return index_masle_HeartRate;
      case value_masle_Pace:      return index_masle_Pace;
      default:                    throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_UIGoalCriteria::maslt_UIGoalCriteria ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_UIGoalCriteria& maslt_UIGoalCriteria::operator++ ( )
  {
    if ( index == index_masle_Pace ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_UIGoalCriteria& maslt_UIGoalCriteria::operator-- ( )
  {
    if ( index == index_masle_HeartRate ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&             stream,
                               const maslt_UIGoalCriteria& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&       stream,
                               maslt_UIGoalCriteria& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_UIGoalCriteria( text );
    return stream;
  }

  maslt_UIGoalSpan::maslt_UIGoalSpan ( )
    : index(index_masle_Distance)
  {
  }

  maslt_UIGoalSpan::maslt_UIGoalSpan ( Index index )
    : index(index)
  {
  }

  const maslt_UIGoalSpan maslt_UIGoalSpan::masle_Distance = maslt_UIGoalSpan( maslt_UIGoalSpan::index_masle_Distance );

  const maslt_UIGoalSpan maslt_UIGoalSpan::masle_Time = maslt_UIGoalSpan( maslt_UIGoalSpan::index_masle_Time );

  maslt_UIGoalSpan::maslt_UIGoalSpan ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_UIGoalSpan::textLookup[] = { "Distance",
     "Time"};

  maslt_UIGoalSpan::TextLookupTable maslt_UIGoalSpan::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Distance], index_masle_Distance ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Time], index_masle_Time ) );
    return lookup;
  }

  maslt_UIGoalSpan::Index maslt_UIGoalSpan::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_UIGoalSpan::maslt_UIGoalSpan ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_UIGoalSpan::Value maslt_UIGoalSpan::valueLookup[] = { maslt_UIGoalSpan::value_masle_Distance,
     maslt_UIGoalSpan::value_masle_Time};

  maslt_UIGoalSpan::Index maslt_UIGoalSpan::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_Distance: return index_masle_Distance;
      case value_masle_Time:     return index_masle_Time;
      default:                   throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_UIGoalSpan::maslt_UIGoalSpan ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_UIGoalSpan& maslt_UIGoalSpan::operator++ ( )
  {
    if ( index == index_masle_Time ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_UIGoalSpan& maslt_UIGoalSpan::operator-- ( )
  {
    if ( index == index_masle_Distance ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&         stream,
                               const maslt_UIGoalSpan& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&   stream,
                               maslt_UIGoalSpan& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_UIGoalSpan( text );
    return stream;
  }

  maslt_UIIndicator::maslt_UIIndicator ( )
    : index(index_masle_Blank)
  {
  }

  maslt_UIIndicator::maslt_UIIndicator ( Index index )
    : index(index)
  {
  }

  const maslt_UIIndicator maslt_UIIndicator::masle_Blank = maslt_UIIndicator( maslt_UIIndicator::index_masle_Blank );

  const maslt_UIIndicator maslt_UIIndicator::masle_Down = maslt_UIIndicator( maslt_UIIndicator::index_masle_Down );

  const maslt_UIIndicator maslt_UIIndicator::masle_Flat = maslt_UIIndicator( maslt_UIIndicator::index_masle_Flat );

  const maslt_UIIndicator maslt_UIIndicator::masle_Up = maslt_UIIndicator( maslt_UIIndicator::index_masle_Up );

  maslt_UIIndicator::maslt_UIIndicator ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_UIIndicator::textLookup[] = { "Blank",
     "Down",
     "Flat",
     "Up"};

  maslt_UIIndicator::TextLookupTable maslt_UIIndicator::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Blank], index_masle_Blank ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Down], index_masle_Down ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Flat], index_masle_Flat ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Up], index_masle_Up ) );
    return lookup;
  }

  maslt_UIIndicator::Index maslt_UIIndicator::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_UIIndicator::maslt_UIIndicator ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_UIIndicator::Value maslt_UIIndicator::valueLookup[] = { maslt_UIIndicator::value_masle_Blank,
     maslt_UIIndicator::value_masle_Down,
     maslt_UIIndicator::value_masle_Flat,
     maslt_UIIndicator::value_masle_Up};

  maslt_UIIndicator::Index maslt_UIIndicator::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_Blank: return index_masle_Blank;
      case value_masle_Down:  return index_masle_Down;
      case value_masle_Flat:  return index_masle_Flat;
      case value_masle_Up:    return index_masle_Up;
      default:                throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_UIIndicator::maslt_UIIndicator ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_UIIndicator& maslt_UIIndicator::operator++ ( )
  {
    if ( index == index_masle_Up ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_UIIndicator& maslt_UIIndicator::operator-- ( )
  {
    if ( index == index_masle_Blank ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&          stream,
                               const maslt_UIIndicator& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&    stream,
                               maslt_UIIndicator& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_UIIndicator( text );
    return stream;
  }

  maslt_UIUnit::maslt_UIUnit ( )
    : index(index_masle_km)
  {
  }

  maslt_UIUnit::maslt_UIUnit ( Index index )
    : index(index)
  {
  }

  const maslt_UIUnit maslt_UIUnit::masle_km = maslt_UIUnit( maslt_UIUnit::index_masle_km );

  const maslt_UIUnit maslt_UIUnit::masle_meters = maslt_UIUnit( maslt_UIUnit::index_masle_meters );

  const maslt_UIUnit maslt_UIUnit::masle_minPerKm = maslt_UIUnit( maslt_UIUnit::index_masle_minPerKm );

  const maslt_UIUnit maslt_UIUnit::masle_kmPerHour = maslt_UIUnit( maslt_UIUnit::index_masle_kmPerHour );

  const maslt_UIUnit maslt_UIUnit::masle_miles = maslt_UIUnit( maslt_UIUnit::index_masle_miles );

  const maslt_UIUnit maslt_UIUnit::masle_yards = maslt_UIUnit( maslt_UIUnit::index_masle_yards );

  const maslt_UIUnit maslt_UIUnit::masle_feet = maslt_UIUnit( maslt_UIUnit::index_masle_feet );

  const maslt_UIUnit maslt_UIUnit::masle_minPerMile = maslt_UIUnit( maslt_UIUnit::index_masle_minPerMile );

  const maslt_UIUnit maslt_UIUnit::masle_mph = maslt_UIUnit( maslt_UIUnit::index_masle_mph );

  const maslt_UIUnit maslt_UIUnit::masle_bpm = maslt_UIUnit( maslt_UIUnit::index_masle_bpm );

  const maslt_UIUnit maslt_UIUnit::masle_laps = maslt_UIUnit( maslt_UIUnit::index_masle_laps );

  maslt_UIUnit::maslt_UIUnit ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_UIUnit::textLookup[] = { "km",
     "meters",
     "minPerKm",
     "kmPerHour",
     "miles",
     "yards",
     "feet",
     "minPerMile",
     "mph",
     "bpm",
     "laps"};

  maslt_UIUnit::TextLookupTable maslt_UIUnit::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_km], index_masle_km ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_meters], index_masle_meters ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_minPerKm], index_masle_minPerKm ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_kmPerHour], index_masle_kmPerHour ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_miles], index_masle_miles ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_yards], index_masle_yards ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_feet], index_masle_feet ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_minPerMile], index_masle_minPerMile ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_mph], index_masle_mph ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_bpm], index_masle_bpm ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_laps], index_masle_laps ) );
    return lookup;
  }

  maslt_UIUnit::Index maslt_UIUnit::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_UIUnit::maslt_UIUnit ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_UIUnit::Value maslt_UIUnit::valueLookup[] = { maslt_UIUnit::value_masle_km,
     maslt_UIUnit::value_masle_meters,
     maslt_UIUnit::value_masle_minPerKm,
     maslt_UIUnit::value_masle_kmPerHour,
     maslt_UIUnit::value_masle_miles,
     maslt_UIUnit::value_masle_yards,
     maslt_UIUnit::value_masle_feet,
     maslt_UIUnit::value_masle_minPerMile,
     maslt_UIUnit::value_masle_mph,
     maslt_UIUnit::value_masle_bpm,
     maslt_UIUnit::value_masle_laps};

  maslt_UIUnit::Index maslt_UIUnit::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_km:         return index_masle_km;
      case value_masle_meters:     return index_masle_meters;
      case value_masle_minPerKm:   return index_masle_minPerKm;
      case value_masle_kmPerHour:  return index_masle_kmPerHour;
      case value_masle_miles:      return index_masle_miles;
      case value_masle_yards:      return index_masle_yards;
      case value_masle_feet:       return index_masle_feet;
      case value_masle_minPerMile: return index_masle_minPerMile;
      case value_masle_mph:        return index_masle_mph;
      case value_masle_bpm:        return index_masle_bpm;
      case value_masle_laps:       return index_masle_laps;
      default:                     throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_UIUnit::maslt_UIUnit ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_UIUnit& maslt_UIUnit::operator++ ( )
  {
    if ( index == index_masle_laps ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_UIUnit& maslt_UIUnit::operator-- ( )
  {
    if ( index == index_masle_km ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&     stream,
                               const maslt_UIUnit& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_UIUnit&   obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_UIUnit( text );
    return stream;
  }

}
