//
// File: Transient__UI__UIConstantsPopulation.hh
//
#ifndef Transient_UI_UI_Constants_Population_hh
#define Transient_UI_UI_Constants_Population_hh

#include "__UI__UIConstants.hh"
#include "__UI__UIConstantsPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_UI
  {
    class maslo_UIConstantsPopulation
      : public TransientPopulation< ::masld_UI::maslo_UIConstants,::masld_UI::maslo_UIConstantsPopulation>
    {

      // Instance Creation
      private:
        maslo_UIConstantsPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> createInstance ( int32_t masla_id,
                                                                                  int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                                  int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                                  int32_t masla_SOCKET_ERROR,
                                                                                  int32_t masla_tick_period );


      // Singleton Registration
      public:
        static maslo_UIConstantsPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_UI_UI_Constants_Population_hh
