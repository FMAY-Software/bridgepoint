//
// File: Sqlite__UI__UIConstantsMapper.cc
//
#include "Sqlite__UI__UIConstants.hh"
#include "Sqlite__UI__UIConstantsMapper.hh"
#include "Sqlite__UI__UIConstantsMapperSql.hh"
#include "__UI__UIConstants.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UIConstantsMapper::maslo_UIConstantsMapper ( )
      : ::SQL::ObjectMapper< ::masld_UI::maslo_UIConstants,maslo_UIConstants>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_UI::maslo_UIConstants,maslo_UIConstants> >( new maslo_UIConstantsSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_UIConstantsMapper::~maslo_UIConstantsMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> maslo_UIConstantsMapper::createInstance ( int32_t masla_id,
                                                                                               int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                                               int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                                               int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                                               int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                                               int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                                               int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                                               int32_t masla_SOCKET_ERROR,
                                                                                               int32_t masla_tick_period )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_UIConstants::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_UIConstants> instance(new maslo_UIConstants(  uniqueId,
                        masla_id,
                        masla_SIGNAL_NO_NULL_SIGNAL,
                        masla_SIGNAL_NO_START_STOP_PRESSED,
                        masla_SIGNAL_NO_TARGET_PRESSED,
                        masla_SIGNAL_NO_LAP_RESET_PRESSED,
                        masla_SIGNAL_NO_LIGHT_PRESSED,
                        masla_SIGNAL_NO_MODE_PRESSED,
                        masla_SOCKET_ERROR,
                        masla_tick_period ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_UIConstantsMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance )
    {
      ::SQL::ObjectMapper< ::masld_UI::maslo_UIConstants,maslo_UIConstants>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_UIConstants>()->getPrimaryKey() );
    }

    bool maslo_UIConstantsMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
