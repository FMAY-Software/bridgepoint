//
// File: Sqlite__UI__UIConstants.cc
//
#include "Sqlite__UI__UIConstants.hh"
#include "Sqlite__UI__UIConstantsPopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UIConstants::maslo_UIConstants ( ::SWA::IdType architectureId,
                                           int32_t       masla_id,
                                           int32_t       masla_SIGNAL_NO_NULL_SIGNAL,
                                           int32_t       masla_SIGNAL_NO_START_STOP_PRESSED,
                                           int32_t       masla_SIGNAL_NO_TARGET_PRESSED,
                                           int32_t       masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                           int32_t       masla_SIGNAL_NO_LIGHT_PRESSED,
                                           int32_t       masla_SIGNAL_NO_MODE_PRESSED,
                                           int32_t       masla_SOCKET_ERROR,
                                           int32_t       masla_tick_period )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_SIGNAL_NO_NULL_SIGNAL(masla_SIGNAL_NO_NULL_SIGNAL),
        masla_SIGNAL_NO_START_STOP_PRESSED(masla_SIGNAL_NO_START_STOP_PRESSED),
        masla_SIGNAL_NO_TARGET_PRESSED(masla_SIGNAL_NO_TARGET_PRESSED),
        masla_SIGNAL_NO_LAP_RESET_PRESSED(masla_SIGNAL_NO_LAP_RESET_PRESSED),
        masla_SIGNAL_NO_LIGHT_PRESSED(masla_SIGNAL_NO_LIGHT_PRESSED),
        masla_SIGNAL_NO_MODE_PRESSED(masla_SIGNAL_NO_MODE_PRESSED),
        masla_SOCKET_ERROR(masla_SOCKET_ERROR),
        masla_tick_period(masla_tick_period),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_UIConstants::maslo_UIConstants ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_SIGNAL_NO_NULL_SIGNAL(),
        masla_SIGNAL_NO_START_STOP_PRESSED(),
        masla_SIGNAL_NO_TARGET_PRESSED(),
        masla_SIGNAL_NO_LAP_RESET_PRESSED(),
        masla_SIGNAL_NO_LIGHT_PRESSED(),
        masla_SIGNAL_NO_MODE_PRESSED(),
        masla_SOCKET_ERROR(),
        masla_tick_period(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_UIConstants::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_UIConstants::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_UIConstantsPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_UIConstants::PrimaryKeyType maslo_UIConstants::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_UIConstants::IndexKeyType_1 maslo_UIConstants::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
