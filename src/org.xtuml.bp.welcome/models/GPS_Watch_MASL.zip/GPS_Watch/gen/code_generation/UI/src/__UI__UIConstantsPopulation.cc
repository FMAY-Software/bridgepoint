//
// File: __UI__UIConstantsPopulation.cc
//
#include "__UI__UIConstantsPopulation.hh"

namespace masld_UI
{
  maslo_UIConstantsPopulation::maslo_UIConstantsPopulation ( )
  {
  }

  maslo_UIConstantsPopulation::~maslo_UIConstantsPopulation ( )
  {
  }

}
