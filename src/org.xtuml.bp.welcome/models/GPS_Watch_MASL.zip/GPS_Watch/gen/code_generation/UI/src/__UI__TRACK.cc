//
// File: __UI__TRACK.cc
//
#include "UI_OOA/__UI_terminators.hh"
#include "UI_OOA/__UI_types.hh"
#include <stdint.h>

namespace masld_UI
{
  maslb_TRACK& maslb_TRACK::getInstance ( )
  {
    static maslb_TRACK instance;
    return instance;
  }

  maslb_TRACK::maslb_TRACK ( )
    : override_masls_setTargetPressed(&domain_masls_setTargetPressed),
      override_masls_startStopPressed(&domain_masls_startStopPressed),
      override_masls_lapResetPressed(&domain_masls_lapResetPressed),
      override_masls_lightPressed(&domain_masls_lightPressed),
      override_masls_modePressed(&domain_masls_modePressed),
      override_masls_newGoalSpec(&domain_masls_newGoalSpec)
  {
  }

}
