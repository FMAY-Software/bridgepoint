//
// File: __UI__UI.hh
//
#ifndef _UI_UI_hh
#define _UI_UI_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  class maslo_UI;
  class maslo_UI
  {

    public:
      enum Type {  maslst_running,
                   maslst_setTargetPressed,
                   maslst_startStopPresssed,
                   maslst_lapResetPressed,
                   maslst_lightPressed,
                   maslst_modePressed };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_UI> createInstance ( int32_t                                masla_id,
                                                         int32_t                                masla_socket_id,
                                                         const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                         Type                                   currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_UI> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_socket_id ( int32_t value ) = 0;
      virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual int32_t get_masla_socket_id ( ) const = 0;
      virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const = 0;


    // Object Services
    public:
      static void masls_connect ( );
      static void masls_initialize ( );


    // Instance Services
    public:
      int32_t masls_poll ( );
      void masls_setData ( double  maslp_value,
                           int32_t maslp_unit );
      void masls_setIndicator ( int32_t maslp_value );
      void masls_setTime ( int32_t maslp_time );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_UI> > findAll ( );
      static ::SWA::ObjectPtr<maslo_UI> findOne ( );
      static ::SWA::ObjectPtr<maslo_UI> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_UI ( );
      virtual ~maslo_UI ( );


    // Prevent copy
    private:
      maslo_UI ( const maslo_UI& rhs );
      maslo_UI& operator= ( const maslo_UI& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_running ( );
      void state_maslst_setTargetPressed ( );
      void state_maslst_startStopPresssed ( );
      void state_maslst_lapResetPressed ( );
      void state_maslst_lightPressed ( );
      void state_maslst_modePressed ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_setTargetPressed ( int           sourceObj = -1,
                                                                                   ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_startStopPressed ( int           sourceObj = -1,
                                                                                   ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_lapResetPressed ( int           sourceObj = -1,
                                                                                  ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_lightPressed ( int           sourceObj = -1,
                                                                               ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_modePressed ( int           sourceObj = -1,
                                                                              ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_running ( int           sourceObj = -1,
                                                                          ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_UI_maslev_tick ( int           sourceObj = -1,
                                                                       ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_UI_maslev_setTargetPressed ( ::SWA::IdType id );
      static void consume_maslo_UI_maslev_startStopPressed ( ::SWA::IdType id );
      static void consume_maslo_UI_maslev_lapResetPressed ( ::SWA::IdType id );
      static void consume_maslo_UI_maslev_lightPressed ( ::SWA::IdType id );
      static void consume_maslo_UI_maslev_modePressed ( ::SWA::IdType id );
      static void consume_maslo_UI_maslev_running ( ::SWA::IdType id );
      static void consume_maslo_UI_maslev_tick ( ::SWA::IdType id );


    // Process Events
    public:
      void process_maslo_UI_maslev_setTargetPressed ( );
      void process_maslo_UI_maslev_startStopPressed ( );
      void process_maslo_UI_maslev_lapResetPressed ( );
      void process_maslo_UI_maslev_lightPressed ( );
      void process_maslo_UI_maslev_modePressed ( );
      void process_maslo_UI_maslev_running ( );
      void process_maslo_UI_maslev_tick ( );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_running,
                       stateId_maslst_setTargetPressed,
                       stateId_maslst_startStopPresssed,
                       stateId_maslst_lapResetPressed,
                       stateId_maslst_lightPressed,
                       stateId_maslst_modePressed };
      enum EventIds {  eventId_maslo_UI_maslev_setTargetPressed,
                       eventId_maslo_UI_maslev_startStopPressed,
                       eventId_maslo_UI_maslev_lapResetPressed,
                       eventId_maslo_UI_maslev_lightPressed,
                       eventId_maslo_UI_maslev_modePressed,
                       eventId_maslo_UI_maslev_running,
                       eventId_maslo_UI_maslev_tick };
      enum ServiceIds {  serviceId_masls_connect,
                         serviceId_masls_poll,
                         serviceId_masls_setData,
                         serviceId_masls_setIndicator,
                         serviceId_masls_setTime,
                         serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream& stream,
                               const maslo_UI& obj );
}
#endif // _UI_UI_hh
