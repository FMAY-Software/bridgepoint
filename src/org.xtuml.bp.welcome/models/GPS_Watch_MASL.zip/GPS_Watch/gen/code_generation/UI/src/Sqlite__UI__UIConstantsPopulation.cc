//
// File: Sqlite__UI__UIConstantsPopulation.cc
//
#include "Sqlite__UI__UIConstantsPopulation.hh"
#include "__UI__UIConstants.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UIConstantsPopulation::maslo_UIConstantsPopulation ( )
    {
    }

    maslo_UIConstantsPopulation::~maslo_UIConstantsPopulation ( )
    {
    }

    void maslo_UIConstantsPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_UIConstantsPopulation& maslo_UIConstantsPopulation::getPopulation ( )
    {
      static maslo_UIConstantsPopulation population;
      return population;
    }

    bool maslo_UIConstantsPopulation::registered = maslo_UIConstantsPopulation::registerSingleton( &maslo_UIConstantsPopulation::getPopulation );

    ::boost::signals2::connection maslo_UIConstantsPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_UIConstantsPopulation::initialise, ::boost::bind( &maslo_UIConstantsPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> maslo_UIConstantsPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> > maslo_UIConstantsPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> maslo_UIConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                   int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                                                   int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                                                   int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                                                   int32_t masla_SOCKET_ERROR,
                                                                                                   int32_t masla_tick_period )
    {
      return mapper->createInstance( masla_id, masla_SIGNAL_NO_NULL_SIGNAL, masla_SIGNAL_NO_START_STOP_PRESSED, masla_SIGNAL_NO_TARGET_PRESSED, masla_SIGNAL_NO_LAP_RESET_PRESSED, masla_SIGNAL_NO_LIGHT_PRESSED, masla_SIGNAL_NO_MODE_PRESSED, masla_SOCKET_ERROR, masla_tick_period );
    }

    void maslo_UIConstantsPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
