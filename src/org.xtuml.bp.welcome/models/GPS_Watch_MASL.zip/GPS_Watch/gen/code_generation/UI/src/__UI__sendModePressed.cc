//
// File: __UI__sendModePressed.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "__UI_private_services.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_sendModePressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_sendModePressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // TRACK~>modePressed()
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          maslb_TRACK::masls_modePressed();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_sendModePressed = interceptor_masls_sendModePressed::instance().registerLocal( &masls_sendModePressed );

}
