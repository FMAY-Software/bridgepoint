//
// File: __UI.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "__UI_private_services.hh"
#include "boost/bind.hpp"
#include "boost/ref.hpp"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_UI
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    ::SWA::Process::getInstance().registerInitialisedListener( ::boost::bind( &::SWA::Process::runService, ::boost::ref( ::SWA::Process::getInstance() ), &masls_init, "" ) );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
