//
// File: Inspector__UI__UIConstants.cc
//
#include "Inspector__UI__UIConstants.hh"
#include "__UI__UIConstants.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslo_UIConstants
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslo_UIConstants::masls_initialize(); }


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write uiconst
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> >();
              break;

          }

        }
      }

      maslo_UIConstantsHandler::maslo_UIConstantsHandler ( )
      {
        registerServiceHandler( ::masld_UI::maslo_UIConstants::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_UI::maslo_UIConstants> ( const ::masld_UI::maslo_UIConstants& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_id() );
    write( instance.get_masla_SIGNAL_NO_NULL_SIGNAL() );
    write( instance.get_masla_SIGNAL_NO_START_STOP_PRESSED() );
    write( instance.get_masla_SIGNAL_NO_TARGET_PRESSED() );
    write( instance.get_masla_SIGNAL_NO_LAP_RESET_PRESSED() );
    write( instance.get_masla_SIGNAL_NO_LIGHT_PRESSED() );
    write( instance.get_masla_SIGNAL_NO_MODE_PRESSED() );
    write( instance.get_masla_SOCKET_ERROR() );
    write( instance.get_masla_tick_period() );
  }

  namespace masld_UI
  {
    namespace maslo_UIConstants
    {
      void maslo_UIConstantsHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_id;
        int32_t masla_SIGNAL_NO_NULL_SIGNAL;
        int32_t masla_SIGNAL_NO_START_STOP_PRESSED;
        int32_t masla_SIGNAL_NO_TARGET_PRESSED;
        int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED;
        int32_t masla_SIGNAL_NO_LIGHT_PRESSED;
        int32_t masla_SIGNAL_NO_MODE_PRESSED;
        int32_t masla_SOCKET_ERROR;
        int32_t masla_tick_period;
        channel >> masla_id >> masla_SIGNAL_NO_NULL_SIGNAL >> masla_SIGNAL_NO_START_STOP_PRESSED >> masla_SIGNAL_NO_TARGET_PRESSED >> masla_SIGNAL_NO_LAP_RESET_PRESSED >> masla_SIGNAL_NO_LIGHT_PRESSED >> masla_SIGNAL_NO_MODE_PRESSED >> masla_SOCKET_ERROR >> masla_tick_period;
        ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance = ::masld_UI::maslo_UIConstants::createInstance( masla_id, masla_SIGNAL_NO_NULL_SIGNAL, masla_SIGNAL_NO_START_STOP_PRESSED, masla_SIGNAL_NO_TARGET_PRESSED, masla_SIGNAL_NO_LAP_RESET_PRESSED, masla_SIGNAL_NO_LIGHT_PRESSED, masla_SIGNAL_NO_MODE_PRESSED, masla_SOCKET_ERROR, masla_tick_period );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_UIConstantsHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> > ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_UI::maslo_UIConstants::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_UI
  {
    namespace maslo_UIConstants
    {
      void maslo_UIConstantsHandler::writeRelatedInstances ( CommunicationChannel&                            channel,
                                                             ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance,
                                                             int                                              relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
