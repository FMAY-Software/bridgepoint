//
// File: Inspector__UI__UI.cc
//
#include "Inspector__UI__UI.hh"
#include "__UI__UI.hh"
#include "__UI__UIConstants.hh"
#include "__UI__UIEvents.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/EventHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslo_UI
    {
      class masls_connectHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_connectInvoker
      {

        public:
          masls_connectInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslo_UI::masls_connect(); }


      };
      class masls_pollHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_pollInvoker
      {

        public:
          masls_pollInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_poll(); }


        private:
          ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;


      };
      class masls_setDataHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setDataInvoker
      {

        public:
          masls_setDataInvoker ( CommunicationChannel& channel )
            : thisVar(),
              maslp_value(),
              maslp_unit()

          {
            channel >> thisVar;
            channel >> maslp_value;
            channel >> maslp_unit;
          }
          void operator() ( ) { if ( thisVar ) thisVar->masls_setData( maslp_value, maslp_unit ); }


        private:
          ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
          double maslp_value;
          int32_t maslp_unit;


      };
      class masls_setIndicatorHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setIndicatorInvoker
      {

        public:
          masls_setIndicatorInvoker ( CommunicationChannel& channel )
            : thisVar(),
              maslp_value()

          {
            channel >> thisVar;
            channel >> maslp_value;
          }
          void operator() ( ) { if ( thisVar ) thisVar->masls_setIndicator( maslp_value ); }


        private:
          ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
          int32_t maslp_value;


      };
      class masls_setTimeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setTimeInvoker
      {

        public:
          masls_setTimeInvoker ( CommunicationChannel& channel )
            : thisVar(),
              maslp_time()

          {
            channel >> thisVar;
            channel >> maslp_time;
          }
          void operator() ( ) { if ( thisVar ) thisVar->masls_setTime( maslp_time ); }


        private:
          ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
          int32_t maslp_time;


      };
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslo_UI::masls_initialize(); }


      };
      class maslst_runningHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_setTargetPressedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_startStopPresssedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_lapResetPressedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_lightPressedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_modePressedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_UI_maslev_setTargetPressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_UI_maslev_startStopPressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_UI_maslev_lapResetPressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_UI_maslev_lightPressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_UI_maslev_modePressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_UI_maslev_runningHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_UI_maslev_tickHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_connectHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_connectInvoker( channel );
      }

      void masls_connectHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_pollHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_pollInvoker( channel );
      }

      void masls_pollHandler::writeLocalVars ( CommunicationChannel&    channel,
                                               const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_setDataHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setDataInvoker( channel );
      }

      void masls_setDataHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write value
        channel << frame.getParameters()[0].getValue<double>();

        // Write unit
        channel << frame.getParameters()[1].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_setIndicatorHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setIndicatorInvoker( channel );
      }

      void masls_setIndicatorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write value
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_setTimeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setTimeInvoker( channel );
      }

      void masls_setTimeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write time
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write ui
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> >();
              break;

            case 1:

              // Write uiconst
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> >();
              break;

          }

        }
      }

      void maslst_runningHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write uiconst
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> >();
              break;

            case 1:

              // Write ui
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> >();
              break;

            case 2:

              // Write signal_no
              channel << frame.getLocalVars()[i].getValue<int32_t>();
              break;

          }

        }
      }

      void maslst_setTargetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_startStopPresssedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_lapResetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_lightPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_modePressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_UI::maslo_UI>( frame.getThis< ::masld_UI::maslo_UI>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_setTargetPressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_setTargetPressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_setTargetPressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                      BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_setTargetPressed& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_setTargetPressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_startStopPressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_startStopPressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_startStopPressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                      BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_startStopPressed& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_startStopPressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_lapResetPressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_lapResetPressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_lapResetPressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                     BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_lapResetPressed& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_lapResetPressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_lightPressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_lightPressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_lightPressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                  BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_lightPressed& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_lightPressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_modePressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_modePressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_modePressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                 BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_modePressed& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_modePressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_runningHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_running( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_runningHandler::writeParameters ( const ::SWA::Event&   event,
                                                             BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_running& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_running&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_UI_maslev_tickHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_UI_maslev_tick( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_UI_maslev_tickHandler::writeParameters ( const ::SWA::Event&   event,
                                                          BufferedOutputStream& stream ) const
      {
        const ::masld_UI::Event_maslo_UI_maslev_tick& typedEvent = dynamic_cast<const ::masld_UI::Event_maslo_UI_maslev_tick&>( event );
      }

      maslo_UIHandler::maslo_UIHandler ( )
      {
        registerServiceHandler( ::masld_UI::maslo_UI::serviceId_masls_connect, ::boost::shared_ptr<ActionHandler>( new masls_connectHandler() ) );
        registerServiceHandler( ::masld_UI::maslo_UI::serviceId_masls_poll, ::boost::shared_ptr<ActionHandler>( new masls_pollHandler() ) );
        registerServiceHandler( ::masld_UI::maslo_UI::serviceId_masls_setData, ::boost::shared_ptr<ActionHandler>( new masls_setDataHandler() ) );
        registerServiceHandler( ::masld_UI::maslo_UI::serviceId_masls_setIndicator, ::boost::shared_ptr<ActionHandler>( new masls_setIndicatorHandler() ) );
        registerServiceHandler( ::masld_UI::maslo_UI::serviceId_masls_setTime, ::boost::shared_ptr<ActionHandler>( new masls_setTimeHandler() ) );
        registerServiceHandler( ::masld_UI::maslo_UI::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
        registerStateHandler( ::masld_UI::maslo_UI::stateId_maslst_running, ::boost::shared_ptr<ActionHandler>( new maslst_runningHandler() ) );
        registerStateHandler( ::masld_UI::maslo_UI::stateId_maslst_setTargetPressed, ::boost::shared_ptr<ActionHandler>( new maslst_setTargetPressedHandler() ) );
        registerStateHandler( ::masld_UI::maslo_UI::stateId_maslst_startStopPresssed, ::boost::shared_ptr<ActionHandler>( new maslst_startStopPresssedHandler() ) );
        registerStateHandler( ::masld_UI::maslo_UI::stateId_maslst_lapResetPressed, ::boost::shared_ptr<ActionHandler>( new maslst_lapResetPressedHandler() ) );
        registerStateHandler( ::masld_UI::maslo_UI::stateId_maslst_lightPressed, ::boost::shared_ptr<ActionHandler>( new maslst_lightPressedHandler() ) );
        registerStateHandler( ::masld_UI::maslo_UI::stateId_maslst_modePressed, ::boost::shared_ptr<ActionHandler>( new maslst_modePressedHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_setTargetPressed, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_setTargetPressedHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_startStopPressed, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_startStopPressedHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_lapResetPressed, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_lapResetPressedHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_lightPressed, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_lightPressedHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_modePressed, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_modePressedHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_running, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_runningHandler() ) );
        registerEventHandler( ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_tick, ::boost::shared_ptr<EventHandler>( new maslo_UI_maslev_tickHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_UI::maslo_UI> ( const ::masld_UI::maslo_UI& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_id() );
    write( instance.get_masla_socket_id() );
    write( ::SWA::EventTimers::getInstance().getTimer( instance.get_masla_timer() ) );
    write( static_cast<int>( instance.getCurrentState() ) );
  }

  namespace masld_UI
  {
    namespace maslo_UI
    {
      void maslo_UIHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_id;
        int32_t masla_socket_id;
        int currentState;
        channel >> masla_id >> masla_socket_id >> currentState;
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance = ::masld_UI::maslo_UI::createInstance( masla_id, masla_socket_id, ::SWA::EventTimers::getInstance().createTimer(), ::masld_UI::maslo_UI::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_UIHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> > ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_UI::maslo_UI::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_UI
  {
    namespace maslo_UI
    {
      void maslo_UIHandler::writeRelatedInstances ( CommunicationChannel&                   channel,
                                                    ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance,
                                                    int                                     relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
