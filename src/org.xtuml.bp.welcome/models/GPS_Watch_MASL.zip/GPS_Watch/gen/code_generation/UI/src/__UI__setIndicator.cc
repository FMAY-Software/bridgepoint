//
// File: __UI__setIndicator.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_services.hh"
#include "UI_OOA/__UI_types.hh"
#include "__UI__UI.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_setIndicator ( const maslt_UIIndicator& maslp_indicator )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_setIndicator);
      ::SWA::Stack::DeclareParameter pm_maslp_indicator(maslp_indicator);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // ui : instance of UI;
        ::SWA::ObjectPtr<maslo_UI> maslv_ui;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_ui(0, maslv_ui);

        // ui := find_one UI ();
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_ui = maslo_UI::findOne();
        }

        // if (null /= ui) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          if ( ::SWA::Null != maslv_ui )
          {

            // if (indicator = UI::UIIndicator.Blank) then ...
            // elsif (indicator = UI::UIIndicator.Down) then ...
            // elsif (indicator = UI::UIIndicator.Flat) then ...
            // elsif (indicator = UI::UIIndicator.Up) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              if ( maslp_indicator == maslt_UIIndicator::masle_Blank )
              {

                // ui.setIndicator(0)
                {
                  ::SWA::Stack::ExecutingStatement statement(8);
                  maslv_ui->masls_setIndicator( 0ll );
                }
              }
              else if ( maslp_indicator == maslt_UIIndicator::masle_Down )
              {

                // ui.setIndicator(1)
                {
                  ::SWA::Stack::ExecutingStatement statement(10);
                  maslv_ui->masls_setIndicator( 1ll );
                }
              }
              else if ( maslp_indicator == maslt_UIIndicator::masle_Flat )
              {

                // ui.setIndicator(2)
                {
                  ::SWA::Stack::ExecutingStatement statement(12);
                  maslv_ui->masls_setIndicator( 2ll );
                }
              }
              else if ( maslp_indicator == maslt_UIIndicator::masle_Up )
              {

                // ui.setIndicator(3)
                {
                  ::SWA::Stack::ExecutingStatement statement(14);
                  maslv_ui->masls_setIndicator( 3ll );
                }
              }
            }
          }
        }
      }
    }
  }

  const bool localServiceRegistration_masls_setIndicator = interceptor_masls_setIndicator::instance().registerLocal( &masls_setIndicator );

}
