//
// File: Sqlite__UI__TestCase.hh
//
#ifndef Sqlite_UI_Test_Case_hh
#define Sqlite_UI_Test_Case_hh

#include "__UI__TestCase.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_TestCase
      : public ::masld_UI::maslo_TestCase
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_TestCase ( ::SWA::IdType architectureId );
        maslo_TestCase ( ::SWA::IdType                    architectureId,
                         int32_t                          masla_iterations,
                         int32_t                          masla_id,
                         ::masld_UI::maslo_TestCase::Type currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_iterations ( int32_t value )
        {
          this->masla_iterations = value;
          markAsModified();
        }
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void setCurrentState ( ::masld_UI::maslo_TestCase::Type newState )
        {
          currentState = newState;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_iterations ( ) const { return masla_iterations; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual ::masld_UI::maslo_TestCase::Type getCurrentState ( ) const { return currentState; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_iterations;
        int32_t masla_id;
        ::masld_UI::maslo_TestCase::Type currentState;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_UI_Test_Case_hh
