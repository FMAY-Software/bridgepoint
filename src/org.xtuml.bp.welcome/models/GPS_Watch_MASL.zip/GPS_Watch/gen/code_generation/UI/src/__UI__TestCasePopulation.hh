//
// File: __UI__TestCasePopulation.hh
//
#ifndef _UI_Test_Case_Population_hh
#define _UI_Test_Case_Population_hh

#include "__UI__TestCase.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  class maslo_TestCasePopulation
    : public ::SWA::DynamicSingleton<maslo_TestCasePopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_TestCase> createInstance ( int32_t              masla_iterations,
                                                                int32_t              masla_id,
                                                                maslo_TestCase::Type currentState ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_TestCase> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_TestCase> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_TestCase> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_TestCase> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_TestCase> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_TestCasePopulation ( );
      virtual ~maslo_TestCasePopulation ( );


    // Prevent copy
    private:
      maslo_TestCasePopulation ( const maslo_TestCasePopulation& rhs );
      maslo_TestCasePopulation& operator= ( const maslo_TestCasePopulation& rhs );


  };
}
#endif // _UI_Test_Case_Population_hh
