//
// File: __UI__UI.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__UI.hh"
#include "__UI__UIEvents.hh"
#include "__UI__UIPopulation.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  ::SWA::ObjectPtr<maslo_UI> maslo_UI::getInstance ( ::SWA::IdType id )
  {
    return maslo_UIPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_UI::getNextArchId ( )
  {
    return maslo_UIPopulation::getSingleton().getNextArchId();
  }

  void maslo_UI::process_maslo_UI_maslev_setTargetPressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_running:
      {
        state_maslst_setTargetPressed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_setTargetPressed );
        setCurrentState( maslst_setTargetPressed );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_setTargetPressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_setTargetPressed ( int           sourceObj,
                                                                                         ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_setTargetPressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_setTargetPressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_setTargetPressed();
  }

  int Event_maslo_UI_maslev_setTargetPressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_setTargetPressed::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_setTargetPressed::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_setTargetPressed;
  }

  Event_maslo_UI_maslev_setTargetPressed::Event_maslo_UI_maslev_setTargetPressed ( )
  {
  }

  void Event_maslo_UI_maslev_setTargetPressed::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_setTargetPressed( getDestInstanceId() );
  }

  void maslo_UI::process_maslo_UI_maslev_startStopPressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_running:
      {
        state_maslst_startStopPresssed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_startStopPresssed );
        setCurrentState( maslst_startStopPresssed );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_startStopPressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_startStopPressed ( int           sourceObj,
                                                                                         ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_startStopPressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_startStopPressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_startStopPressed();
  }

  int Event_maslo_UI_maslev_startStopPressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_startStopPressed::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_startStopPressed::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_startStopPressed;
  }

  Event_maslo_UI_maslev_startStopPressed::Event_maslo_UI_maslev_startStopPressed ( )
  {
  }

  void Event_maslo_UI_maslev_startStopPressed::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_startStopPressed( getDestInstanceId() );
  }

  void maslo_UI::process_maslo_UI_maslev_lapResetPressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_running:
      {
        state_maslst_lapResetPressed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_lapResetPressed );
        setCurrentState( maslst_lapResetPressed );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_lapResetPressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_lapResetPressed ( int           sourceObj,
                                                                                        ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_lapResetPressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_lapResetPressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_lapResetPressed();
  }

  int Event_maslo_UI_maslev_lapResetPressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_lapResetPressed::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_lapResetPressed::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_lapResetPressed;
  }

  Event_maslo_UI_maslev_lapResetPressed::Event_maslo_UI_maslev_lapResetPressed ( )
  {
  }

  void Event_maslo_UI_maslev_lapResetPressed::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_lapResetPressed( getDestInstanceId() );
  }

  void maslo_UI::process_maslo_UI_maslev_lightPressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_running:
      {
        state_maslst_lightPressed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_lightPressed );
        setCurrentState( maslst_lightPressed );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_lightPressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_lightPressed ( int           sourceObj,
                                                                                     ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_lightPressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_lightPressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_lightPressed();
  }

  int Event_maslo_UI_maslev_lightPressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_lightPressed::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_lightPressed::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_lightPressed;
  }

  Event_maslo_UI_maslev_lightPressed::Event_maslo_UI_maslev_lightPressed ( )
  {
  }

  void Event_maslo_UI_maslev_lightPressed::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_lightPressed( getDestInstanceId() );
  }

  void maslo_UI::process_maslo_UI_maslev_modePressed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_running:
      {
        state_maslst_modePressed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_modePressed );
        setCurrentState( maslst_modePressed );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_modePressed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_modePressed ( int           sourceObj,
                                                                                    ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_modePressed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_modePressed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_modePressed();
  }

  int Event_maslo_UI_maslev_modePressed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_modePressed::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_modePressed::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_modePressed;
  }

  Event_maslo_UI_maslev_modePressed::Event_maslo_UI_maslev_modePressed ( )
  {
  }

  void Event_maslo_UI_maslev_modePressed::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_modePressed( getDestInstanceId() );
  }

  void maslo_UI::process_maslo_UI_maslev_running ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_setTargetPressed:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      case maslst_startStopPresssed:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      case maslst_lapResetPressed:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      case maslst_lightPressed:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      case maslst_modePressed:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_running ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_running ( int           sourceObj,
                                                                                ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_running());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_running ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_running();
  }

  int Event_maslo_UI_maslev_running::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_running::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_running::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_running;
  }

  Event_maslo_UI_maslev_running::Event_maslo_UI_maslev_running ( )
  {
  }

  void Event_maslo_UI_maslev_running::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_running( getDestInstanceId() );
  }

  void maslo_UI::process_maslo_UI_maslev_tick ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_running:
      {
        state_maslst_running();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_UI, getArchitectureId(), getCurrentState(), maslst_running );
        setCurrentState( maslst_running );
        break;
      }
      case maslst_setTargetPressed:
        /* Ignore */
        break;

      case maslst_startStopPresssed:
        /* Ignore */
        break;

      case maslst_lapResetPressed:
        /* Ignore */
        break;

      case maslst_lightPressed:
        /* Ignore */
        break;

      case maslst_modePressed:
        /* Ignore */
        break;

      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_UI, eventId_maslo_UI_maslev_tick ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_UI ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_UI, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_UI::create_maslo_UI_maslev_tick ( int           sourceObj,
                                                                             ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_UI_maslev_tick());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_UI::consume_maslo_UI_maslev_tick ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_UI> instance = getInstance( id );
    if ( instance ) instance->process_maslo_UI_maslev_tick();
  }

  int Event_maslo_UI_maslev_tick::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_UI_maslev_tick::getObjectId ( ) const
  {
    return objectId_maslo_UI;
  }

  int Event_maslo_UI_maslev_tick::getEventId ( ) const
  {
    return maslo_UI::eventId_maslo_UI_maslev_tick;
  }

  Event_maslo_UI_maslev_tick::Event_maslo_UI_maslev_tick ( )
  {
  }

  void Event_maslo_UI_maslev_tick::invoke ( ) const
  {
    maslo_UI::consume_maslo_UI_maslev_tick( getDestInstanceId() );
  }

  maslo_UI::maslo_UI ( )
    : isDeletedFlag()
  {
  }

  maslo_UI::~maslo_UI ( )
  {
  }

  ::SWA::ObjectPtr<maslo_UI> maslo_UI::createInstance ( int32_t                                masla_id,
                                                        int32_t                                masla_socket_id,
                                                        const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                        Type                                   currentState )
  {
    return maslo_UIPopulation::getSingleton().createInstance( masla_id, masla_socket_id, masla_timer, currentState );
  }

  void maslo_UI::deleteInstance ( )
  {
    maslo_UIPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_UI>( this ) );
    ::SWA::EventTimers::getInstance().deleteTimer( get_masla_timer() );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_UI::getPopulationSize ( )
  {
    return maslo_UIPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_UI> > maslo_UI::findAll ( )
  {
    return maslo_UIPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_UI> maslo_UI::findOne ( )
  {
    return maslo_UIPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_UI> maslo_UI::findOnly ( )
  {
    return maslo_UIPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream& stream,
                               const maslo_UI& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_socket_id();
    stream << ",";
    stream << obj.get_masla_timer();
    stream << ")";
    return stream;
  }

}
