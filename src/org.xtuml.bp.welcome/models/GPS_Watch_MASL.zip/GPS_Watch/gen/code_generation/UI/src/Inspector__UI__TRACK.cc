//
// File: Inspector__UI__TRACK.cc
//
#include "Inspector__UI__TRACK.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "UI_OOA/__UI_types.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      class masls_setTargetPressedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_setTargetPressedInvoker
      {

        public:
          masls_setTargetPressedInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslb_TRACK::masls_setTargetPressed(); }


      };
      class masls_startStopPressedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_startStopPressedInvoker
      {

        public:
          masls_startStopPressedInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslb_TRACK::masls_startStopPressed(); }


      };
      class masls_lapResetPressedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_lapResetPressedInvoker
      {

        public:
          masls_lapResetPressedInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslb_TRACK::masls_lapResetPressed(); }


      };
      class masls_lightPressedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_lightPressedInvoker
      {

        public:
          masls_lightPressedInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslb_TRACK::masls_lightPressed(); }


      };
      class masls_modePressedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_modePressedInvoker
      {

        public:
          masls_modePressedInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_UI::maslb_TRACK::masls_modePressed(); }


      };
      class masls_newGoalSpecHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_newGoalSpecInvoker
      {

        public:
          masls_newGoalSpecInvoker ( CommunicationChannel& channel )
            : maslp_spanType(),
              maslp_criteriaType(),
              maslp_span(),
              maslp_maximum(),
              maslp_minimum(),
              maslp_sequenceNumber()

          {
            channel >> maslp_spanType;
            channel >> maslp_criteriaType;
            channel >> maslp_span;
            channel >> maslp_maximum;
            channel >> maslp_minimum;
            channel >> maslp_sequenceNumber;
          }
          void operator() ( ) { ::masld_UI::maslb_TRACK::masls_newGoalSpec( maslp_spanType, maslp_criteriaType, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber ); }


        private:
          ::masld_UI::maslt_UIGoalSpan maslp_spanType;
          ::masld_UI::maslt_UIGoalCriteria maslp_criteriaType;
          double maslp_span;
          double maslp_maximum;
          double maslp_minimum;
          int32_t maslp_sequenceNumber;


      };
      Callable masls_setTargetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_setTargetPressedInvoker( channel );
      }

      void masls_setTargetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_startStopPressedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_startStopPressedInvoker( channel );
      }

      void masls_startStopPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_lapResetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_lapResetPressedInvoker( channel );
      }

      void masls_lapResetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_lightPressedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_lightPressedInvoker( channel );
      }

      void masls_lightPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_modePressedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_modePressedInvoker( channel );
      }

      void masls_modePressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_newGoalSpecHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_newGoalSpecInvoker( channel );
      }

      void masls_newGoalSpecHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write spanType
        channel << frame.getParameters()[0].getValue< ::masld_UI::maslt_UIGoalSpan>();

        // Write criteriaType
        channel << frame.getParameters()[1].getValue< ::masld_UI::maslt_UIGoalCriteria>();

        // Write span
        channel << frame.getParameters()[2].getValue<double>();

        // Write maximum
        channel << frame.getParameters()[3].getValue<double>();

        // Write minimum
        channel << frame.getParameters()[4].getValue<double>();

        // Write sequenceNumber
        channel << frame.getParameters()[5].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      maslb_TRACKHandler::maslb_TRACKHandler ( )
      {
        registerServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_setTargetPressed, ::boost::shared_ptr<ActionHandler>( new masls_setTargetPressedHandler() ) );
        registerServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_startStopPressed, ::boost::shared_ptr<ActionHandler>( new masls_startStopPressedHandler() ) );
        registerServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_lapResetPressed, ::boost::shared_ptr<ActionHandler>( new masls_lapResetPressedHandler() ) );
        registerServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_lightPressed, ::boost::shared_ptr<ActionHandler>( new masls_lightPressedHandler() ) );
        registerServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_modePressed, ::boost::shared_ptr<ActionHandler>( new masls_modePressedHandler() ) );
        registerServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_newGoalSpec, ::boost::shared_ptr<ActionHandler>( new masls_newGoalSpecHandler() ) );
      }

    }
  }
}
