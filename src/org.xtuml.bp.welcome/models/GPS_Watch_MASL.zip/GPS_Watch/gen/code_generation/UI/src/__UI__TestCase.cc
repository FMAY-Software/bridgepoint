//
// File: __UI__TestCase.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__TestCase.hh"
#include "__UI__TestCaseEvents.hh"
#include "__UI__TestCasePopulation.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  ::SWA::ObjectPtr<maslo_TestCase> maslo_TestCase::getInstance ( ::SWA::IdType id )
  {
    return maslo_TestCasePopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_TestCase::getNextArchId ( )
  {
    return maslo_TestCasePopulation::getSingleton().getNextArchId();
  }

  void maslo_TestCase::process_maslo_TestCase_maslev_doDelay ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_pressStartStop:
      {
        state_maslst_pressStartStop();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_TestCase, getArchitectureId(), getCurrentState(), maslst_pressStartStop );
        setCurrentState( maslst_pressStartStop );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_TestCase, eventId_maslo_TestCase_maslev_doDelay ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_TestCase ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_TestCase, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_TestCase::create_maslo_TestCase_maslev_doDelay ( int           sourceObj,
                                                                                            ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_TestCase_maslev_doDelay());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_TestCase::consume_maslo_TestCase_maslev_doDelay ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_TestCase> instance = getInstance( id );
    if ( instance ) instance->process_maslo_TestCase_maslev_doDelay();
  }

  int Event_maslo_TestCase_maslev_doDelay::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_TestCase_maslev_doDelay::getObjectId ( ) const
  {
    return objectId_maslo_TestCase;
  }

  int Event_maslo_TestCase_maslev_doDelay::getEventId ( ) const
  {
    return maslo_TestCase::eventId_maslo_TestCase_maslev_doDelay;
  }

  Event_maslo_TestCase_maslev_doDelay::Event_maslo_TestCase_maslev_doDelay ( )
  {
  }

  void Event_maslo_TestCase_maslev_doDelay::invoke ( ) const
  {
    maslo_TestCase::consume_maslo_TestCase_maslev_doDelay( getDestInstanceId() );
  }

  void maslo_TestCase::process_maslo_TestCase_maslev_finish ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_pressStartStop:
      {
        state_maslst_testCaseFinished();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_TestCase, getArchitectureId(), getCurrentState(), maslst_testCaseFinished );
        setCurrentState( maslst_testCaseFinished );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_TestCase, eventId_maslo_TestCase_maslev_finish ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_TestCase ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_TestCase, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_TestCase::create_maslo_TestCase_maslev_finish ( int           sourceObj,
                                                                                           ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_TestCase_maslev_finish());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_TestCase::consume_maslo_TestCase_maslev_finish ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_TestCase> instance = getInstance( id );
    if ( instance ) instance->process_maslo_TestCase_maslev_finish();
  }

  int Event_maslo_TestCase_maslev_finish::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_TestCase_maslev_finish::getObjectId ( ) const
  {
    return objectId_maslo_TestCase;
  }

  int Event_maslo_TestCase_maslev_finish::getEventId ( ) const
  {
    return maslo_TestCase::eventId_maslo_TestCase_maslev_finish;
  }

  Event_maslo_TestCase_maslev_finish::Event_maslo_TestCase_maslev_finish ( )
  {
  }

  void Event_maslo_TestCase_maslev_finish::invoke ( ) const
  {
    maslo_TestCase::consume_maslo_TestCase_maslev_finish( getDestInstanceId() );
  }

  void maslo_TestCase::process_maslo_TestCase_maslev_initializationComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_initialize:
      {
        state_maslst_pressStartStop();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_TestCase, getArchitectureId(), getCurrentState(), maslst_pressStartStop );
        setCurrentState( maslst_pressStartStop );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_TestCase, eventId_maslo_TestCase_maslev_initializationComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_TestCase ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_TestCase, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_TestCase::create_maslo_TestCase_maslev_initializationComplete ( int           sourceObj,
                                                                                                           ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_TestCase_maslev_initializationComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_TestCase::consume_maslo_TestCase_maslev_initializationComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_TestCase> instance = getInstance( id );
    if ( instance ) instance->process_maslo_TestCase_maslev_initializationComplete();
  }

  int Event_maslo_TestCase_maslev_initializationComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_TestCase_maslev_initializationComplete::getObjectId ( ) const
  {
    return objectId_maslo_TestCase;
  }

  int Event_maslo_TestCase_maslev_initializationComplete::getEventId ( ) const
  {
    return maslo_TestCase::eventId_maslo_TestCase_maslev_initializationComplete;
  }

  Event_maslo_TestCase_maslev_initializationComplete::Event_maslo_TestCase_maslev_initializationComplete ( )
  {
  }

  void Event_maslo_TestCase_maslev_initializationComplete::invoke ( ) const
  {
    maslo_TestCase::consume_maslo_TestCase_maslev_initializationComplete( getDestInstanceId() );
  }

  void maslo_TestCase::process_maslo_TestCase_maslev_initialize ( int32_t maslp_iterations )
  {
    switch ( getCurrentState() )
    {
      case maslst_Idle:
      {
        state_maslst_initialize( maslp_iterations );
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_TestCase, getArchitectureId(), getCurrentState(), maslst_initialize );
        setCurrentState( maslst_initialize );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_TestCase, eventId_maslo_TestCase_maslev_initialize ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_TestCase ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_TestCase, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_TestCase::create_maslo_TestCase_maslev_initialize ( int32_t       maslp_iterations,
                                                                                               int           sourceObj,
                                                                                               ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_TestCase_maslev_initialize(  maslp_iterations ));
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_TestCase::consume_maslo_TestCase_maslev_initialize ( ::SWA::IdType id,
                                                                  int32_t       maslp_iterations )
  {
    ::SWA::ObjectPtr<maslo_TestCase> instance = getInstance( id );
    if ( instance ) instance->process_maslo_TestCase_maslev_initialize( maslp_iterations );
  }

  int Event_maslo_TestCase_maslev_initialize::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_TestCase_maslev_initialize::getObjectId ( ) const
  {
    return objectId_maslo_TestCase;
  }

  int Event_maslo_TestCase_maslev_initialize::getEventId ( ) const
  {
    return maslo_TestCase::eventId_maslo_TestCase_maslev_initialize;
  }

  Event_maslo_TestCase_maslev_initialize::Event_maslo_TestCase_maslev_initialize ( )
    : maslp_iterations()
  {
  }

  Event_maslo_TestCase_maslev_initialize::Event_maslo_TestCase_maslev_initialize ( int32_t maslp_iterations )
    : maslp_iterations(maslp_iterations)
  {
    addParam( this->maslp_iterations );
  }

  void Event_maslo_TestCase_maslev_initialize::invoke ( ) const
  {
    maslo_TestCase::consume_maslo_TestCase_maslev_initialize( getDestInstanceId(), maslp_iterations );
  }

  maslo_TestCase::maslo_TestCase ( )
    : isDeletedFlag()
  {
  }

  maslo_TestCase::~maslo_TestCase ( )
  {
  }

  ::SWA::ObjectPtr<maslo_TestCase> maslo_TestCase::createInstance ( int32_t masla_iterations,
                                                                    int32_t masla_id,
                                                                    Type    currentState )
  {
    return maslo_TestCasePopulation::getSingleton().createInstance( masla_iterations, masla_id, currentState );
  }

  void maslo_TestCase::deleteInstance ( )
  {
    maslo_TestCasePopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_TestCase>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_TestCase::getPopulationSize ( )
  {
    return maslo_TestCasePopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_TestCase> > maslo_TestCase::findAll ( )
  {
    return maslo_TestCasePopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_TestCase> maslo_TestCase::findOne ( )
  {
    return maslo_TestCasePopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_TestCase> maslo_TestCase::findOnly ( )
  {
    return maslo_TestCasePopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_TestCase& obj )
  {
    stream << "(";
    stream << obj.get_masla_iterations();
    stream << ",";
    stream << obj.get_masla_id();
    stream << ")";
    return stream;
  }

}
