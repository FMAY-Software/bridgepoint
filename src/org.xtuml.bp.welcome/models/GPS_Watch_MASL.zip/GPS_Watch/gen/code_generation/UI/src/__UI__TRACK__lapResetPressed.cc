//
// File: __UI__TRACK__lapResetPressed.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_UI
{
  void maslb_TRACK::masls_lapResetPressed ( )
  {
    getInstance().override_masls_lapResetPressed.getFunction()();
  }

  bool maslb_TRACK::register_masls_lapResetPressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override )
  {
    getInstance().override_masls_lapResetPressed.override( override );
    return true;
  }

  bool maslb_TRACK::overriden_masls_lapResetPressed ( )
  {
    return getInstance().override_masls_lapResetPressed.isOverridden();
  }

  void maslb_TRACK::domain_masls_lapResetPressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_TRACK, serviceId_masls_lapResetPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Sending message 'lapResetPressed' on terminator TRACK")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'lapResetPressed' on terminator TRACK" ) );
        }
      }
    }
  }

}
