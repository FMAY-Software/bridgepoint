//
// File: Transient__UI__TestCase.cc
//
#include "Transient__UI__TestCase.hh"
#include "__UI__TestCase.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_UI
  {
    maslo_TestCase::maslo_TestCase ( int32_t                          masla_iterations,
                                     int32_t                          masla_id,
                                     ::masld_UI::maslo_TestCase::Type currentState )
      : architectureId(getNextArchId()),
        masla_iterations(masla_iterations),
        masla_id(masla_id),
        currentState(currentState)
    {
    }

  }
}
