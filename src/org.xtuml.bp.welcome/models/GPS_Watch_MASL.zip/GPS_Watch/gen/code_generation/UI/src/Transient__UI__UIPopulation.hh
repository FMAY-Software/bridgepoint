//
// File: Transient__UI__UIPopulation.hh
//
#ifndef Transient_UI_UI_Population_hh
#define Transient_UI_UI_Population_hh

#include "__UI__UI.hh"
#include "__UI__UIPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_UI
  {
    class maslo_UIPopulation
      : public TransientPopulation< ::masld_UI::maslo_UI,::masld_UI::maslo_UIPopulation>
    {

      // Instance Creation
      private:
        maslo_UIPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_UI> createInstance ( int32_t                                masla_id,
                                                                         int32_t                                masla_socket_id,
                                                                         const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                         ::masld_UI::maslo_UI::Type             currentState );


      // Singleton Registration
      public:
        static maslo_UIPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_UI::maslo_UI> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_UI_UI_Population_hh
