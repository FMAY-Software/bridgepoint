//
// File: __GPS_Watch__Tracking__HR__unregisterListener.hh
//
#ifndef _GPS_Watch_Tracking_HR_unregister_Listener_hh
#define _GPS_Watch_Tracking_HR_unregister_Listener_hh

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_HR
    {
      void masls_unregisterListener ( );
    }
  }
}
#endif // _GPS_Watch_Tracking_HR_unregister_Listener_hh
