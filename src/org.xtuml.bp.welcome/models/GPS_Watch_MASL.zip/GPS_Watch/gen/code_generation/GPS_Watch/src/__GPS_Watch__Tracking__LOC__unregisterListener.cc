//
// File: __GPS_Watch__Tracking__LOC__unregisterListener.cc
//
#include "Location_OOA/__Location_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "__GPS_Watch__Tracking__LOC__unregisterListener.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      bool register_masls_unregisterListener = ::masld_Tracking::maslb_LOC::register_masls_unregisterListener( &masls_unregisterListener );

      void masls_unregisterListener ( )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, ::masld_Tracking::maslb_LOC::serviceId_masls_unregisterListener);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(2);
          {

            // Location::unregisterListener()
            {
              ::SWA::Stack::ExecutingStatement statement(3);
              ::masld_Location::interceptor_masls_unregisterListener::instance().callService()();
            }
          }
        }
      }

    }
  }
}
