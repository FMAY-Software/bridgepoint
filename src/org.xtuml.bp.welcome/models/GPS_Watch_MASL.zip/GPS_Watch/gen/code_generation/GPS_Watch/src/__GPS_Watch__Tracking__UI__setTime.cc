//
// File: __GPS_Watch__Tracking__UI__setTime.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "UI_OOA/__UI_services.hh"
#include "__GPS_Watch__Tracking__UI__setTime.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      bool register_masls_setTime = ::masld_Tracking::maslb_UI::register_masls_setTime( &masls_setTime );

      void masls_setTime ( int32_t maslp_time )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_UI, ::masld_Tracking::maslb_UI::serviceId_masls_setTime);
          ::SWA::Stack::DeclareParameter pm_maslp_time(maslp_time);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(2);
          {

            // UI::setTime(time)
            {
              ::SWA::Stack::ExecutingStatement statement(3);
              ::masld_UI::interceptor_masls_setTime::instance().callService()( maslp_time );
            }
          }
        }
      }

    }
  }
}
