//
// File: __GPS_Watch__UI__TRACK__newGoalSpec.hh
//
#ifndef _GPS_Watch_UI_TRACK_new_Goal_Spec_hh
#define _GPS_Watch_UI_TRACK_new_Goal_Spec_hh

#include <stdint.h>

namespace masld_UI
{
  class maslt_UIGoalSpan;
  class maslt_UIGoalCriteria;
}
namespace maslp_GPS_Watch
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      void masls_newGoalSpec ( const ::masld_UI::maslt_UIGoalSpan&     maslp_spanType,
                               const ::masld_UI::maslt_UIGoalCriteria& maslp_criteriaType,
                               double                                  maslp_span,
                               double                                  maslp_maximum,
                               double                                  maslp_minimum,
                               int32_t                                 maslp_sequenceNumber );
    }
  }
}
#endif // _GPS_Watch_UI_TRACK_new_Goal_Spec_hh
