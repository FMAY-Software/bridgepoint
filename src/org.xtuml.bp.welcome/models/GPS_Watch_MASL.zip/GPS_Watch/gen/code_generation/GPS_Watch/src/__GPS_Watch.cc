//
// File: __GPS_Watch.cc
//
#include "swa/Main.hh"
#include "swa/Process.hh"

namespace maslp_GPS_Watch
{
  bool initialiseProcess ( )
  {
    ::SWA::Process::getInstance().setProjectName( "GPS_Watch" );
    return true;
  }

  const bool processInitialised = initialiseProcess();

}
int main ( int                 argc,
           const char* const * argv )
{
  return SWA::main( argc, argv );
}

