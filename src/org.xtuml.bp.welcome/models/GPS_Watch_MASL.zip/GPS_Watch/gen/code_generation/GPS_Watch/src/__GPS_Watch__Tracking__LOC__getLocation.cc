//
// File: __GPS_Watch__Tracking__LOC__getLocation.cc
//
#include "Location_OOA/__Location_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "__GPS_Watch__Tracking__LOC__getLocation.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      bool register_masls_getLocation = ::masld_Tracking::maslb_LOC::register_masls_getLocation( &masls_getLocation );

      void masls_getLocation ( double& maslp_longitude,
                               double& maslp_latitude )
      {

        // declare ...
        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, ::masld_Tracking::maslb_LOC::serviceId_masls_getLocation);
          ::SWA::Stack::DeclareParameter pm_maslp_longitude(maslp_longitude);
          ::SWA::Stack::DeclareParameter pm_maslp_latitude(maslp_latitude);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(5);
          {

            // lat : real;
            double maslv_lat = 0;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_lat(0, maslv_lat);

            // longi : real;
            double maslv_longi = 0;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_longi(1, maslv_longi);

            // lat := latitude;
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_lat = maslp_latitude;
            }

            // longi := longitude;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_longi = maslp_longitude;
            }

            // Location::getLocation(longi, lat)
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              ::masld_Location::interceptor_masls_getLocation::instance().callService()( maslv_longi, maslv_lat );
            }

            // latitude := lat;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              maslp_latitude = maslv_lat;
            }

            // longitude := longi;
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              maslp_longitude = maslv_longi;
            }
          }
        }
      }

    }
  }
}
