//
// File: __GPS_Watch__Tracking__UI__setIndicator.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "UI_OOA/__UI_services.hh"
#include "UI_OOA/__UI_types.hh"
#include "__GPS_Watch__Tracking__UI__setIndicator.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      bool register_masls_setIndicator = ::masld_Tracking::maslb_UI::register_masls_setIndicator( &masls_setIndicator );

      void masls_setIndicator ( const ::masld_Tracking::maslt_Indicator& maslp_indicator )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_UI, ::masld_Tracking::maslb_UI::serviceId_masls_setIndicator);
          ::SWA::Stack::DeclareParameter pm_maslp_indicator(maslp_indicator);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(2);
          {

            // if (indicator = Tracking::Indicator.Blank) then ...
            // elsif (indicator = Tracking::Indicator.Down) then ...
            // elsif (indicator = Tracking::Indicator.Flat) then ...
            // elsif (indicator = Tracking::Indicator.Up) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(3);
              if ( maslp_indicator == ::masld_Tracking::maslt_Indicator::masle_Blank )
              {

                // UI::setIndicator(UI::UIIndicator.Blank)
                {
                  ::SWA::Stack::ExecutingStatement statement(4);
                  ::masld_UI::interceptor_masls_setIndicator::instance().callService()( ::masld_UI::maslt_UIIndicator::masle_Blank );
                }
              }
              else if ( maslp_indicator == ::masld_Tracking::maslt_Indicator::masle_Down )
              {

                // UI::setIndicator(UI::UIIndicator.Down)
                {
                  ::SWA::Stack::ExecutingStatement statement(6);
                  ::masld_UI::interceptor_masls_setIndicator::instance().callService()( ::masld_UI::maslt_UIIndicator::masle_Down );
                }
              }
              else if ( maslp_indicator == ::masld_Tracking::maslt_Indicator::masle_Flat )
              {

                // UI::setIndicator(UI::UIIndicator.Flat)
                {
                  ::SWA::Stack::ExecutingStatement statement(8);
                  ::masld_UI::interceptor_masls_setIndicator::instance().callService()( ::masld_UI::maslt_UIIndicator::masle_Flat );
                }
              }
              else if ( maslp_indicator == ::masld_Tracking::maslt_Indicator::masle_Up )
              {

                // UI::setIndicator(UI::UIIndicator.Up)
                {
                  ::SWA::Stack::ExecutingStatement statement(10);
                  ::masld_UI::interceptor_masls_setIndicator::instance().callService()( ::masld_UI::maslt_UIIndicator::masle_Up );
                }
              }
            }
          }
        }
      }

    }
  }
}
