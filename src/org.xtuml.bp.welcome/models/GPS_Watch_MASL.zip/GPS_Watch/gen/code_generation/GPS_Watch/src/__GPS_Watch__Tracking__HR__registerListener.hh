//
// File: __GPS_Watch__Tracking__HR__registerListener.hh
//
#ifndef _GPS_Watch_Tracking_HR_register_Listener_hh
#define _GPS_Watch_Tracking_HR_register_Listener_hh

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_HR
    {
      void masls_registerListener ( );
    }
  }
}
#endif // _GPS_Watch_Tracking_HR_register_Listener_hh
