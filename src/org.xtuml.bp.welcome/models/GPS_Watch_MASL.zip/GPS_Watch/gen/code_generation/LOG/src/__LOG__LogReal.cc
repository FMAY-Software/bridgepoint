//
// File: __LOG__LogReal.cc
//
#include "Format_OOA/__Format_services.hh"
#include "LOG_OOA/__LOG_interface.hh"
#include "LOG_OOA/__LOG_services.hh"
#include "Logger_OOA/__Logger_services.hh"
#include "Logger_OOA/__Logger_types.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_LOG
{
  void masls_LogReal ( const ::SWA::String& maslp_message,
                       double               maslp_r )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_LogReal);
      ::SWA::Stack::DeclareParameter pm_maslp_message(maslp_message);
      ::SWA::Stack::DeclareParameter pm_maslp_r(maslp_r);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // Logger::log(Logger::Priority.Information, ((message & ": ") & Format::format_number(r, false, 3)))
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::masld_Logger::interceptor_masls_log::instance().callService()( ::masld_Logger::maslt_Priority::masle_Information, maslp_message + ::SWA::String( ": " ) += ::masld_Format::masls_format_number( maslp_r, false, 3ll ) );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_LogReal = interceptor_masls_LogReal::instance().registerLocal( &masls_LogReal );

}
