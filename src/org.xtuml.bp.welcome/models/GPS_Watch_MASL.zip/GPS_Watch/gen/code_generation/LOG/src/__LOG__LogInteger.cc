//
// File: __LOG__LogInteger.cc
//
#include "Format_OOA/__Format_services.hh"
#include "LOG_OOA/__LOG_interface.hh"
#include "LOG_OOA/__LOG_services.hh"
#include "Logger_OOA/__Logger_services.hh"
#include "Logger_OOA/__Logger_types.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_LOG
{
  void masls_LogInteger ( int32_t maslp_message )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_LogInteger);
      ::SWA::Stack::DeclareParameter pm_maslp_message(maslp_message);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // Logger::log(Logger::Priority.Information, Format::format_integer(message, false))
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_Logger::interceptor_masls_log::instance().callService()( ::masld_Logger::maslt_Priority::masle_Information, ::masld_Format::masls_format_integer( maslp_message, false ) );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_LogInteger = interceptor_masls_LogInteger::instance().registerLocal( &masls_LogInteger );

}
