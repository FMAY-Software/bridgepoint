//
// File: MetaData__LOG.cc
//
#include "LOG_OOA/__LOG_interface.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_LOG
  {
    ::SWA::ServiceMetaData get_masls_LogSuccess_MetaData ( );
    ::SWA::ServiceMetaData get_masls_LogFailure_MetaData ( );
    ::SWA::ServiceMetaData get_masls_LogInfo_MetaData ( );
    ::SWA::ServiceMetaData get_masls_LogInteger_MetaData ( );
    ::SWA::ServiceMetaData get_masls_LogReal_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_LOG::getDomain().getId(), "LOG", false);
      domain.addService( get_masls_LogSuccess_MetaData() );
      domain.addService( get_masls_LogFailure_MetaData() );
      domain.addService( get_masls_LogInfo_MetaData() );
      domain.addService( get_masls_LogInteger_MetaData() );
      domain.addService( get_masls_LogReal_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_LOG::getDomain().getId(), &getDomainMetaData );

    ::SWA::ServiceMetaData get_masls_LogSuccess_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_LOG::serviceId_masls_LogSuccess, ::SWA::ServiceMetaData::Domain, "LogSuccess", ::std::vector<int>( lines, lines + 2 ), "LogSuccess.svc", "f091a672cb1143b05dfb6fccdcd4421f");
      service.addParameter( ::SWA::ParameterMetaData( "message", "string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_LogFailure_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_LOG::serviceId_masls_LogFailure, ::SWA::ServiceMetaData::Domain, "LogFailure", ::std::vector<int>( lines, lines + 2 ), "LogFailure.svc", "fa4d00458ec1e43c22fb62c03f09117d");
      service.addParameter( ::SWA::ParameterMetaData( "message", "string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_LogInfo_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_LOG::serviceId_masls_LogInfo, ::SWA::ServiceMetaData::Domain, "LogInfo", ::std::vector<int>( lines, lines + 2 ), "LogInfo.svc", "2ea7018659004583f40083bc71854a8b");
      service.addParameter( ::SWA::ParameterMetaData( "message", "string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_LogInteger_MetaData ( )
    {
      int lines[] = { 2,
     3};
      ::SWA::ServiceMetaData service(::masld_LOG::serviceId_masls_LogInteger, ::SWA::ServiceMetaData::Domain, "LogInteger", ::std::vector<int>( lines, lines + 2 ), "LogInteger.svc", "ff7202044b9b6cde57cecbb43900d7c1");
      service.addParameter( ::SWA::ParameterMetaData( "message", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_LogReal_MetaData ( )
    {
      int lines[] = { 3,
     4};
      ::SWA::ServiceMetaData service(::masld_LOG::serviceId_masls_LogReal, ::SWA::ServiceMetaData::Domain, "LogReal", ::std::vector<int>( lines, lines + 2 ), "LogReal.svc", "07e398e0930398d2c2b47da3bd0e7be1");
      service.addParameter( ::SWA::ParameterMetaData( "message", "string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "r", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      return service;
    }

  }
}
