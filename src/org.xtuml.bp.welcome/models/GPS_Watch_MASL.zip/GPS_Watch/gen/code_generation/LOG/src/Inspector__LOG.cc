//
// File: Inspector__LOG.cc
//
#include "LOG_OOA/__LOG_interface.hh"
#include "LOG_OOA/__LOG_services.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace Inspector
{
  namespace masld_LOG
  {
    class masls_LogSuccessHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_LogSuccessInvoker
    {

      public:
        masls_LogSuccessInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_LOG::interceptor_masls_LogSuccess::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_LogFailureHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_LogFailureInvoker
    {

      public:
        masls_LogFailureInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_LOG::interceptor_masls_LogFailure::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_LogInfoHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_LogInfoInvoker
    {

      public:
        masls_LogInfoInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_LogIntegerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_LogIntegerInvoker
    {

      public:
        masls_LogIntegerInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_LOG::interceptor_masls_LogInteger::instance().callService()( maslp_message ); }


      private:
        int32_t maslp_message;


    };
    class masls_LogRealHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_LogRealInvoker
    {

      public:
        masls_LogRealInvoker ( CommunicationChannel& channel )
          : maslp_message(),
            maslp_r()

        {
          channel >> maslp_message;
          channel >> maslp_r;
        }
        void operator() ( ) { ::masld_LOG::interceptor_masls_LogReal::instance().callService()( maslp_message, maslp_r ); }


      private:
        ::SWA::String maslp_message;
        double maslp_r;


    };
    class masld_LOGHandler
      : public DomainHandler
    {

      public:
        masld_LOGHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_LogSuccessHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_LogSuccessInvoker( channel );
    }

    void masls_LogSuccessHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_LogFailureHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_LogFailureInvoker( channel );
    }

    void masls_LogFailureHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_LogInfoHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_LogInfoInvoker( channel );
    }

    void masls_LogInfoHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_LogIntegerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_LogIntegerInvoker( channel );
    }

    void masls_LogIntegerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_LogRealHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_LogRealInvoker( channel );
    }

    void masls_LogRealHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write r
      channel << frame.getParameters()[1].getValue<double>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    masld_LOGHandler::masld_LOGHandler ( )
    {
      registerServiceHandler( ::masld_LOG::serviceId_masls_LogSuccess, ::boost::shared_ptr<ActionHandler>( new masls_LogSuccessHandler() ) );
      registerServiceHandler( ::masld_LOG::serviceId_masls_LogFailure, ::boost::shared_ptr<ActionHandler>( new masls_LogFailureHandler() ) );
      registerServiceHandler( ::masld_LOG::serviceId_masls_LogInfo, ::boost::shared_ptr<ActionHandler>( new masls_LogInfoHandler() ) );
      registerServiceHandler( ::masld_LOG::serviceId_masls_LogInteger, ::boost::shared_ptr<ActionHandler>( new masls_LogIntegerHandler() ) );
      registerServiceHandler( ::masld_LOG::serviceId_masls_LogReal, ::boost::shared_ptr<ActionHandler>( new masls_LogRealHandler() ) );
    }

    void masld_LOGHandler::createRelationship ( CommunicationChannel& channel,
                                                int                   relId )
    {
      switch ( relId )
      {
      }

    }

  }
}
namespace 
{
  bool masld_LOG_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "LOG" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_LOG::masld_LOGHandler() ) );

}
