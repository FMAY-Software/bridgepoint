//
// File: MetaData__if__LOG.cc
//
#include "LOG_OOA/__LOG_interface.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_LOG
  {
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_LOG::getDomain().getId(), "LOG", true);
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_LOG::getDomain().getId(), &getDomainMetaData );

  }
}
