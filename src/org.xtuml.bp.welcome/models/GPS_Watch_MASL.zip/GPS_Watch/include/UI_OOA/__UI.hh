//
// File: __UI.hh
//
#ifndef UI_OOA_UI_hh
#define UI_OOA_UI_hh

namespace masld_UI
{
  enum ObjectIds {  objectId_maslo_TestCase,
                    objectId_maslo_UI,
                    objectId_maslo_UIConstants };
  enum RelationshipIds {};
}
#endif // UI_OOA_UI_hh
