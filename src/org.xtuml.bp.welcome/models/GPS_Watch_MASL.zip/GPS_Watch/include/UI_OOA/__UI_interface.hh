//
// File: __UI_interface.hh
//
#ifndef UI_OOA_UI_interface_hh
#define UI_OOA_UI_interface_hh

#include "swa/Domain.hh"

namespace masld_UI
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_RunTestCase,
                     serviceId_masls_createGoals_1,
                     serviceId_masls_init,
                     serviceId_masls_setData,
                     serviceId_masls_setIndicator,
                     serviceId_masls_setTime,
                     serviceId_masls_startTest,
                     serviceId_masls_sendLapResetPressed,
                     serviceId_masls_sendLightPressed,
                     serviceId_masls_sendModePressed,
                     serviceId_masls_sendStartStopPressed,
                     serviceId_masls_sendTargetPressed };
  enum TerminatorIds {  terminatorId_maslb_TRACK };
}
#endif // UI_OOA_UI_interface_hh
