//
// File: __UI_types.hh
//
#ifndef UI_OOA_UI_types_hh
#define UI_OOA_UI_types_hh

#include "asn1/BERDecode.hh"
#include "asn1/BERDecoder.hh"
#include "asn1/DEREncode.hh"
#include "asn1/DEREncoder.hh"
#include "boost/operators.hpp"
#include <cstddef>
#include <iostream>
#include <map>
#include <stdint.h>
#include <string>
#include "swa/RangeIterator.hh"

namespace masld_UI
{
  class maslt_UIGoalCriteria;
  class maslt_UIGoalSpan;
  class maslt_UIIndicator;
  class maslt_UIUnit;
  class maslt_UIGoalCriteria
    : private ::boost::less_than_comparable<maslt_UIGoalCriteria,::boost::equality_comparable<maslt_UIGoalCriteria,::boost::incrementable<maslt_UIGoalCriteria,::boost::decrementable<maslt_UIGoalCriteria> > > >
  {

    // Enumerates
    public:
      static const maslt_UIGoalCriteria masle_HeartRate;
      static const maslt_UIGoalCriteria masle_Pace;


    // Enumeration
    public:
      maslt_UIGoalCriteria ( );
      static maslt_UIGoalCriteria getFirst ( ) { return masle_HeartRate; }
      static maslt_UIGoalCriteria getLast ( ) { return masle_Pace; }


    // Index Conversions
    public:
      enum Index {  index_masle_HeartRate,
                    index_masle_Pace };
    private:
      Index index;
    public:
      explicit maslt_UIGoalCriteria ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_UIGoalCriteria> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_HeartRate, masle_Pace ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Pace ); }


    // Value Conversions
    public:
      enum Value {  value_masle_HeartRate,
                    value_masle_Pace };
      explicit maslt_UIGoalCriteria ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_UIGoalCriteria ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_UIGoalCriteria ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_UIGoalCriteria& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_UIGoalCriteria& rhs ) const { return index == rhs.index; }
      maslt_UIGoalCriteria& operator++ ( );
      maslt_UIGoalCriteria& operator-- ( );
      int64_t operator- ( const maslt_UIGoalCriteria& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&             stream,
                               const maslt_UIGoalCriteria& obj );
  ::std::istream& operator>> ( ::std::istream&       stream,
                               maslt_UIGoalCriteria& obj );
  inline ::std::size_t hash_value ( const maslt_UIGoalCriteria& value ) { return value.getIndex(); }
  class maslt_UIGoalSpan
    : private ::boost::less_than_comparable<maslt_UIGoalSpan,::boost::equality_comparable<maslt_UIGoalSpan,::boost::incrementable<maslt_UIGoalSpan,::boost::decrementable<maslt_UIGoalSpan> > > >
  {

    // Enumerates
    public:
      static const maslt_UIGoalSpan masle_Distance;
      static const maslt_UIGoalSpan masle_Time;


    // Enumeration
    public:
      maslt_UIGoalSpan ( );
      static maslt_UIGoalSpan getFirst ( ) { return masle_Distance; }
      static maslt_UIGoalSpan getLast ( ) { return masle_Time; }


    // Index Conversions
    public:
      enum Index {  index_masle_Distance,
                    index_masle_Time };
    private:
      Index index;
    public:
      explicit maslt_UIGoalSpan ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_UIGoalSpan> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_Distance, masle_Time ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Time ); }


    // Value Conversions
    public:
      enum Value {  value_masle_Distance,
                    value_masle_Time };
      explicit maslt_UIGoalSpan ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_UIGoalSpan ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_UIGoalSpan ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_UIGoalSpan& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_UIGoalSpan& rhs ) const { return index == rhs.index; }
      maslt_UIGoalSpan& operator++ ( );
      maslt_UIGoalSpan& operator-- ( );
      int64_t operator- ( const maslt_UIGoalSpan& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&         stream,
                               const maslt_UIGoalSpan& obj );
  ::std::istream& operator>> ( ::std::istream&   stream,
                               maslt_UIGoalSpan& obj );
  inline ::std::size_t hash_value ( const maslt_UIGoalSpan& value ) { return value.getIndex(); }
  class maslt_UIIndicator
    : private ::boost::less_than_comparable<maslt_UIIndicator,::boost::equality_comparable<maslt_UIIndicator,::boost::incrementable<maslt_UIIndicator,::boost::decrementable<maslt_UIIndicator> > > >
  {

    // Enumerates
    public:
      static const maslt_UIIndicator masle_Blank;
      static const maslt_UIIndicator masle_Down;
      static const maslt_UIIndicator masle_Flat;
      static const maslt_UIIndicator masle_Up;


    // Enumeration
    public:
      maslt_UIIndicator ( );
      static maslt_UIIndicator getFirst ( ) { return masle_Blank; }
      static maslt_UIIndicator getLast ( ) { return masle_Up; }


    // Index Conversions
    public:
      enum Index {  index_masle_Blank,
                    index_masle_Down,
                    index_masle_Flat,
                    index_masle_Up };
    private:
      Index index;
    public:
      explicit maslt_UIIndicator ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_UIIndicator> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_Blank, masle_Up ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Up ); }


    // Value Conversions
    public:
      enum Value {  value_masle_Blank,
                    value_masle_Down,
                    value_masle_Flat,
                    value_masle_Up };
      explicit maslt_UIIndicator ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_UIIndicator ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_UIIndicator ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_UIIndicator& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_UIIndicator& rhs ) const { return index == rhs.index; }
      maslt_UIIndicator& operator++ ( );
      maslt_UIIndicator& operator-- ( );
      int64_t operator- ( const maslt_UIIndicator& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&          stream,
                               const maslt_UIIndicator& obj );
  ::std::istream& operator>> ( ::std::istream&    stream,
                               maslt_UIIndicator& obj );
  inline ::std::size_t hash_value ( const maslt_UIIndicator& value ) { return value.getIndex(); }
  class maslt_UIUnit
    : private ::boost::less_than_comparable<maslt_UIUnit,::boost::equality_comparable<maslt_UIUnit,::boost::incrementable<maslt_UIUnit,::boost::decrementable<maslt_UIUnit> > > >
  {

    // Enumerates
    public:
      static const maslt_UIUnit masle_km;
      static const maslt_UIUnit masle_meters;
      static const maslt_UIUnit masle_minPerKm;
      static const maslt_UIUnit masle_kmPerHour;
      static const maslt_UIUnit masle_miles;
      static const maslt_UIUnit masle_yards;
      static const maslt_UIUnit masle_feet;
      static const maslt_UIUnit masle_minPerMile;
      static const maslt_UIUnit masle_mph;
      static const maslt_UIUnit masle_bpm;
      static const maslt_UIUnit masle_laps;


    // Enumeration
    public:
      maslt_UIUnit ( );
      static maslt_UIUnit getFirst ( ) { return masle_km; }
      static maslt_UIUnit getLast ( ) { return masle_laps; }


    // Index Conversions
    public:
      enum Index {  index_masle_km,
                    index_masle_meters,
                    index_masle_minPerKm,
                    index_masle_kmPerHour,
                    index_masle_miles,
                    index_masle_yards,
                    index_masle_feet,
                    index_masle_minPerMile,
                    index_masle_mph,
                    index_masle_bpm,
                    index_masle_laps };
    private:
      Index index;
    public:
      explicit maslt_UIUnit ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_UIUnit> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_km, masle_laps ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_laps ); }


    // Value Conversions
    public:
      enum Value {  value_masle_km,
                    value_masle_meters,
                    value_masle_minPerKm,
                    value_masle_kmPerHour,
                    value_masle_miles,
                    value_masle_yards,
                    value_masle_feet,
                    value_masle_minPerMile,
                    value_masle_mph,
                    value_masle_bpm,
                    value_masle_laps };
      explicit maslt_UIUnit ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_UIUnit ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_UIUnit ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_UIUnit& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_UIUnit& rhs ) const { return index == rhs.index; }
      maslt_UIUnit& operator++ ( );
      maslt_UIUnit& operator-- ( );
      int64_t operator- ( const maslt_UIUnit& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&     stream,
                               const maslt_UIUnit& obj );
  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_UIUnit&   obj );
  inline ::std::size_t hash_value ( const maslt_UIUnit& value ) { return value.getIndex(); }
}
namespace ASN1
{
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_UI::maslt_UIGoalCriteria& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                 decoder,
                       ::masld_UI::maslt_UIGoalCriteria& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_UI::maslt_UIGoalSpan& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&             decoder,
                       ::masld_UI::maslt_UIGoalSpan& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_UI::maslt_UIIndicator& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&              decoder,
                       ::masld_UI::maslt_UIIndicator& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_UI::maslt_UIUnit& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&         decoder,
                       ::masld_UI::maslt_UIUnit& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
}
#endif // UI_OOA_UI_types_hh
