//
// File: __UI_private_types.hh
//
#ifndef UI_OOA_UI_private_types_hh
#define UI_OOA_UI_private_types_hh

#endif // UI_OOA_UI_private_types_hh
