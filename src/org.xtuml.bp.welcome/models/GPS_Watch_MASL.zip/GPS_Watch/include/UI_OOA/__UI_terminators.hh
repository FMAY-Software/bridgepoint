//
// File: __UI_terminators.hh
//
#ifndef UI_OOA_UI_terminators_hh
#define UI_OOA_UI_terminators_hh

#include <stdint.h>
#include "swa/FunctionOverrider.hh"

namespace masld_UI
{
  class maslt_UIGoalSpan;
  class maslt_UIGoalCriteria;
  class maslb_TRACK
  {

    // Terminator Services
    public:
      static void masls_setTargetPressed ( );
      static void masls_startStopPressed ( );
      static void masls_lapResetPressed ( );
      static void masls_lightPressed ( );
      static void masls_modePressed ( );
      static void masls_newGoalSpec ( const maslt_UIGoalSpan&     maslp_spanType,
                                      const maslt_UIGoalCriteria& maslp_criteriaType,
                                      double                      maslp_span,
                                      double                      maslp_maximum,
                                      double                      maslp_minimum,
                                      int32_t                     maslp_sequenceNumber );


    // Service Registration
    public:
      static bool register_masls_setTargetPressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_startStopPressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_lapResetPressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_lightPressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_modePressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_newGoalSpec ( ::SWA::FunctionOverrider<void (const maslt_UIGoalSpan&,const maslt_UIGoalCriteria&,double,double,double,int32_t)>::FunctionPtr override );


    // Override Checks
    public:
      static bool overriden_masls_setTargetPressed ( );
      static bool overriden_masls_startStopPressed ( );
      static bool overriden_masls_lapResetPressed ( );
      static bool overriden_masls_lightPressed ( );
      static bool overriden_masls_modePressed ( );
      static bool overriden_masls_newGoalSpec ( );


    // Singleton
    private:
      static maslb_TRACK& getInstance ( );
      maslb_TRACK ( );


    // Domain Defined Services
    private:
      static void domain_masls_setTargetPressed ( );
      static void domain_masls_startStopPressed ( );
      static void domain_masls_lapResetPressed ( );
      static void domain_masls_lightPressed ( );
      static void domain_masls_modePressed ( );
      static void domain_masls_newGoalSpec ( const maslt_UIGoalSpan&     maslp_spanType,
                                             const maslt_UIGoalCriteria& maslp_criteriaType,
                                             double                      maslp_span,
                                             double                      maslp_maximum,
                                             double                      maslp_minimum,
                                             int32_t                     maslp_sequenceNumber );


    // Overriden Services
    private:
      ::SWA::FunctionOverrider<void()> override_masls_setTargetPressed;
      ::SWA::FunctionOverrider<void()> override_masls_startStopPressed;
      ::SWA::FunctionOverrider<void()> override_masls_lapResetPressed;
      ::SWA::FunctionOverrider<void()> override_masls_lightPressed;
      ::SWA::FunctionOverrider<void()> override_masls_modePressed;
      ::SWA::FunctionOverrider<void (const maslt_UIGoalSpan&,const maslt_UIGoalCriteria&,double,double,double,int32_t)> override_masls_newGoalSpec;


    // Id Enumerations
    public:
      enum ServiceIds {  serviceId_masls_setTargetPressed,
                         serviceId_masls_startStopPressed,
                         serviceId_masls_lapResetPressed,
                         serviceId_masls_lightPressed,
                         serviceId_masls_modePressed,
                         serviceId_masls_newGoalSpec };


  };
}
#endif // UI_OOA_UI_terminators_hh
