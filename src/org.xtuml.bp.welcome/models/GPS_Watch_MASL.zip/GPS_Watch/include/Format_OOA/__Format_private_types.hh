//
// File: __Format_private_types.hh
//
#ifndef Format_OOA_Format_private_types_hh
#define Format_OOA_Format_private_types_hh

#endif // Format_OOA_Format_private_types_hh
