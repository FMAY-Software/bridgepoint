//
// File: __Format.hh
//
#ifndef Format_OOA_Format_hh
#define Format_OOA_Format_hh

namespace masld_Format
{
  enum ObjectIds {};
  enum RelationshipIds {};
}
#endif // Format_OOA_Format_hh
