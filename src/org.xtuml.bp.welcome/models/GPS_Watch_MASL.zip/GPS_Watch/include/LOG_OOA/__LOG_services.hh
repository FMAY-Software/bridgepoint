//
// File: __LOG_services.hh
//
#ifndef LOG_OOA_LOG_services_hh
#define LOG_OOA_LOG_services_hh

#include <stdint.h>
#include "swa/ServiceInterceptor.hh"
#include "swa/String.hh"

namespace masld_LOG
{
  void masls_LogSuccess ( const ::SWA::String& maslp_message );
  class masls_LogSuccess_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_LogSuccess_tag,void (const ::SWA::String&)> interceptor_masls_LogSuccess;
  void masls_LogFailure ( const ::SWA::String& maslp_message );
  class masls_LogFailure_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_LogFailure_tag,void (const ::SWA::String&)> interceptor_masls_LogFailure;
  void masls_LogInfo ( const ::SWA::String& maslp_message );
  class masls_LogInfo_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_LogInfo_tag,void (const ::SWA::String&)> interceptor_masls_LogInfo;
  void masls_LogInteger ( int32_t maslp_message );
  class masls_LogInteger_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_LogInteger_tag,void (int32_t)> interceptor_masls_LogInteger;
  void masls_LogReal ( const ::SWA::String& maslp_message,
                       double               maslp_r );
  class masls_LogReal_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_LogReal_tag,void (const ::SWA::String&,double)> interceptor_masls_LogReal;
}
#endif // LOG_OOA_LOG_services_hh
