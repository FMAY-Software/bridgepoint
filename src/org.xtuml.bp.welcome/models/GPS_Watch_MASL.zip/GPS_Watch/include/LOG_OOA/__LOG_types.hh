//
// File: __LOG_types.hh
//
#ifndef LOG_OOA_LOG_types_hh
#define LOG_OOA_LOG_types_hh

#endif // LOG_OOA_LOG_types_hh
