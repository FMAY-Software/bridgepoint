//
// File: __LOG.hh
//
#ifndef LOG_OOA_LOG_hh
#define LOG_OOA_LOG_hh

namespace masld_LOG
{
  enum ObjectIds {};
  enum RelationshipIds {};
}
#endif // LOG_OOA_LOG_hh
