//
// File: __LOG_interface.hh
//
#ifndef LOG_OOA_LOG_interface_hh
#define LOG_OOA_LOG_interface_hh

#include "swa/Domain.hh"

namespace masld_LOG
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_LogSuccess,
                     serviceId_masls_LogFailure,
                     serviceId_masls_LogInfo,
                     serviceId_masls_LogInteger,
                     serviceId_masls_LogReal };
  enum TerminatorIds {};
}
#endif // LOG_OOA_LOG_interface_hh
