//
// File: __Logger.hh
//
#ifndef Logger_OOA_Logger_hh
#define Logger_OOA_Logger_hh

namespace masld_Logger
{
  enum ObjectIds {};
  enum RelationshipIds {};
}
#endif // Logger_OOA_Logger_hh
