//
// File: __Logger_terminators.hh
//
#ifndef Logger_OOA_Logger_terminators_hh
#define Logger_OOA_Logger_terminators_hh

#endif // Logger_OOA_Logger_terminators_hh
