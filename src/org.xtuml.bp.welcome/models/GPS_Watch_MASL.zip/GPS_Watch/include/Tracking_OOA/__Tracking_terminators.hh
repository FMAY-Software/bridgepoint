//
// File: __Tracking_terminators.hh
//
#ifndef Tracking_OOA_Tracking_terminators_hh
#define Tracking_OOA_Tracking_terminators_hh

#include <stdint.h>
#include "swa/FunctionOverrider.hh"

namespace masld_Tracking
{
  class maslt_Unit;
  class maslt_Indicator;
  class maslb_HR
  {

    // Terminator Services
    public:
      static void masls_registerListener ( );
      static void masls_unregisterListener ( );


    // Service Registration
    public:
      static bool register_masls_registerListener ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_unregisterListener ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );


    // Override Checks
    public:
      static bool overriden_masls_registerListener ( );
      static bool overriden_masls_unregisterListener ( );


    // Singleton
    private:
      static maslb_HR& getInstance ( );
      maslb_HR ( );


    // Domain Defined Services
    private:
      static void domain_masls_registerListener ( );
      static void domain_masls_unregisterListener ( );


    // Overriden Services
    private:
      ::SWA::FunctionOverrider<void()> override_masls_registerListener;
      ::SWA::FunctionOverrider<void()> override_masls_unregisterListener;


    // Id Enumerations
    public:
      enum ServiceIds {  serviceId_masls_registerListener,
                         serviceId_masls_unregisterListener };


  };
  class maslb_LOC
  {

    // Terminator Services
    public:
      static void masls_getDistance ( double& maslp_result,
                                      double  maslp_toLong,
                                      double  maslp_toLat,
                                      double  maslp_fromLong,
                                      double  maslp_fromLat );
      static void masls_getLocation ( double& maslp_longitude,
                                      double& maslp_latitude );
      static void masls_registerListener ( );
      static void masls_unregisterListener ( );


    // Service Registration
    public:
      static bool register_masls_getDistance ( ::SWA::FunctionOverrider<void (double&,double,double,double,double)>::FunctionPtr override );
      static bool register_masls_getLocation ( ::SWA::FunctionOverrider<void (double&,double&)>::FunctionPtr override );
      static bool register_masls_registerListener ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );
      static bool register_masls_unregisterListener ( ::SWA::FunctionOverrider<void()>::FunctionPtr override );


    // Override Checks
    public:
      static bool overriden_masls_getDistance ( );
      static bool overriden_masls_getLocation ( );
      static bool overriden_masls_registerListener ( );
      static bool overriden_masls_unregisterListener ( );


    // Singleton
    private:
      static maslb_LOC& getInstance ( );
      maslb_LOC ( );


    // Domain Defined Services
    private:
      static void domain_masls_getDistance ( double& maslp_result,
                                             double  maslp_toLong,
                                             double  maslp_toLat,
                                             double  maslp_fromLong,
                                             double  maslp_fromLat );
      static void domain_masls_getLocation ( double& maslp_longitude,
                                             double& maslp_latitude );
      static void domain_masls_registerListener ( );
      static void domain_masls_unregisterListener ( );


    // Overriden Services
    private:
      ::SWA::FunctionOverrider<void (double&,double,double,double,double)> override_masls_getDistance;
      ::SWA::FunctionOverrider<void (double&,double&)> override_masls_getLocation;
      ::SWA::FunctionOverrider<void()> override_masls_registerListener;
      ::SWA::FunctionOverrider<void()> override_masls_unregisterListener;


    // Id Enumerations
    public:
      enum ServiceIds {  serviceId_masls_getDistance,
                         serviceId_masls_getLocation,
                         serviceId_masls_registerListener,
                         serviceId_masls_unregisterListener };


  };
  class maslb_UI
  {

    // Terminator Services
    public:
      static void masls_setData ( double            maslp_value,
                                  const maslt_Unit& maslp_unit );
      static void masls_setIndicator ( const maslt_Indicator& maslp_indicator );
      static void masls_setTime ( int32_t maslp_time );


    // Service Registration
    public:
      static bool register_masls_setData ( ::SWA::FunctionOverrider<void (double,const maslt_Unit&)>::FunctionPtr override );
      static bool register_masls_setIndicator ( ::SWA::FunctionOverrider<void (const maslt_Indicator&)>::FunctionPtr override );
      static bool register_masls_setTime ( ::SWA::FunctionOverrider<void (int32_t)>::FunctionPtr override );


    // Override Checks
    public:
      static bool overriden_masls_setData ( );
      static bool overriden_masls_setIndicator ( );
      static bool overriden_masls_setTime ( );


    // Singleton
    private:
      static maslb_UI& getInstance ( );
      maslb_UI ( );


    // Domain Defined Services
    private:
      static void domain_masls_setData ( double            maslp_value,
                                         const maslt_Unit& maslp_unit );
      static void domain_masls_setIndicator ( const maslt_Indicator& maslp_indicator );
      static void domain_masls_setTime ( int32_t maslp_time );


    // Overriden Services
    private:
      ::SWA::FunctionOverrider<void (double,const maslt_Unit&)> override_masls_setData;
      ::SWA::FunctionOverrider<void (const maslt_Indicator&)> override_masls_setIndicator;
      ::SWA::FunctionOverrider<void (int32_t)> override_masls_setTime;


    // Id Enumerations
    public:
      enum ServiceIds {  serviceId_masls_setData,
                         serviceId_masls_setIndicator,
                         serviceId_masls_setTime };


  };
}
#endif // Tracking_OOA_Tracking_terminators_hh
