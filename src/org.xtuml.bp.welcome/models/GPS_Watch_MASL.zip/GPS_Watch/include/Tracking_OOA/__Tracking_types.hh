//
// File: __Tracking_types.hh
//
#ifndef Tracking_OOA_Tracking_types_hh
#define Tracking_OOA_Tracking_types_hh

#include "asn1/BERDecode.hh"
#include "asn1/BERDecoder.hh"
#include "asn1/DEREncode.hh"
#include "asn1/DEREncoder.hh"
#include "boost/operators.hpp"
#include <cstddef>
#include <iostream>
#include <map>
#include <stdint.h>
#include <string>
#include "swa/RangeIterator.hh"

namespace masld_Tracking
{
  class maslt_GoalCriteria;
  class maslt_GoalDisposition;
  class maslt_GoalSpan;
  class maslt_Indicator;
  class maslt_Unit;
  class maslt_GoalCriteria
    : private ::boost::less_than_comparable<maslt_GoalCriteria,::boost::equality_comparable<maslt_GoalCriteria,::boost::incrementable<maslt_GoalCriteria,::boost::decrementable<maslt_GoalCriteria> > > >
  {

    // Enumerates
    public:
      static const maslt_GoalCriteria masle_HeartRate;
      static const maslt_GoalCriteria masle_Pace;


    // Enumeration
    public:
      maslt_GoalCriteria ( );
      static maslt_GoalCriteria getFirst ( ) { return masle_HeartRate; }
      static maslt_GoalCriteria getLast ( ) { return masle_Pace; }


    // Index Conversions
    public:
      enum Index {  index_masle_HeartRate,
                    index_masle_Pace };
    private:
      Index index;
    public:
      explicit maslt_GoalCriteria ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_GoalCriteria> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_HeartRate, masle_Pace ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Pace ); }


    // Value Conversions
    public:
      enum Value {  value_masle_HeartRate,
                    value_masle_Pace };
      explicit maslt_GoalCriteria ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_GoalCriteria ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_GoalCriteria ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_GoalCriteria& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_GoalCriteria& rhs ) const { return index == rhs.index; }
      maslt_GoalCriteria& operator++ ( );
      maslt_GoalCriteria& operator-- ( );
      int64_t operator- ( const maslt_GoalCriteria& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&           stream,
                               const maslt_GoalCriteria& obj );
  ::std::istream& operator>> ( ::std::istream&     stream,
                               maslt_GoalCriteria& obj );
  inline ::std::size_t hash_value ( const maslt_GoalCriteria& value ) { return value.getIndex(); }
  class maslt_GoalDisposition
    : private ::boost::less_than_comparable<maslt_GoalDisposition,::boost::equality_comparable<maslt_GoalDisposition,::boost::incrementable<maslt_GoalDisposition,::boost::decrementable<maslt_GoalDisposition> > > >
  {

    // Enumerates
    public:
      static const maslt_GoalDisposition masle_Achieving;
      static const maslt_GoalDisposition masle_Increase;
      static const maslt_GoalDisposition masle_Decrease;


    // Enumeration
    public:
      maslt_GoalDisposition ( );
      static maslt_GoalDisposition getFirst ( ) { return masle_Achieving; }
      static maslt_GoalDisposition getLast ( ) { return masle_Decrease; }


    // Index Conversions
    public:
      enum Index {  index_masle_Achieving,
                    index_masle_Increase,
                    index_masle_Decrease };
    private:
      Index index;
    public:
      explicit maslt_GoalDisposition ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_GoalDisposition> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_Achieving, masle_Decrease ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Decrease ); }


    // Value Conversions
    public:
      enum Value {  value_masle_Achieving,
                    value_masle_Increase,
                    value_masle_Decrease };
      explicit maslt_GoalDisposition ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_GoalDisposition ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_GoalDisposition ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_GoalDisposition& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_GoalDisposition& rhs ) const { return index == rhs.index; }
      maslt_GoalDisposition& operator++ ( );
      maslt_GoalDisposition& operator-- ( );
      int64_t operator- ( const maslt_GoalDisposition& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&              stream,
                               const maslt_GoalDisposition& obj );
  ::std::istream& operator>> ( ::std::istream&        stream,
                               maslt_GoalDisposition& obj );
  inline ::std::size_t hash_value ( const maslt_GoalDisposition& value ) { return value.getIndex(); }
  class maslt_GoalSpan
    : private ::boost::less_than_comparable<maslt_GoalSpan,::boost::equality_comparable<maslt_GoalSpan,::boost::incrementable<maslt_GoalSpan,::boost::decrementable<maslt_GoalSpan> > > >
  {

    // Enumerates
    public:
      static const maslt_GoalSpan masle_Distance;
      static const maslt_GoalSpan masle_Time;


    // Enumeration
    public:
      maslt_GoalSpan ( );
      static maslt_GoalSpan getFirst ( ) { return masle_Distance; }
      static maslt_GoalSpan getLast ( ) { return masle_Time; }


    // Index Conversions
    public:
      enum Index {  index_masle_Distance,
                    index_masle_Time };
    private:
      Index index;
    public:
      explicit maslt_GoalSpan ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_GoalSpan> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_Distance, masle_Time ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Time ); }


    // Value Conversions
    public:
      enum Value {  value_masle_Distance,
                    value_masle_Time };
      explicit maslt_GoalSpan ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_GoalSpan ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_GoalSpan ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_GoalSpan& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_GoalSpan& rhs ) const { return index == rhs.index; }
      maslt_GoalSpan& operator++ ( );
      maslt_GoalSpan& operator-- ( );
      int64_t operator- ( const maslt_GoalSpan& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslt_GoalSpan& obj );
  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_GoalSpan& obj );
  inline ::std::size_t hash_value ( const maslt_GoalSpan& value ) { return value.getIndex(); }
  class maslt_Indicator
    : private ::boost::less_than_comparable<maslt_Indicator,::boost::equality_comparable<maslt_Indicator,::boost::incrementable<maslt_Indicator,::boost::decrementable<maslt_Indicator> > > >
  {

    // Enumerates
    public:
      static const maslt_Indicator masle_Blank;
      static const maslt_Indicator masle_Down;
      static const maslt_Indicator masle_Flat;
      static const maslt_Indicator masle_Up;


    // Enumeration
    public:
      maslt_Indicator ( );
      static maslt_Indicator getFirst ( ) { return masle_Blank; }
      static maslt_Indicator getLast ( ) { return masle_Up; }


    // Index Conversions
    public:
      enum Index {  index_masle_Blank,
                    index_masle_Down,
                    index_masle_Flat,
                    index_masle_Up };
    private:
      Index index;
    public:
      explicit maslt_Indicator ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_Indicator> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_Blank, masle_Up ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Up ); }


    // Value Conversions
    public:
      enum Value {  value_masle_Blank,
                    value_masle_Down,
                    value_masle_Flat,
                    value_masle_Up };
      explicit maslt_Indicator ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_Indicator ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_Indicator ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_Indicator& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_Indicator& rhs ) const { return index == rhs.index; }
      maslt_Indicator& operator++ ( );
      maslt_Indicator& operator-- ( );
      int64_t operator- ( const maslt_Indicator& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&        stream,
                               const maslt_Indicator& obj );
  ::std::istream& operator>> ( ::std::istream&  stream,
                               maslt_Indicator& obj );
  inline ::std::size_t hash_value ( const maslt_Indicator& value ) { return value.getIndex(); }
  class maslt_Unit
    : private ::boost::less_than_comparable<maslt_Unit,::boost::equality_comparable<maslt_Unit,::boost::incrementable<maslt_Unit,::boost::decrementable<maslt_Unit> > > >
  {

    // Enumerates
    public:
      static const maslt_Unit masle_km;
      static const maslt_Unit masle_meters;
      static const maslt_Unit masle_minPerKm;
      static const maslt_Unit masle_kmPerHour;
      static const maslt_Unit masle_miles;
      static const maslt_Unit masle_yards;
      static const maslt_Unit masle_feet;
      static const maslt_Unit masle_minPerMile;
      static const maslt_Unit masle_mph;
      static const maslt_Unit masle_bpm;
      static const maslt_Unit masle_laps;


    // Enumeration
    public:
      maslt_Unit ( );
      static maslt_Unit getFirst ( ) { return masle_km; }
      static maslt_Unit getLast ( ) { return masle_laps; }


    // Index Conversions
    public:
      enum Index {  index_masle_km,
                    index_masle_meters,
                    index_masle_minPerKm,
                    index_masle_kmPerHour,
                    index_masle_miles,
                    index_masle_yards,
                    index_masle_feet,
                    index_masle_minPerMile,
                    index_masle_mph,
                    index_masle_bpm,
                    index_masle_laps };
    private:
      Index index;
    public:
      explicit maslt_Unit ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_Unit> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_km, masle_laps ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_laps ); }


    // Value Conversions
    public:
      enum Value {  value_masle_km,
                    value_masle_meters,
                    value_masle_minPerKm,
                    value_masle_kmPerHour,
                    value_masle_miles,
                    value_masle_yards,
                    value_masle_feet,
                    value_masle_minPerMile,
                    value_masle_mph,
                    value_masle_bpm,
                    value_masle_laps };
      explicit maslt_Unit ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_Unit ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_Unit ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_Unit& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_Unit& rhs ) const { return index == rhs.index; }
      maslt_Unit& operator++ ( );
      maslt_Unit& operator-- ( );
      int64_t operator- ( const maslt_Unit& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&   stream,
                               const maslt_Unit& obj );
  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_Unit&     obj );
  inline ::std::size_t hash_value ( const maslt_Unit& value ) { return value.getIndex(); }
}
namespace ASN1
{
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Tracking::maslt_GoalCriteria& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                     decoder,
                       ::masld_Tracking::maslt_GoalCriteria& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Tracking::maslt_GoalDisposition& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                        decoder,
                       ::masld_Tracking::maslt_GoalDisposition& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Tracking::maslt_GoalSpan& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                 decoder,
                       ::masld_Tracking::maslt_GoalSpan& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Tracking::maslt_Indicator& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                  decoder,
                       ::masld_Tracking::maslt_Indicator& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Tracking::maslt_Unit& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&             decoder,
                       ::masld_Tracking::maslt_Unit& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
}
#endif // Tracking_OOA_Tracking_types_hh
