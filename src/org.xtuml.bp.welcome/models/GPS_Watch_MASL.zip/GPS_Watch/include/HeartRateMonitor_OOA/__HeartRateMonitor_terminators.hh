//
// File: __HeartRateMonitor_terminators.hh
//
#ifndef Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_terminators_hh
#define Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_terminators_hh

#include <stdint.h>
#include "swa/FunctionOverrider.hh"

namespace masld_HeartRateMonitor
{
  class maslb_HRChange
  {

    // Terminator Services
    public:
      static void masls_heartRateChanged ( int32_t maslp_heartRate );


    // Service Registration
    public:
      static bool register_masls_heartRateChanged ( ::SWA::FunctionOverrider<void (int32_t)>::FunctionPtr override );


    // Override Checks
    public:
      static bool overriden_masls_heartRateChanged ( );


    // Singleton
    private:
      static maslb_HRChange& getInstance ( );
      maslb_HRChange ( );


    // Domain Defined Services
    private:
      static void domain_masls_heartRateChanged ( int32_t maslp_heartRate );


    // Overriden Services
    private:
      ::SWA::FunctionOverrider<void (int32_t)> override_masls_heartRateChanged;


    // Id Enumerations
    public:
      enum ServiceIds {  serviceId_masls_heartRateChanged };


  };
}
#endif // Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_terminators_hh
