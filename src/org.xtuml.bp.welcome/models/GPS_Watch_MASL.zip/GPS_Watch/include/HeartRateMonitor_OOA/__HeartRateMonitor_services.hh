//
// File: __HeartRateMonitor_services.hh
//
#ifndef Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_services_hh
#define Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_services_hh

#include "swa/ServiceInterceptor.hh"

namespace masld_HeartRateMonitor
{
  void masls_registerListener ( );
  class masls_registerListener_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_registerListener_tag,void()> interceptor_masls_registerListener;
  void masls_unregisterListener ( );
  class masls_unregisterListener_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_unregisterListener_tag,void()> interceptor_masls_unregisterListener;
}
#endif // Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_services_hh
