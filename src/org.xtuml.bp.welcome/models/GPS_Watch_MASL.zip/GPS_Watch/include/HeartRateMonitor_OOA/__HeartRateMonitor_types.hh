//
// File: __HeartRateMonitor_types.hh
//
#ifndef Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_types_hh
#define Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_types_hh

#endif // Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_types_hh
