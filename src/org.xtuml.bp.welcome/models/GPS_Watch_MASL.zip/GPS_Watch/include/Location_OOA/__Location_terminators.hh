//
// File: __Location_terminators.hh
//
#ifndef Location_OOA_Location_terminators_hh
#define Location_OOA_Location_terminators_hh

#endif // Location_OOA_Location_terminators_hh
