//
// File: __Location.hh
//
#ifndef Location_OOA_Location_hh
#define Location_OOA_Location_hh

namespace masld_Location
{
  enum ObjectIds {  objectId_maslo_Distance,
                    objectId_maslo_GPS,
                    objectId_maslo_simulatedGPS };
  enum RelationshipIds {};
}
#endif // Location_OOA_Location_hh
